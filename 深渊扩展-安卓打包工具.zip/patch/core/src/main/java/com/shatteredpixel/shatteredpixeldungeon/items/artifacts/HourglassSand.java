package com.shatteredpixel.shatteredpixeldungeon.items.artifacts;

import com.shatteredpixel.shatteredpixeldungeon.Dungeon;
import com.shatteredpixel.shatteredpixeldungeon.actors.Actor;
import com.shatteredpixel.shatteredpixeldungeon.actors.Char;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.Buff;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.MagicImmune;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.Regeneration;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.SandPillars;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.SandStasis;
import com.shatteredpixel.shatteredpixeldungeon.actors.hero.Hero;
import com.shatteredpixel.shatteredpixeldungeon.actors.mobs.Mob;
import com.shatteredpixel.shatteredpixeldungeon.items.Item;
import com.shatteredpixel.shatteredpixeldungeon.items.rings.RingOfEnergy;
import com.shatteredpixel.shatteredpixeldungeon.levels.Level;
import com.shatteredpixel.shatteredpixeldungeon.levels.Terrain;
import com.shatteredpixel.shatteredpixeldungeon.scenes.CellSelector;
import com.shatteredpixel.shatteredpixeldungeon.scenes.GameScene;
import com.shatteredpixel.shatteredpixeldungeon.utils.GLog;
import com.watabou.noosa.audio.Sample;

import java.lang.reflect.Field;

/**
 * MOD: 时光沙漏的强化（通过试炼 + 装在神器位上）：
 *
 * <ul>
 *   <li><b>充能快 1.5 倍</b>：每回合额外补半份充能。</li>
 *   <li><b>洒沙</b>：花 1 点充能上限，把身边一个敌人凝滞住；
 *       玩家离开本层时沙粒自动回收，凝滞解除，并把那 1 点上限还回来。</li>
 * </ul>
 *
 * <p>沙漏本身是原版类（charge / chargeCap / partialCharge 都是 protected），
 * 这里用反射读写那几个字段，失败就静默跳过，不会影响沙漏原有功能。</p>
 */
public class HourglassSand {

    /** 沙漏：强化过、装在神器位、且没在试炼诅咒里 */
    public static boolean active() {
        Hero hero = Dungeon.hero;
        if (hero == null || hero.belongings == null || Dungeon.level == null) {
            return false;
        }
        Artifact equipped = hero.belongings.artifact();
        if (!(equipped instanceof TimekeepersHourglass)) {
            return false;
        }
        if (equipped.cursed || hero.buff(MagicImmune.class) != null) {
            return false;
        }
        return ArtifactTrial.isEnhancedClass(TimekeepersHourglass.class);
    }

    private static TimekeepersHourglass hourglass() {
        Hero hero = Dungeon.hero;
        if (hero == null || hero.belongings == null) {
            return null;
        }
        return hero.belongings.getItem(TimekeepersHourglass.class);
    }

    // ============================================================
    // 充能速率 ×1.5
    // ============================================================

    /** 每回合调用：在原版那份充能之外，再补半份（合计 1.5 倍） */
    public static void fasterRecharge() {
        if (!active()) {
            return;
        }
        TimekeepersHourglass h = hourglass();
        if (h == null || h.cursed || !Regeneration.regenOn()) {
            return;
        }
        int cap = readInt(h, "chargeCap", 5 + h.level());
        int charge = readInt(h, "charge", 0);
        if (charge >= cap) {
            return;
        }
        // 与原版同样的速率公式，只要一半
        float gain = 1.0f / (90.0f - (cap - charge) * 3.0f)
                * RingOfEnergy.artifactChargeMultiplier(Dungeon.hero);
        addPartial(h, 0.5f * gain);
    }

    // ============================================================
    // 洒沙
    // ============================================================

    private static final CellSelector.Listener PICK = new CellSelector.Listener() {
        @Override
        public void onSelect(Integer cell) {
            if (cell == null) {
                return;
            }
            if (Dungeon.level.distance(cell, Dungeon.hero.pos) > 2) {
                GLog.w("只能凝滞身边两格内的东西。");
                return;
            }
            Char ch = Actor.findChar(cell);
            if (ch instanceof Mob) {
                apply((Mob) ch);
                return;
            }
            if (Dungeon.level.map[cell] == Terrain.HIGH_GRASS) {
                applyPillar(cell);
                return;
            }
            GLog.w("得选一个敌人，或者一丛高草。");
        }

        @Override
        public String prompt() {
            return "选身边的敌人或高草，把沙粒洒上去";
        }
    };

    /** 打开目标选择 */
    public static void cast(Hero hero) {
        if (!active()) {
            return;
        }
        TimekeepersHourglass h = hourglass();
        if (h == null) {
            return;
        }
        if (readInt(h, "chargeCap", 5 + h.level()) <= 1) {
            GLog.w("充能上限不够了，洒不出沙粒。");
            return;
        }
        GameScene.selectCell(PICK);
    }

    private static void apply(Mob m) {
        TimekeepersHourglass h = hourglass();
        if (h == null) {
            return;
        }
        if (m.buff(SandStasis.class) != null) {
            GLog.w("它已经被沙粒裹住了。");
            return;
        }
        // NPC（商人、友好小恶魔之类）不吃这套，先给个红字，别白扣上限
        if (m instanceof com.shatteredpixel.shatteredpixeldungeon.actors.mobs.npcs.NPC) {
            GLog.w("沙粒从它身上滑落——凝滞失败了。");
            return;
        }
        int cap = readInt(h, "chargeCap", 5 + h.level());
        if (cap <= 1) {
            GLog.w("充能上限不够了，洒不出沙粒。");
            return;
        }
        // 先试着裹上去，成功了才抵押上限
        SandStasis s = Buff.affect(m, SandStasis.class);
        if (s == null) {
            GLog.w("沙粒从它身上滑落——凝滞失败了。");
            return;
        }
        writeInt(h, "chargeCap", cap - 1);
        if (readInt(h, "charge", 0) > cap - 1) {
            writeInt(h, "charge", cap - 1);
        }
        s.depth = Dungeon.depth;
        Sample.INSTANCE.play("sounds/teleport.mp3");
        GameScene.flash(0x33000000);
        GLog.p("沙粒洒开了。「" + m.name() + "」被凝滞在原地。");
        Item.updateQuickslot();
        Dungeon.hero.spendAndNext(1.0f);
    }

    /** 回收 n 份沙粒：充能上限 +n（供 SandStasis 记账时调用） */
    public static void refundSand(int n) {
        returnSand(n, Dungeon.hero);
    }

    /** 离开本层：回收所有沙粒，解除凝滞，把上限还回去 */
    public static void onLeavingLevel(Hero hero) {
        if (Dungeon.level == null) {
            return;
        }
        // 怪物身上的沙子由 SandStasis.detach() → consumeAndRefund() 自己记账，这里只负责摘掉
        for (Mob m : Dungeon.level.mobs.toArray(new Mob[0])) {
            SandStasis s = m.buff(SandStasis.class);
            if (s == null) {
                continue;
            }
            s.detach();
        }
        // 草丛柱子也一起化掉（沙回到沙漏里）
        SandPillars p = SandPillars.get();
        int pillars = 0;
        if (p != null && p.depth == Dungeon.depth) {
            pillars = p.cells.size();
            p.cells.clear();
            p.depth = -1;
            p.detach();
        }
        returnSand(pillars, hero);
    }

    /** 把 count 份沙粒还给沙漏（充能上限 +count） */
    private static void returnSand(int count, Hero hero) {
        if (count <= 0) {
            return;
        }
        TimekeepersHourglass h = hero == null || hero.belongings == null
                ? null : hero.belongings.getItem(TimekeepersHourglass.class);
        if (h != null) {
            int cap = readInt(h, "chargeCap", 5 + h.level());
            writeInt(h, "chargeCap", cap + count);
            Item.updateQuickslot();
        }
        GLog.p("沙粒从「" + count + "」处回到了沙漏里：充能上限 +" + count + "。");
    }

    // ============================================================
    // 沙柱：把高草丛凝成「墙」
    // ============================================================

    /** 这一格是不是本层的沙柱（检视文案、判定都用它） */
    public static boolean isPillar(int cell) {
        SandPillars p = SandPillars.get();
        return p != null && p.has(cell);
    }

    /** 洒在高草上：草变成不可通行、挡视线、不着火、不进水的沙柱 */
    private static void applyPillar(int cell) {
        TimekeepersHourglass h = hourglass();
        if (h == null || isPillar(cell)) {
            return;
        }
        int cap = readInt(h, "chargeCap", 5 + h.level());
        if (cap <= 1) {
            GLog.w("充能上限不够了，洒不出沙粒。");
            return;
        }
        SandPillars p = SandPillars.ensure();
        if (p == null) {
            GLog.w("沙粒凝不起来。");
            return;
        }
        writeInt(h, "chargeCap", cap - 1);
        if (readInt(h, "charge", 0) > cap - 1) {
            writeInt(h, "charge", cap - 1);
        }
        if (p.depth != Dungeon.depth) {
            p.cells.clear();
            p.depth = Dungeon.depth;
        }
        p.cells.add(cell);
        assertPillar(cell);
        Sample.INSTANCE.play("sounds/teleport.mp3");
        GLog.p("沙粒落在草丛上，凝成了一根柱子。");
        Item.updateQuickslot();
        Dungeon.observe();
        GameScene.updateFog();
        Dungeon.hero.spendAndNext(1.0f);
    }

    /** 每回合把沙柱重新钉死：引擎会按地形重算 passable / losBlocking / flamable 这些数组 */
    public static void assertPillars() {
        if (Dungeon.level == null) {
            return;
        }
        SandPillars p = SandPillars.get();
        if (p == null || p.cells.isEmpty()) {
            return;
        }
        if (p.depth != Dungeon.depth) {
            // 读档换层之类：这批沙属于别的楼层了，直接还回去
            int n = p.cells.size();
            p.cells.clear();
            p.depth = -1;
            p.detach();
            returnSand(n, Dungeon.hero);
            return;
        }
        for (Integer c : p.cells.toArray(new Integer[0])) {
            assertPillar(c);
        }
    }

    private static void assertPillar(int cell) {
        Level level = Dungeon.level;
        if (level == null || cell < 0 || cell >= level.length()) {
            return;
        }
        // 被踩踏 / 被烧 / 被水淹掉的话，把地形补回高草
        if (level.map[cell] != Terrain.HIGH_GRASS) {
            Level.set(cell, Terrain.HIGH_GRASS);
            GameScene.updateMap(cell);
        }
        level.solid[cell] = true;
        level.passable[cell] = false;
        level.losBlocking[cell] = true;
        level.flamable[cell] = false;
        level.water[cell] = false;
    }

    // ============================================================
    // 反射读写 Artifact 的 protected 字段
    // ============================================================

    private static int readInt(Artifact a, String field, int def) {
        try {
            Field f = Artifact.class.getDeclaredField(field);
            f.setAccessible(true);
            return f.getInt(a);
        } catch (Throwable t) {
            return def;
        }
    }

    private static void writeInt(Artifact a, String field, int value) {
        try {
            Field f = Artifact.class.getDeclaredField(field);
            f.setAccessible(true);
            f.setInt(a, value);
        } catch (Throwable ignored) {
        }
    }

    private static void addPartial(Artifact a, float add) {
        try {
            Field pf = Artifact.class.getDeclaredField("partialCharge");
            pf.setAccessible(true);
            float partial = pf.getFloat(a) + add;
            int charge = readInt(a, "charge", 0);
            int cap = readInt(a, "chargeCap", 0);
            while (partial >= 1.0f && charge < cap) {
                partial -= 1.0f;
                charge++;
            }
            if (charge >= cap) {
                partial = 0.0f;
            }
            pf.setFloat(a, partial);
            writeInt(a, "charge", charge);
        } catch (Throwable ignored) {
        }
    }
}
