package com.shatteredpixel.shatteredpixeldungeon.actors.buffs;

import com.shatteredpixel.shatteredpixeldungeon.actors.Char;
import com.shatteredpixel.shatteredpixeldungeon.sprites.CharSprite;
import com.shatteredpixel.shatteredpixeldungeon.ui.BuffIndicator;
import com.watabou.utils.Bundle;

/**
 * MOD: 时光沙漏（强化）——洒在敌人身上的沙粒。
 *
 * <p>被沙粒裹住的怪物会被凝滞：不行动、不能动，直到玩家离开这一层。
 * 离开时沙粒自动回到沙漏里（{@code HourglassSand.onLeavingLevel}），
 * 同时把当初抵押的那 1 点充能上限还回来。</p>
 */
public class SandStasis extends Buff {

    /** 洒下沙粒时所在的层（换层时据此回收） */
    public int depth = -1;

    /** 这份沙是否已经记账回收过（避免重复返还充能上限） */
    private boolean consumed = false;

    private static final String DEPTH = "depth";

    {
        type = buffType.NEGATIVE;
        announced = false;
    }

    @Override
    public boolean attachTo(Char target) {
        if (super.attachTo(target)) {
            ++target.paralysed;
            if (target.sprite != null) {
                target.sprite.add(CharSprite.State.PARALYSED);
            }
            target.next();
            return true;
        }
        return false;
    }

    @Override
    public boolean act() {
        spend(TICK);
        return true;
    }

    @Override
    public void detach() {
        // 不管是到期、被清掉还是随关卡回收，沙粒都要记账还回去
        consumeAndRefund();
        if (target != null) {
            if (target.paralysed > 0) {
                --target.paralysed;
            }
            if (target.sprite != null && target.paralysed == 0) {
                target.sprite.remove(CharSprite.State.PARALYSED);
            }
        }
        super.detach();
    }

    /**
     * 沙粒回收记账：只要这份沙还没还过，就把当初抵押的 1 点充能上限还回去。
     * 被凝滞的目标**被机制杀**（推下悬崖、巨型食人鱼被推到岸上）时也会走到这里，
     * 所以不会出现「对象没了、充能上限永久丢失」的情况。
     */
    public void consumeAndRefund() {
        if (consumed) {
            return;
        }
        consumed = true;
        try {
            com.shatteredpixel.shatteredpixeldungeon.items.artifacts.HourglassSand.refundSand(1);
        } catch (Throwable ignored) {
        }
    }

    @Override
    public int icon() {
        return BuffIndicator.TIME;
    }

    @Override
    public String name() {
        return "被沙粒凝滞";
    }

    @Override
    public String desc() {
        return "沙粒裹住了它。时间对它来说停了下来——直到你离开这一层。";
    }

    @Override
    public void storeInBundle(Bundle bundle) {
        super.storeInBundle(bundle);
        bundle.put(DEPTH, depth);
    }

    @Override
    public void restoreFromBundle(Bundle bundle) {
        super.restoreFromBundle(bundle);
        depth = bundle.getInt(DEPTH);
    }
}
