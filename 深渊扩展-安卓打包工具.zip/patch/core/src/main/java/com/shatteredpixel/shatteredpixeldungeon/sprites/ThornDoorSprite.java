package com.shatteredpixel.shatteredpixeldungeon.sprites;

import com.shatteredpixel.shatteredpixeldungeon.Dungeon;
import com.shatteredpixel.shatteredpixeldungeon.actors.mobs.ThornDoor;
import com.watabou.noosa.MovieClip;
import com.watabou.noosa.TextureFilm;

/**
 * MOD: 「被荆棘缠绕的木门」的贴图——只有**藤蔓**这一层（透明背景），
 * 门体交给引擎按朝向绘制（横板门 / 竖板门都能正确）。
 *
 * 另外这里兼任「每帧收尾」的锚点：投掷物是在投掷动画的回调里落地的（渲染线程），
 * 那时回合已经结束，所以只能每帧检查一次，把被 {@code pressCell()} 弹开的门按回去。
 */
public class ThornDoorSprite extends MobSprite {

    public ThornDoorSprite() {
        this.texture(ThornDoor.textureFor(Dungeon.level == null ? null : Dungeon.level.tilesTex()));
        TextureFilm frames = new TextureFilm(this.texture, 16, 16);

        this.idle = new MovieClip.Animation(1, true);
        this.idle.frames(frames, 0);

        this.run = this.idle;
        this.attack = this.idle;
        this.operate = this.idle;
        this.zap = this.idle;

        this.die = new MovieClip.Animation(1, false);
        this.die.frames(frames, 0);

        this.play(this.idle);
    }

    @Override
    public void update() {
        super.update();
        ThornDoor.police();
    }
}
