package com.shatteredpixel.shatteredpixeldungeon.windows;

import com.shatteredpixel.shatteredpixeldungeon.Dungeon;
import com.shatteredpixel.shatteredpixeldungeon.items.Item;
import com.shatteredpixel.shatteredpixeldungeon.items.artifacts.ArtifactTrial;
import com.shatteredpixel.shatteredpixeldungeon.items.artifacts.TalismanOfForesight;
import com.shatteredpixel.shatteredpixeldungeon.ui.InventoryPane;
import com.shatteredpixel.shatteredpixeldungeon.ui.ItemJournalButton;
import com.shatteredpixel.shatteredpixeldungeon.ui.RedButton;
import com.shatteredpixel.shatteredpixeldungeon.ui.Window;
import com.watabou.noosa.ui.Component;

import java.util.ArrayList;

/**
 * MOD: 与 4.0.2 的唯一差别是动作按钮的文案——
 * 先见护符通过试炼后，「探查」按钮会补一句「（并致盲敌人）」。
 * 其余布局逻辑与原版一致。
 */
public class WndUseItem extends WndInfoItem {

    private static final float BUTTON_HEIGHT = 16.0f;

    public Window owner;
    public Item item;

    public WndUseItem(final Window owner, final Item item) {
        super(item);
        this.owner = owner;
        this.item = item;

        float y = this.height;

        if (Dungeon.hero.isAlive() && Dungeon.hero.belongings.contains(item)) {
            y += 2.0f;

            ArrayList<RedButton> buttons = new ArrayList<>();
            for (final String action : item.actions(Dungeon.hero)) {
                // MOD: 虚空锁链只有在**通过试炼之后**才改成「起点→终点」两段式；
                // 试炼之前保留原版的一键施放，界面与原版一致。
                if (item instanceof com.shatteredpixel.shatteredpixeldungeon.items.artifacts.EtherealChains
                        && com.shatteredpixel.shatteredpixeldungeon.items.artifacts.EtherealChains.AC_CAST
                        .equals(action)
                        && com.shatteredpixel.shatteredpixeldungeon.items.artifacts.ArtifactTrial
                        .isEnhancedClass(com.shatteredpixel.shatteredpixeldungeon.items.artifacts
                                .EtherealChains.class)) {
                    continue;
                }
                // MOD: 强化后的先见护符（且不在试炼诅咒中），把「致盲」写进按钮文案
                String label = item.actionName(action, Dungeon.hero);
                if (item instanceof TalismanOfForesight
                        && TalismanOfForesight.AC_SCRY.equals(action)
                        && com.shatteredpixel.shatteredpixeldungeon.items.artifacts.TalismanVision.active()) {
                    label = label + "（并致盲敌人）";
                }

                RedButton btn = new RedButton(label, 8) {
                    @Override
                    protected void onClick() {
                        WndUseItem.this.hide();
                        if (owner != null && owner.parent != null) {
                            owner.hide();
                        }
                        if (Dungeon.hero.isAlive() && Dungeon.hero.belongings.contains(item)) {
                            item.execute(Dungeon.hero, action);
                        }
                        Item.updateQuickslot();
                        if (action.equals(item.defaultAction()) && item.usesTargeting && owner == null) {
                            InventoryPane.useTargeting();
                        }
                    }
                };
                btn.setSize(btn.reqWidth(), BUTTON_HEIGHT);
                buttons.add(btn);
                this.add(btn);
                if (action.equals(item.defaultAction())) {
                    btn.textColor(0xFFFF44);
                }
            }
            // MOD: 虚空锁链——两段式「起点 → 终点」牵引
            if (item instanceof com.shatteredpixel.shatteredpixeldungeon.items.artifacts.EtherealChains
                    && com.shatteredpixel.shatteredpixeldungeon.items.artifacts.ArtifactTrial
                    .isEnhancedClass(com.shatteredpixel.shatteredpixeldungeon.items.artifacts
                            .EtherealChains.class)
                    && com.shatteredpixel.shatteredpixeldungeon.items.artifacts.ChainPull
                    .chargeOf((com.shatteredpixel.shatteredpixeldungeon.items.artifacts.EtherealChains) item) >= 1
                    && !item.cursed) {
                RedButton pull = new RedButton("施放（两端）", 8) {
                    @Override
                    protected void onClick() {
                        WndUseItem.this.hide();
                        if (owner != null && owner.parent != null) {
                            owner.hide();
                        }
                        com.shatteredpixel.shatteredpixeldungeon.items.artifacts.ChainPull
                                .begin(Dungeon.hero);
                        Item.updateQuickslot();
                    }
                };
                pull.setSize(pull.reqWidth(), BUTTON_HEIGHT);
                buttons.add(pull);
                this.add(pull);
            }
            // MOD: 位面日晷（强化）—— 每层一次「校准」，把本层锁成白昼
            if (item instanceof com.shatteredpixel.shatteredpixeldungeon.items.trinkets.DimensionalSundial
                    && com.shatteredpixel.shatteredpixeldungeon.items.trinkets.TrinketPerks.canCalibrate()) {
                RedButton cal = new RedButton("校准晷影（本层白昼）", 8) {
                    @Override
                    protected void onClick() {
                        WndUseItem.this.hide();
                        if (owner != null && owner.parent != null) {
                            owner.hide();
                        }
                        com.shatteredpixel.shatteredpixeldungeon.items.trinkets.TrinketPerks
                                .calibrate(Dungeon.hero);
                        Item.updateQuickslot();
                    }
                };
                cal.setSize(cal.reqWidth(), BUTTON_HEIGHT);
                buttons.add(cal);
                this.add(cal);
            }
            // MOD: 混沌香炉（强化）—— 手动放出闷住的气体
            if (item instanceof com.shatteredpixel.shatteredpixeldungeon.items.trinkets.ChaoticCenser
                    && com.shatteredpixel.shatteredpixeldungeon.items.trinkets.TrinketPerks.censerActive()
                    && com.shatteredpixel.shatteredpixeldungeon.items.trinkets.TrinketPerks.censerStored() > 0) {
                RedButton gas = new RedButton("放出气体（存 "
                        + com.shatteredpixel.shatteredpixeldungeon.items.trinkets.TrinketPerks.censerStored()
                        + "）", 8) {
                    @Override
                    protected void onClick() {
                        WndUseItem.this.hide();
                        if (owner != null && owner.parent != null) {
                            owner.hide();
                        }
                        com.shatteredpixel.shatteredpixeldungeon.items.trinkets.TrinketPerks
                                .beginCenserRelease(Dungeon.hero);
                        Item.updateQuickslot();
                    }
                };
                gas.setSize(gas.reqWidth(), BUTTON_HEIGHT);
                buttons.add(gas);
                this.add(gas);
            }
            // MOD: 陷阱元件（强化到 4 级及以上）—— 把身边的陷阱收成晶柱
            if (item instanceof com.shatteredpixel.shatteredpixeldungeon.items.trinkets.TrapMechanism
                    && com.shatteredpixel.shatteredpixeldungeon.items.trinkets.TrinketPerks.trapSenseActive()) {
                RedButton collect = new RedButton("收纳陷阱", 8) {
                    @Override
                    protected void onClick() {
                        WndUseItem.this.hide();
                        if (owner != null && owner.parent != null) {
                            owner.hide();
                        }
                        com.shatteredpixel.shatteredpixeldungeon.items.trinkets.TrinketPerks
                                .collectTraps(Dungeon.hero);
                        Item.updateQuickslot();
                    }
                };
                collect.setSize(collect.reqWidth(), BUTTON_HEIGHT);
                buttons.add(collect);
                this.add(collect);
            }
            // MOD: 石化种子（强化到 4 级及以上）—— 吞下一枚符石/种子，下三次踩草必得它
            if (item instanceof com.shatteredpixel.shatteredpixeldungeon.items.trinkets.PetrifiedSeed
                    && com.shatteredpixel.shatteredpixeldungeon.items.trinkets.TrinketPerks.seedSealReady()) {
                RedButton seal = new RedButton("封存符石/种子", 8) {
                    @Override
                    protected void onClick() {
                        WndUseItem.this.hide();
                        if (owner != null && owner.parent != null) {
                            owner.hide();
                        }
                        com.shatteredpixel.shatteredpixeldungeon.items.trinkets.TrinketPerks
                                .beginSeal(Dungeon.hero);
                        Item.updateQuickslot();
                    }
                };
                seal.setSize(seal.reqWidth(), BUTTON_HEIGHT);
                buttons.add(seal);
                this.add(seal);
            }
            // MOD: 残魔余卷（强化到 4 级及以上）—— 撕下来贴到装备上，随机附魔
            if (item instanceof com.shatteredpixel.shatteredpixeldungeon.items.trinkets.ParchmentScrap
                    && com.shatteredpixel.shatteredpixeldungeon.items.trinkets.TrinketPerks.scrapReady()) {
                RedButton bind = new RedButton("贴附到装备（消耗本章）", 8) {
                    @Override
                    protected void onClick() {
                        WndUseItem.this.hide();
                        if (owner != null && owner.parent != null) {
                            owner.hide();
                        }
                        com.shatteredpixel.shatteredpixeldungeon.items.trinkets.TrinketPerks
                                .beginBind(Dungeon.hero);
                        Item.updateQuickslot();
                    }
                };
                bind.setSize(bind.reqWidth(), BUTTON_HEIGHT);
                buttons.add(bind);
                this.add(bind);
            }
            // MOD: 炼金工具箱（强化）—— 独特饰品可以花炼金能量升到 4~6 级
            if (com.shatteredpixel.shatteredpixeldungeon.items.trinkets.TrinketPerks
                    .canExtraUpgrade(item)) {
                final int cost = com.shatteredpixel.shatteredpixeldungeon.items.trinkets.TrinketPerks
                        .extraCostFor(item);
                RedButton up = new RedButton("强化饰物（" + cost + " 炼金能量）", 8) {
                    @Override
                    protected void onClick() {
                        WndUseItem.this.hide();
                        if (owner != null && owner.parent != null) {
                            owner.hide();
                        }
                        com.shatteredpixel.shatteredpixeldungeon.items.trinkets.TrinketPerks
                                .tryExtraUpgrade(item);
                        Item.updateQuickslot();
                    }
                };
                up.setSize(up.reqWidth(), BUTTON_HEIGHT);
                buttons.add(up);
                this.add(up);
            }
            // MOD: 丰饶之角（强化）——花 1 点充能吹 3 颗口哨糖
            if (item instanceof com.shatteredpixel.shatteredpixeldungeon.items.artifacts.HornOfPlenty
                    && com.shatteredpixel.shatteredpixeldungeon.items.artifacts.HornCandy.canCraft()) {
                RedButton candy = new RedButton("吹制口哨糖（1 充能 → 3 颗）", 8) {
                    @Override
                    protected void onClick() {
                        WndUseItem.this.hide();
                        if (owner != null && owner.parent != null) {
                            owner.hide();
                        }
                        com.shatteredpixel.shatteredpixeldungeon.items.artifacts.HornCandy
                                .craft(Dungeon.hero);
                        Item.updateQuickslot();
                    }
                };
                candy.setSize(candy.reqWidth(), BUTTON_HEIGHT);
                buttons.add(candy);
                this.add(candy);
            }
            // MOD: 时光沙漏（强化）——额外一个「洒沙」动作
            if (item instanceof com.shatteredpixel.shatteredpixeldungeon.items.artifacts.TimekeepersHourglass
                    && com.shatteredpixel.shatteredpixeldungeon.items.artifacts.HourglassSand.active()) {
                RedButton sand = new RedButton("洒沙（−1 充能上限）", 8) {
                    @Override
                    protected void onClick() {
                        WndUseItem.this.hide();
                        if (owner != null && owner.parent != null) {
                            owner.hide();
                        }
                        com.shatteredpixel.shatteredpixeldungeon.items.artifacts.HourglassSand
                                .cast(Dungeon.hero);
                        Item.updateQuickslot();
                    }
                };
                sand.setSize(sand.reqWidth(), BUTTON_HEIGHT);
                buttons.add(sand);
                this.add(sand);
            }
            y = layoutButtons(buttons, this.width, y);

            ItemJournalButton btn = new ItemJournalButton(item, this);
            btn.setRect(this.width - 16, 0.0f, 16.0f, 16.0f);
            this.add(btn);
        }

        this.resize(this.width, (int) y);
    }

    private static float layoutButtons(ArrayList<RedButton> buttons, float width, float y) {
        ArrayList<RedButton> curRow = new ArrayList<>();
        float widthLeftThisRow = width;

        while (!buttons.isEmpty()) {
            RedButton btn = buttons.get(0);
            widthLeftThisRow -= btn.width();

            if (curRow.isEmpty()) {
                curRow.add(btn);
                buttons.remove(btn);
            } else if ((widthLeftThisRow -= 1.0f) >= 0.0f) {
                curRow.add(btn);
                buttons.remove(btn);
            }

            if (buttons.isEmpty() || widthLeftThisRow <= 0.0f || curRow.size() >= 3) {
                widthLeftThisRow = width - (curRow.size() - 1.0f);
                for (RedButton b : curRow) {
                    widthLeftThisRow -= b.width();
                }

                while (widthLeftThisRow > 0.0f) {
                    ArrayList<RedButton> shortest = new ArrayList<>();
                    RedButton secondShortest = null;
                    for (RedButton b : curRow) {
                        if (shortest.isEmpty()) {
                            shortest.add(b);
                            continue;
                        }
                        if (b.width() < shortest.get(0).width()) {
                            secondShortest = shortest.get(0);
                            shortest.clear();
                            shortest.add(b);
                            continue;
                        }
                        if (b.width() == shortest.get(0).width()) {
                            shortest.add(b);
                            continue;
                        }
                        if (secondShortest != null && secondShortest.width() > b.width()) {
                            secondShortest = b;
                        }
                    }

                    float widthToGrow;
                    if (secondShortest == null) {
                        widthToGrow = widthLeftThisRow / shortest.size();
                        widthLeftThisRow = 0.0f;
                    } else {
                        widthToGrow = secondShortest.width() - shortest.get(0).width();
                        if (widthToGrow * shortest.size() >= widthLeftThisRow) {
                            widthToGrow = widthLeftThisRow / shortest.size();
                            widthLeftThisRow = 0.0f;
                        } else {
                            widthLeftThisRow -= widthToGrow * shortest.size();
                        }
                    }
                    for (RedButton toGrow : shortest) {
                        toGrow.setRect(0.0f, 0.0f, toGrow.width() + widthToGrow, toGrow.height());
                    }
                }

                float x = 0.0f;
                for (RedButton b : curRow) {
                    b.setRect(x, y, b.width(), b.height());
                    x += b.width() + 1.0f;
                }
                y += BUTTON_HEIGHT + 1.0f;
                widthLeftThisRow = width;
                curRow.clear();
            }
        }
        return y - 1.0f;
    }
}
