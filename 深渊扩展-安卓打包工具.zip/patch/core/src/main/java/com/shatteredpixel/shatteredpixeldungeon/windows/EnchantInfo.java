/*
 * MOD: 附魔 / 诅咒 的说明文本
 *
 * 内容分三块：
 *   1) 类型与稀有度：直接读 Weapon.Enchantment / Armor.Glyph 的 common/uncommon/rare/curses 数组
 *      与 typeChances(50/40/10)。
 *   2) 效果：游戏自带 desc()（中文语言包已完整翻译）。
 *   3) 触发与公式：依据 4.0.2 反编译源码里各附魔的 proc() 手写整理。
 *      记号：L = 装备等级(buffedLvl)，M = 触发倍率(procChanceMultiplier，天赋/词条加成，通常为 1)，
 *            P = max(1, 触发率)（游戏里统一用这个 powerMulti 放大效果）。
 *
 * 注意：公式与游戏版本绑定。游戏更新后需要按新版 proc() 复核。
 */
package com.shatteredpixel.shatteredpixeldungeon.windows;

import com.shatteredpixel.shatteredpixeldungeon.items.armor.Armor;
import com.shatteredpixel.shatteredpixeldungeon.items.weapon.Weapon;

import java.util.Arrays;

public class EnchantInfo {

    /** 组装完整说明文本。 */
    public static String describe(Class<?> cls) {
        StringBuilder sb = new StringBuilder();

        sb.append("【类型】").append(isCurse(cls) ? "诅咒" : "附魔");
        String rarity = rarityLabel(cls);
        if (!rarity.isEmpty()) {
            sb.append("　【稀有度】").append(rarity);
        }
        sb.append("\n\n【效果】\n").append(descOf(cls));
        sb.append("\n\n【触发与公式】\n").append(formula(cls));
        sb.append("\n\n——\nL = 装备等级，M = 触发倍率（天赋/词条加成，默认 1），")
          .append("P = max(1, 触发率)。数值依据 4.0.2 源码整理。");
        return sb.toString();
    }

    // ------------------------------------------------------------------
    // 稀有度
    // ------------------------------------------------------------------

    static boolean isCurse(Class<?> cls) {
        return Arrays.asList(Armor.Glyph.curses).contains(cls)
                || Arrays.asList(Weapon.Enchantment.curses).contains(cls);
    }

    private static String rarityLabel(Class<?> cls) {
        float[] tc = null;
        if (Arrays.asList(Armor.Glyph.common).contains(cls)
                || Arrays.asList(Weapon.Enchantment.common).contains(cls)) {
            tc = Armor.Glyph.typeChances;
            return "普通（" + pct(tc) + " 权重）";
        }
        if (Arrays.asList(Armor.Glyph.uncommon).contains(cls)
                || Arrays.asList(Weapon.Enchantment.uncommon).contains(cls)) {
            tc = Armor.Glyph.typeChances;
            return "少见（" + pct(tc, 1) + " 权重）";
        }
        if (Arrays.asList(Armor.Glyph.rare).contains(cls)
                || Arrays.asList(Weapon.Enchantment.rare).contains(cls)) {
            tc = Armor.Glyph.typeChances;
            return "稀有（" + pct(tc, 2) + " 权重）";
        }
        return isCurse(cls) ? "诅咒（必定为诅咒附魔）" : "";
    }

    private static String pct(float[] arr) {
        return pct(arr, 0);
    }

    private static String pct(float[] arr, int idx) {
        if (arr == null || idx >= arr.length) {
            return "?";
        }
        return Math.round(arr[idx]) + "%";
    }

    private static String descOf(Class<?> cls) {
        try {
            Object inst = cls.getDeclaredConstructor().newInstance();
            if (inst instanceof Armor.Glyph) {
                return ((Armor.Glyph) inst).desc();
            }
            if (inst instanceof Weapon.Enchantment) {
                return ((Weapon.Enchantment) inst).desc();
            }
        } catch (Throwable ignored) {
        }
        return "（暂无描述）";
    }

    // ------------------------------------------------------------------
    // 公式表
    // ------------------------------------------------------------------

    private static final String PASSIVE = "被动生效，没有概率触发判定（效果由装备属性或其它逻辑实现）。";

    private static String formula(Class<?> cls) {
        String n = cls.getSimpleName();
        switch (n) {
            // ---------------- 武器附魔 ----------------
            case "Blazing":
                return "触发率 = (L+1)/(L+3) × M\n"
                        + "触发后：若目标未燃烧，则点燃 8 回合（P-1 的一部分换算成伤害）\n"
                        + "额外灼烧伤害 = round( rand(1, 3+深度/4) × 0.67 × P )\n"
                        + "其中 深度 = Dungeon.scalingDepth()";
            case "Chilling":
                return "触发率 = (L+1)/(L+4) × M\n"
                        + "冰冻时长 = 3 × P 回合；已有冰冻时最多补到 6 × P 回合";
            case "Kinetic":
                return "无概率判定：命中时把此前积累的「守恒伤害」加入本次伤害，并记录本次伤害作为后续积累。";
            case "Shocking":
                return "触发率 = 1/3 × M\n"
                        + "对 2 格内的其他敌人各造成 本次伤害 × 0.5 × P";
            case "Venomous":
                return "触发率 = 1/3 × M\n"
                        + "中毒时长 += P × (L/2 + 3)";
            case "Blocking":
                return "触发率 = (L+4)/(L+40) × M\n"
                        + "获得护盾 = P × (2 + L)";
            case "Blooming":
                return "触发率 = (L+1)/(L+3) × M\n"
                        + "生成植物数量 = round( (1.5 + 0.1 × L) × P )，优先在目标周围、其次在攻击者周围";
            case "Eldritch":
                return "触发率 = (L+1)/(L+4) × M\n"
                        + "对视野内的其他敌人施加恐惧 5 × P 回合；若目标是英雄则改为眩晕 5 回合";
            case "Elastic":
                return "触发率 = (L+1)/(L+5) × M\n"
                        + "把目标击退 2 × P 格";
            case "Lucky":
                return "触发率 = (L+4)/(L+40) × M\n"
                        + "给目标挂上 LuckProc（等效戒指等级 = -10 + round(5 × P)）；未触发则移除";
            case "Projecting":
                return PASSIVE;
            case "Unstable":
                return "无固定触发：每次命中随机选一种附魔并执行其 proc()，再把此前的「守恒伤害」加回去。";
            case "Vorpal":
                return "触发率 = 0.25 × M\n"
                        + "触发后记录处决加成（VorpalTracker，powerMulti = P），用于处决低血量目标";
            case "Corrupting":
                return "触发率 = (L+5)/(L+20) × M\n"
                        + "条件：攻击者为友方、目标为可腐化的生物且未被腐化、未免疫\n"
                        + "触发后挂 CorruptingTracker（powerMulti = P）";
            case "Crystal":
                return "无触发判定：每次命中额外造成 ceil(伤害 × 0.33 × M) 魔法伤害\n"
                        + "同时消耗耐久，平均可用次数 = 50 - min(20, 20×L/6)";
            case "Grim":
                return "触发率上限 = (0.50 + 0.05 × L) × M\n"
                        + "给攻击者挂 GrimTracker（处决几率上限），对免疫目标无效";
            case "Vampiric":
                return "触发率 = (0.05 + 0.25 × 已损失生命占比) × M\n"
                        + "回复量 = round( 伤害 × 0.5 × P )，上限为已损失生命";

            // ---------------- 武器诅咒 ----------------
            case "Annoying":
                return "触发率 = 0.05 × M\n触发后：全场敌人被吸引到攻击者位置";
            case "Dazzling":
                return "触发率 = 0.10 × M\n"
                        + "使视野内敌人致盲（攻击者自身 10 回合，其他 5 回合）";
            case "Displacing":
                return "触发率 = 1/12 × M\n触发后随机传送目标（不可移动目标免疫）；目标若在追击则转为游荡";
            case "Explosive":
                return "每次命中耐久减少 rand(0,10) × M\n"
                        + "耐久 ≤0 时在目标附近爆炸，并重置 +100 耐久\n"
                        + "耐久跨过 50 / 10 时会有「发烫 / 炽热」预警";
            case "Friendly":
                return "触发率 = 0.10 × M\n"
                        + "攻击者魅惑 10 回合、目标魅惑 5 回合（互相）\n"
                        + "攻击者处于对目标的魅惑状态时，本次伤害归零";
            case "Polarized":
                return "触发率 = 0.50 × M\n"
                        + "触发 → 本次伤害 × 1.5\n"
                        + "未触发 → 本次伤害归零";
            case "Pressurized":
                return "触发率 = 0.125 × M\n触发后在目标脚下生成喷泉陷阱（GeyserTrap）";
            case "Sacrificial":
                return "触发率 = 0.10 × M\n"
                        + "若 rand < (当前生命/最大生命)² × 最大生命 / 8，则自身流血该数值（至少 1）";
            case "Wayward":
                return "触发率 = 0.25 × M\n"
                        + "若当前有 WaywardBuff 则移除，否则给自己挂 10 回合 WaywardBuff";
            case "Wondrous":
                return "触发率 = 0.125 × M\n"
                        + "效果从诅咒法杖的 32 种里抽取：先按档位抽（60%/30%/9%/1%），"
                        + "档内等概率，抽到无效效果会自动重抽\n"
                        + "若佩戴「奇迹树脂」饰物，有一定概率把结果变成无害/有益（positiveOnly）\n"
                        + "\n" + wondrousEffects();

            // ---------------- 护甲符文 ----------------
            case "Affection":
                return "触发率 = (L+3)/(L+20) × M\n魅惑攻击者 round(10 × P) 回合";
            case "AntiMagic":
                return PASSIVE;
            case "Brimstone":
                return PASSIVE;
            case "Camouflage":
                return PASSIVE;
            case "Entanglement":
                return "触发率 = 0.25 × M\n获得大地护甲 = (5 + 2 × L) × P";
            case "Flow":
                return PASSIVE;
            case "Obfuscation":
                return PASSIVE;
            case "Potential":
                return "触发率 = (L+1)/(L+6) × M\n触发后按 P 为法杖充能（返回充能的法杖数量）";
            case "Repulsion":
                return "触发率 = (L+1)/(L+5) × M（仅当攻击者与自己相邻时判定）\n"
                        + "把攻击者沿反方向击退 2 × P 格";
            case "Stone":
                return "无概率判定：按命中率折算伤害\n"
                        + "命中率 h 由双方 accuracy/evasion 计算，再经 h = gate(0.25, (1+3h)/4, 1) 压缩\n"
                        + "最终伤害 = ceil( 伤害 × h )";
            case "Swiftness":
                return PASSIVE;
            case "Thorns":
                return "触发率 = (L+2)/(L+12) × M\n"
                        + "使攻击者流血 (4 + L) × P";
            case "Viscosity":
                return "无概率判定：记录护甲等级用于延迟伤害（ViscosityTracker），按等级分摊伤害";

            // ---------------- 护甲诅咒 ----------------
            case "AntiEntropy":
                return "触发率 = 0.125 × M\n点燃自身（水中不点燃），并把周围 8 格变为冰面";
            case "Bulk":
                return PASSIVE;
            case "Corrosion":
                return "触发率 = 0.10 × M\n使自身周围 3×3 范围内的角色中毒（黏液）10 回合";
            case "Displacement":
                return "触发率 = 0.05 × M\n随机传送自己，且本次伤害归零";
            case "Metabolism":
                return "触发率 = 1/6 × M\n"
                        + "回复 min(4, 已损失生命)，同时消耗 4 点饥饿（饥饿中不触发）";
            case "Multiplicity":
                return "触发率 = 0.05 × M\n在周围空格生成复制体（英雄可能生成镜像，敌人复制自身）";
            case "Overgrowth":
                return "触发率 = 0.05 × M\n在脚下生成并激活一株随机植物";
            case "Stench":
                return "触发率 = 0.125 × M\n在脚下生成毒气云";
            default:
                return "（该附魔没有整理公式）";
        }
    }

    /** 奇迹诅咒可触发的全部 32 种诅咒法杖效果，按触发概率从高到低排列。 */
    private static String wondrousEffects() {
        // 概率 = 档位概率 / 8
        return "【触发效果（按概率从高到低）】\n"
                + "7.5%　灼烧与冰冻：随机一方被点燃、另一方被冰冻 10 回合（无害模式不会烧到自己）\n"
                + "7.5%　草木滋生：落点生成再生草丛 30 回合\n"
                + "7.5%　随机传送：随机传送目标；没有目标时可能传送自己\n"
                + "7.5%　随机毒气：落点生成混淆毒气 / 剧毒毒气 / 麻痹毒气之一\n"
                + "7.5%　随机陷阱：落点触发烈焰 / 寒冰 / 电击陷阱之一\n"
                + "7.5%　泡泡：只冒泡，没有实际效果\n"
                + "7.5%　随机法杖：随机一根法杖的效果（等级跟随原法杖）\n"
                + "7.5%　自身黏液：以自己为中心 2 格内所有生物附上黏液 20 回合\n"
                + "3.75%　随机植物：落点种下一株随机植物\n"
                + "3.75%　生命转移：一方受 2×深度 伤害，另一方回复一半\n"
                + "3.75%　召唤爆炸：落点引爆一枚召唤炸弹\n"
                + "3.75%　闪电链：以自己为中心 3×3 放电，波及范围内所有生物\n"
                + "3.75%　喷泉：落点触发喷泉陷阱，击退周围生物\n"
                + "3.75%　召唤羊群：落点触发羊群陷阱\n"
                + "3.75%　漂浮：使目标（或自己）漂浮 20 回合\n"
                + "3.75%　警报：吸引全场怪物；无害模式下改为生成保护你的挑战领域\n"
                + "1.125%　变羊术：把目标（非英雄/非 BOSS/非小 BOSS）变成羊 10 回合\n"
                + "1.125%　诅咒装备：诅咒英雄的装备；无害模式改为给目标施放虚弱 30 回合\n"
                + "1.125%　跨层传送：把英雄随机传送回 10 层以内；不满足条件时仅随机传送\n"
                + "1.125%　召唤怪物：落点触发召唤陷阱；无害模式改为生成 2 个分身\n"
                + "1.125%　火球：落点 3 格视野内全体燃烧，受 (5+深度)~(10+2×深度) 伤害，可燃地面起火\n"
                + "1.125%　五彩锥：朝落点方向释放 90° 半径 8 的锥形随机元素攻击\n"
                + "1.125%　群体无敌：全场生物获得无敌 10 回合 + 祝福 30 回合\n"
                + "1.125%　石化：自己进入时间停滞 100 回合\n"
                + "0.125%　森林大火：全图长满草，并在随机位置起火\n"
                + "0.125%　金色拟态：落点生成一只金色拟态怪\n"
                + "0.125%　中止/重试/失败：彩蛋，仅英文语言下弹出「自毁」对话框，其它语言下重抽\n"
                + "0.125%　随机变形：把触发的道具变成别的道具；无害模式可自选目标\n"
                + "0.125%　英雄变形：英雄获得伪装（外观改变）\n"
                + "0.125%　超新星：落点生成膨胀的能量球，随后大范围爆炸（无害模式不伤友方）\n"
                + "0.125%　塌陷：英雄周围 5 格地面塌陷，触发坠落\n"
                + "0.125%　重力混乱：全场重力方向随机变化，持续一段时间（无害模式不影响你）";
    }
}
