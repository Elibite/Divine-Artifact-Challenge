package com.shatteredpixel.shatteredpixeldungeon.items.trinkets;

import com.shatteredpixel.shatteredpixeldungeon.Dungeon;
import com.shatteredpixel.shatteredpixeldungeon.actors.Char;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.Buff;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.ChampionEnemy;
import com.shatteredpixel.shatteredpixeldungeon.actors.hero.Hero;
import com.shatteredpixel.shatteredpixeldungeon.actors.mobs.Mob;
import com.shatteredpixel.shatteredpixeldungeon.items.Item;
import com.shatteredpixel.shatteredpixeldungeon.items.artifacts.AlchemistsToolkit;
import com.shatteredpixel.shatteredpixeldungeon.items.artifacts.ArtifactTrial;
import com.shatteredpixel.shatteredpixeldungeon.messages.Messages;
import com.shatteredpixel.shatteredpixeldungeon.utils.GLog;

/**
 * MOD: 炼金工具箱强化 —— 独特饰品的「新等级」。
 *
 * <p>通过试炼后，四件由魔能触媒做出来的独特饰品可以花炼金能量升到 4~6 级
 * （原版最多 3 级）。效果绑在**饰品等级**上，而不是工具箱上：
 * 只要饰品在身上、等级够，效果就生效，带不带工具箱都一样。</p>
 */
public class TrinketPerks {

    /** 允许吃「额外等级」的独特饰品 */
    private static final Class<? extends Trinket>[] UNIQUE = new Class[]{
            RatSkull.class, ParchmentScrap.class, PetrifiedSeed.class, ExoticCrystals.class,
            MossyClump.class, ThirteenLeafClover.class, TrapMechanism.class, MimicTooth.class, WondrousResin.class, EyeOfNewt.class, SaltCube.class,
            VialOfBlood.class, ChaoticCenser.class, FerretTuft.class,
            CrackedSpyglass.class, DimensionalSundial.class, ShardOfOblivion.class
    };

    /** 原版上限 3 级，强化后最多 6 级 */
    public static final int MAX_LEVEL = 6;

    /** 炼金工具箱是否通过试炼 */
    public static boolean toolkitEnhanced() {
        return ArtifactTrial.isEnhancedClass(AlchemistsToolkit.class);
    }

    /** 这枚饰品是不是「独特饰品」 */
    public static boolean isUnique(Item item) {
        if (!(item instanceof Trinket)) {
            return false;
        }
        for (Class<? extends Trinket> c : UNIQUE) {
            if (c.isInstance(item)) {
                return true;
            }
        }
        return false;
    }

    /** 身上的某个饰品的等级（不在身上返回 -1） */
    public static int levelOf(Class<? extends Trinket> type) {
        if (Dungeon.hero == null || Dungeon.hero.belongings == null) {
            return -1;
        }
        Trinket t = Dungeon.hero.belongings.getItem(type);
        return t == null ? -1 : t.buffedLvl();
    }

    /**
     * 强化等级 = 超过原版上限（4 级及以上），且**神器挑战必须开着**。
     * 4~6 级本来就只能靠「强化炼金工具箱」升上去，这里再兜一道，
     * 保证关掉挑战后所有饰品强化效果一并失效。
     */
    public static boolean isEnhancedLevel(Class<? extends Trinket> type) {
        if (!com.shatteredpixel.shatteredpixeldungeon.ModContent.enabled()) {
            return false;
        }
        if (!Dungeon.isChallenged(com.shatteredpixel.shatteredpixeldungeon.Challenges.ARTIFACT)) {
            return false;
        }
        int lvl = levelOf(type);
        return lvl >= 4;
    }

    /** 额外等级的炼金能量价格 */
    public static int extraCost(int currentLevel) {
        switch (currentLevel) {
            case 3:
                return 40;
            case 4:
                return 60;
            case 5:
                return 80;
            default:
                return -1;
        }
    }

    /**
     * 按物品算价格：凝血试管**只能额外升一次**（3→4），
     * 其余独特饰品可以升到 6 级。
     */
    public static int extraCostFor(Item item) {
        if (item instanceof VialOfBlood || item instanceof CrackedSpyglass) {
            // 这两件只能额外升一次（3 → 4）
            return item.buffedLvl() == 3 ? 40 : -1;
        }
        return extraCost(item.buffedLvl());
    }

    /** 这枚饰品现在还能不能额外升级 */
    public static boolean canExtraUpgrade(Item item) {
        if (!toolkitEnhanced() || !isUnique(item)) {
            return false;
        }
        // 升级这一步要真的把强化工具箱装在神器位上（效果本身不要求）
        if (Dungeon.hero == null || Dungeon.hero.belongings == null
                || !(Dungeon.hero.belongings.artifact() instanceof AlchemistsToolkit)) {
            return false;
        }
        return extraCostFor(item) > 0;
    }

    /** 花炼金能量升一级（4→5→6） */
    public static boolean tryExtraUpgrade(Item item) {
        if (!canExtraUpgrade(item)) {
            return false;
        }
        int cost = extraCostFor(item);
        if (Dungeon.energy < cost) {
            GLog.w("炼金能量不够（要 " + cost + "，你有 " + Dungeon.energy + "）。");
            return false;
        }
        Dungeon.energy -= cost;
        item.upgrade();
        item.levelKnown = true;
        GLog.p("「" + item.name() + "」被炼金能量浸透，升到了 " + item.buffedLvl() + " 级。");
        Item.updateQuickslot();
        return true;
    }

    // ============================================================
    // 巨鼠头骨（强化）：挑战生成的精英怪保持中立
    // ============================================================

    /** 强化巨鼠头骨在身上？ */
    public static boolean championsPacified() {
        return isEnhancedLevel(RatSkull.class);
    }

    /** 这头怪是不是被「精英强敌」挑战强化出来的精英 */
    public static boolean isChampion(Mob mob) {
        return mob != null && mob.buff(ChampionEnemy.class) != null;
    }

    /**
     * 精英是否该放过玩家（强化巨鼠头骨：它们对你保持中立，不主动进攻）。
     */
    public static boolean sparesHero(Mob mob) {
        return championsPacified() && isChampion(mob)
                && mob.alignment == Char.Alignment.ENEMY;
    }

    // ============================================================
    // 残魔余卷（强化）：撕下来贴到装备上，随机附魔
    // ============================================================

    /** 强化的残魔余卷在身上？ */
    public static boolean scrapReady() {
        if (!isEnhancedLevel(ParchmentScrap.class)) {
            return false;
        }
        return Dungeon.hero != null && Dungeon.hero.belongings != null
                && Dungeon.hero.belongings.getItem(ParchmentScrap.class) != null;
    }

    /** 打开「选一件装备」的窗口 */
    public static void beginBind(final Hero hero) {
        if (hero == null || hero.belongings == null || !scrapReady()) {
            return;
        }
        final java.util.ArrayList<Item> candidates = new java.util.ArrayList<>();
        Object equippedWeaponRaw = hero.belongings.weapon();
        Item equippedWeapon = equippedWeaponRaw instanceof Item ? (Item) equippedWeaponRaw : null;
        Item equippedArmor = hero.belongings.armor();
        if (equippedWeapon != null && canEnchant(equippedWeapon)) {
            candidates.add(equippedWeapon);
        }
        if (equippedArmor != null && canEnchant(equippedArmor)) {
            candidates.add(equippedArmor);
        }
        for (Item it : hero.belongings.backpack.items) {
            if (it != null && canEnchant(it) && !candidates.contains(it)) {
                candidates.add(it);
            }
        }
        if (candidates.isEmpty()) {
            GLog.w("你身上没有可以贴附的武器、护甲或投掷武器。");
            return;
        }
        final int max = Math.min(candidates.size(), 9);
        final String[] labels = new String[max];
        for (int i = 0; i < max; i++) {
            labels[i] = candidates.get(i).name() + (i == 0 && candidates.get(0) == equippedWeapon ? "（装备中）" : "");
        }
        com.watabou.noosa.Game.runOnRenderThread(new com.watabou.utils.Callback() {
            @Override
            public void call() {
                com.shatteredpixel.shatteredpixeldungeon.scenes.GameScene.show(
                        new com.shatteredpixel.shatteredpixeldungeon.windows.WndOptions(
                                new com.shatteredpixel.shatteredpixeldungeon.sprites.ItemSprite(
                                        new ParchmentScrap()),
                                "残魔余卷", "选一件装备，把这页残卷贴上去（会随机附魔）", labels) {
                            @Override
                            protected void onSelect(int index) {
                                if (index >= 0 && index < candidates.size()) {
                                    applyBind(hero, candidates.get(index));
                                }
                            }
                        });
            }
        });
    }

    private static boolean canEnchant(Item item) {
        return item instanceof com.shatteredpixel.shatteredpixeldungeon.items.weapon.Weapon
                || item instanceof com.shatteredpixel.shatteredpixeldungeon.items.armor.Armor;
    }

    /** 消耗残魔余卷，给目标随机附魔 */
    private static void applyBind(Hero hero, Item target) {
        if (hero == null || hero.belongings == null) {
            return;
        }
        ParchmentScrap scrap = hero.belongings.getItem(ParchmentScrap.class);
        if (scrap == null) {
            GLog.w("残魔余卷已经用掉了。");
            return;
        }
        String enchName;
        if (target instanceof com.shatteredpixel.shatteredpixeldungeon.items.weapon.Weapon) {
            com.shatteredpixel.shatteredpixeldungeon.items.weapon.Weapon.Enchantment e
                    = com.shatteredpixel.shatteredpixeldungeon.items.weapon.Weapon.Enchantment.random();
            ((com.shatteredpixel.shatteredpixeldungeon.items.weapon.Weapon) target).enchant(e);
            enchName = com.shatteredpixel.shatteredpixeldungeon.messages.Messages.titleCase(e.name());
        } else if (target instanceof com.shatteredpixel.shatteredpixeldungeon.items.armor.Armor) {
            com.shatteredpixel.shatteredpixeldungeon.items.armor.Armor.Glyph g
                    = com.shatteredpixel.shatteredpixeldungeon.items.armor.Armor.Glyph.random();
            ((com.shatteredpixel.shatteredpixeldungeon.items.armor.Armor) target).inscribe(g);
            enchName = com.shatteredpixel.shatteredpixeldungeon.messages.Messages.titleCase(g.name());
        } else {
            GLog.w("只能贴附在武器、护甲或投掷武器上。");
            return;
        }
        scrap.detachAll(hero.belongings.backpack);
        GLog.p("残魔余卷缠上了「" + target.name() + "」——" + enchName + "。");
        Item.updateQuickslot();
    }

    // ============================================================
    // 石化种子（强化）：吞下一枚符石/种子，下 3 次踩草必得它
    // ============================================================

    /** 强化石化种子在身上？ */
    public static boolean seedSealReady() {
        return isEnhancedLevel(PetrifiedSeed.class);
    }

    /** 强化后踩高草的掉率加成（+25%） */
    public static float grassLootBonus() {
        return seedSealReady() ? 1.25f : 1.0f;
    }

    /** 打开「选一枚符石或种子」的窗口 */
    public static void beginSeal(final Hero hero) {
        if (hero == null || hero.belongings == null || !seedSealReady()) {
            return;
        }
        final java.util.ArrayList<Item> candidates = new java.util.ArrayList<>();
        boolean sawForbidden = false;
        for (Item it : hero.belongings.backpack.items) {
            if (it == null) {
                continue;
            }
            if (it instanceof com.shatteredpixel.shatteredpixeldungeon.items.stones.StoneOfEnchantment) {
                // 附魔符石太贵重，石化种子吞不下
                sawForbidden = true;
                continue;
            }
            if (it instanceof com.shatteredpixel.shatteredpixeldungeon.plants.Plant.Seed
                    || it instanceof com.shatteredpixel.shatteredpixeldungeon.items.stones.Runestone) {
                candidates.add(it);
            }
        }
        if (candidates.isEmpty()) {
            if (sawForbidden) {
                GLog.w("石化种子不肯吞下附魔符石——那东西太贵重了，它保证不了。");
            } else {
                GLog.w("你身上没有可以让它封存的符石或种子。");
            }
            return;
        }
        final int max = Math.min(candidates.size(), 9);
        final String[] labels = new String[max];
        for (int i = 0; i < max; i++) {
            labels[i] = candidates.get(i).name();
        }
        com.watabou.noosa.Game.runOnRenderThread(new com.watabou.utils.Callback() {
            @Override
            public void call() {
                com.shatteredpixel.shatteredpixeldungeon.scenes.GameScene.show(
                        new com.shatteredpixel.shatteredpixeldungeon.windows.WndOptions(
                                new com.shatteredpixel.shatteredpixeldungeon.sprites.ItemSprite(
                                        new PetrifiedSeed()),
                                "石化种子", "让它吞下一枚符石或种子——接下来三次踩草，掉的一定是它",
                                labels) {
                            @Override
                            protected void onSelect(int index) {
                                if (index >= 0 && index < candidates.size()) {
                                    applySeal(hero, candidates.get(index));
                                }
                            }
                        });
            }
        });
    }

    private static void applySeal(Hero hero, Item item) {
        if (item instanceof com.shatteredpixel.shatteredpixeldungeon.items.stones.StoneOfEnchantment) {
            GLog.w("石化种子不肯吞下附魔符石——那东西太贵重了，它保证不了。");
            return;
        }
        com.shatteredpixel.shatteredpixeldungeon.actors.buffs.SeedSeal seal
                = com.shatteredpixel.shatteredpixeldungeon.actors.buffs.SeedSeal.ensure();
        if (seal == null) {
            return;
        }
        seal.itemClass = item.getClass().getName();
        seal.remaining = 3;
        if (item.quantity() > 1) {
            item.quantity(item.quantity() - 1);
        } else {
            item.detachAll(hero.belongings.backpack);
        }
        GLog.p("石化种子把那枚「" + item.name() + "」吞了下去——接下来三次踩草，它会还给你的。");
        Item.updateQuickslot();
    }

    /** 有没有封存着东西 */
    public static boolean hasSealedSeed() {
        com.shatteredpixel.shatteredpixeldungeon.actors.buffs.SeedSeal seal
                = com.shatteredpixel.shatteredpixeldungeon.actors.buffs.SeedSeal.get();
        return seal != null && seal.remaining > 0 && seal.itemClass != null;
    }

    /** 取出封存的那枚（同时扣一次次数，扣完就清掉） */
    public static Item takeSealedSeed() {
        com.shatteredpixel.shatteredpixeldungeon.actors.buffs.SeedSeal seal
                = com.shatteredpixel.shatteredpixeldungeon.actors.buffs.SeedSeal.get();
        if (seal == null || seal.remaining <= 0 || seal.itemClass == null) {
            return null;
        }
        Item made = null;
        try {
            Class<?> c = Class.forName(seal.itemClass);
            Object o = c.getDeclaredConstructor().newInstance();
            if (o instanceof Item) {
                made = (Item) o;
            }
        } catch (Throwable ignored) {
        }
        seal.remaining--;
        if (seal.remaining <= 0) {
            seal.itemClass = null;
            seal.detach();
        }
        return made;
    }

    // ============================================================
    // 奇异能晶（强化）：化作催化剂 —— 每次炼金返还 2 点能量
    // ============================================================

    /** 强化奇异能晶在身上？ */
    public static boolean crystalsCatalyst() {
        return isEnhancedLevel(ExoticCrystals.class);
    }

    private static int lastCrafted = -1;
    private static int lastEnergy = -1;

    /**
     * 每回合调用：比对「本局合成件数」和「当前能量」，
     * 每合成一件且确实花了至少 2 点能量，就返还 2 点。
     */
    public static void watchAlchemy() {
        int crafted = com.shatteredpixel.shatteredpixeldungeon.Statistics.itemsCrafted;
        if (!crystalsCatalyst()) {
            lastCrafted = crafted;
            lastEnergy = Dungeon.energy;
            return;
        }
        if (lastCrafted < 0) {
            lastCrafted = crafted;
            lastEnergy = Dungeon.energy;
            return;
        }
        if (crafted > lastCrafted) {
            int brews = crafted - lastCrafted;
            int spent = lastEnergy - Dungeon.energy;
            int refund = 0;
            for (int i = 0; i < brews; i++) {
                if (spent >= 2) {
                    refund += 2;
                    spent -= 2;
                }
            }
            if (refund > 0) {
                Dungeon.energy += refund;
                GLog.i("奇异能晶从炼金残渣里吸回了一点能量（+" + refund + "）。");
            }
        }
        lastCrafted = crafted;
        lastEnergy = Dungeon.energy;
    }

    // ============================================================
    // 苔藓丛簇（强化）：借来女猎手的「复春步伐」+ 苔藓生风
    // ============================================================

    /** 强化苔藓丛簇在身上？ */
    public static boolean mossyActive() {
        return isEnhancedLevel(MossyClump.class);
    }

    /** 「复春步伐」的冷却（回合）：比原版长，7 回合 */
    public static final float REJUVENATING_COOLDOWN = 7f;

    /**
     * 每回合调用：复刻女猎手二层「复春步伐」——踩在草地/余烬上时让草重新长回来，
     * 冷却用原版的 {@code RejuvenatingStepsCooldown} 挂在英雄身上，
     * 所以**取下饰品也不会清掉冷却**（防止反复穿戴刷新）。
     */
    public static void mossyTick() {
        Hero hero = Dungeon.hero;
        if (hero == null || Dungeon.level == null) {
            return;
        }
        if (!mossyActive()) {
            return;
        }
        int pos = hero.pos;
        int terrain = Dungeon.level.map[pos];

        // 走在水面上：持续获得「苔藓生风」
        if (terrain == com.shatteredpixel.shatteredpixeldungeon.levels.Terrain.WATER) {
            Buff.prolong(hero, com.shatteredpixel.shatteredpixeldungeon.actors.buffs.MossyStride.class, 2f);
            return;
        }

        // 复春步伐：只在草地 / 余烬上触发，且冷却中不触发
        if (terrain != com.shatteredpixel.shatteredpixeldungeon.levels.Terrain.GRASS
                && terrain != com.shatteredpixel.shatteredpixeldungeon.levels.Terrain.EMBERS) {
            return;
        }
        if (hero.buff(com.shatteredpixel.shatteredpixeldungeon.actors.hero.Talent.RejuvenatingStepsCooldown.class) != null) {
            return;
        }
        try {
            boolean furrowFull = false;
            com.shatteredpixel.shatteredpixeldungeon.actors.hero.Talent.RejuvenatingStepsFurrow furrow
                    = hero.buff(com.shatteredpixel.shatteredpixeldungeon.actors.hero.Talent.RejuvenatingStepsFurrow.class);
            if (furrow != null && furrow.count() >= 200f) {
                furrowFull = true;
            }
            if (!com.shatteredpixel.shatteredpixeldungeon.actors.buffs.Regeneration.regenOn()
                    || furrowFull) {
                com.shatteredpixel.shatteredpixeldungeon.levels.Level.set(pos,
                        com.shatteredpixel.shatteredpixeldungeon.levels.Terrain.FURROWED_GRASS);
            } else {
                com.shatteredpixel.shatteredpixeldungeon.levels.Level.set(pos,
                        com.shatteredpixel.shatteredpixeldungeon.levels.Terrain.HIGH_GRASS);
                Buff.count(hero,
                        com.shatteredpixel.shatteredpixeldungeon.actors.hero.Talent.RejuvenatingStepsFurrow.class,
                        1f);
            }
            com.shatteredpixel.shatteredpixeldungeon.scenes.GameScene.updateMap(pos);
            Buff.affect(hero,
                    com.shatteredpixel.shatteredpixeldungeon.actors.hero.Talent.RejuvenatingStepsCooldown.class,
                    REJUVENATING_COOLDOWN);
        } catch (Throwable ignored) {
        }
    }

    /** 踩过一丛「未枯萎的高草」时给一段「苔藓生风」 */
    public static void onTrampleGrass() {
        if (!mossyActive()) {
            return;
        }
        Hero hero = Dungeon.hero;
        if (hero == null) {
            return;
        }
        Buff.prolong(hero, com.shatteredpixel.shatteredpixeldungeon.actors.buffs.MossyStride.class, 5f);
    }
    // ============================================================
    // 陷阱元件（强化）：隐藏陷阱全部显形 + 把周围陷阱收成晶柱
    // ============================================================

    /** 强化陷阱元件在身上？ */
    public static boolean trapSenseActive() {
        return isEnhancedLevel(TrapMechanism.class);
    }

    /** 每回合调用：把本层所有还藏着的陷阱显形 */
    public static void revealTraps() {
        if (!trapSenseActive() || Dungeon.level == null) {
            return;
        }
        boolean changed = false;
        for (com.shatteredpixel.shatteredpixeldungeon.levels.traps.Trap t
                : Dungeon.level.traps.valueList()) {
            if (t == null || t.visible || !t.canBeHidden) {
                continue;
            }
            t.reveal();
            changed = true;
        }
        if (changed) {
            com.shatteredpixel.shatteredpixeldungeon.scenes.GameScene.updateFog();
        }
    }

    /** 陷阱能不能被晶柱收走（活着的、看得见的） */
    private static boolean storable(com.shatteredpixel.shatteredpixeldungeon.levels.traps.Trap t) {
        return t != null && t.active && t.visible;
    }

    /** 收集身边 4 格内所有能被晶柱存下的陷阱 */
    public static void collectTraps(Hero hero) {
        if (hero == null || Dungeon.level == null || !trapSenseActive()) {
            return;
        }
        int collected = 0;
        java.util.ArrayList<com.shatteredpixel.shatteredpixeldungeon.levels.traps.Trap> found =
                new java.util.ArrayList<>();
        for (com.shatteredpixel.shatteredpixeldungeon.levels.traps.Trap t
                : Dungeon.level.traps.valueList()) {
            if (!storable(t)) {
                continue;
            }
            if (Dungeon.level.distance(hero.pos, t.pos) > 4) {
                continue;
            }
            found.add(t);
        }
        for (com.shatteredpixel.shatteredpixeldungeon.levels.traps.Trap t : found) {
            com.shatteredpixel.shatteredpixeldungeon.items.spells.TrapCrystal crystal =
                    new com.shatteredpixel.shatteredpixeldungeon.items.spells.TrapCrystal(t.getClass());
            if (!crystal.collect(hero.belongings.backpack)) {
                break;
            }
            t.disarm();
            com.shatteredpixel.shatteredpixeldungeon.scenes.GameScene.updateMap(t.pos);
            collected++;
        }
        if (collected > 0) {
            GLog.p("陷阱元件把 " + collected + " 个陷阱收进了晶柱。");
            Item.updateQuickslot();
        } else {
            GLog.w("身边没有能被晶柱收下的陷阱。");
        }
    }
    // ============================================================
    // 拟箱利齿（强化）：换层时所有宝箱都变成宝箱怪，另保证一只藏起来的黑檀宝箱怪
    // ============================================================

    /** 强化拟箱利齿在身上？ */
    public static boolean mimicActive() {
        return isEnhancedLevel(MimicTooth.class);
    }

    /** 上一次处理过宝箱的层 */
    private static int lastMimicDepth = -1;

    /** 每回合调用：换新层时处理一遍 */
    public static void mimicTick() {
        if (Dungeon.level == null) {
            return;
        }
        if (lastMimicDepth == Dungeon.depth) {
            return;
        }
        lastMimicDepth = Dungeon.depth;
        if (!mimicActive()) {
            return;
        }

        // ① 所有宝箱 → 宝箱怪（明着来的，不再伪装）
        int converted = 0;
        java.util.ArrayList<com.shatteredpixel.shatteredpixeldungeon.items.Heap> chests =
                new java.util.ArrayList<>();
        for (com.shatteredpixel.shatteredpixeldungeon.items.Heap h
                : Dungeon.level.heaps.valueList()) {
            if (h != null && h.type == com.shatteredpixel.shatteredpixeldungeon.items.Heap.Type.CHEST) {
                chests.add(h);
            }
        }
        for (com.shatteredpixel.shatteredpixeldungeon.items.Heap h : chests) {
            Item[] items = h.items.toArray(new Item[0]);
            Dungeon.level.heaps.remove(h.pos);
            if (h.sprite != null) {
                h.sprite.killAndErase();
            }
            com.shatteredpixel.shatteredpixeldungeon.actors.mobs.Mimic m =
                    com.shatteredpixel.shatteredpixeldungeon.actors.mobs.Mimic.spawnAt(h.pos, items);
            if (m == null) {
                continue;
            }
            setBoolean(m, "stealthy", false);
            m.state = m.WANDERING;
            com.shatteredpixel.shatteredpixeldungeon.scenes.GameScene.add(m);
            converted++;
        }

        // ② 每层保证一只「藏起来的」黑檀宝箱怪
        boolean spawnedEbony = false;
        int cell = pickHiddenMimicCell();
        if (cell >= 0) {
            com.shatteredpixel.shatteredpixeldungeon.actors.mobs.Mimic ebony =
                    com.shatteredpixel.shatteredpixeldungeon.actors.mobs.Mimic.spawnAt(
                            cell,
                            com.shatteredpixel.shatteredpixeldungeon.actors.mobs.EbonyMimic.class);
            if (ebony != null) {
                setBoolean(ebony, "stealthy", true);      // 保持伪装：藏起来的那一只
                ebony.state = ebony.PASSIVE;
                com.shatteredpixel.shatteredpixeldungeon.scenes.GameScene.add(ebony);
                spawnedEbony = true;
            }
        }

        if (converted > 0) {
            GLog.w("牙根一阵发痒——这一层的 " + converted + " 个宝箱全都睁开了眼。");
        }
        if (spawnedEbony) {
            GLog.i("（角落里有个箱子不太对劲。）");
        }
    }

    /** 找一个能藏宝箱怪的地方：可通行、没人、没堆、不在视野里 */
    private static int pickHiddenMimicCell() {
        com.shatteredpixel.shatteredpixeldungeon.levels.Level level = Dungeon.level;
        if (level == null) {
            return -1;
        }
        int len = level.length();
        for (int i = 0; i < 300; i++) {
            int c = com.watabou.utils.Random.Int(len);
            if (!level.passable[c] || level.solid[c]) {
                continue;
            }
            if (level.heroFOV[c] || level.heaps.get(c) != null
                    || com.shatteredpixel.shatteredpixeldungeon.actors.Actor.findChar(c) != null) {
                continue;
            }
            if (Dungeon.hero != null && level.distance(c, Dungeon.hero.pos) < 3) {
                continue;
            }
            return c;
        }
        return -1;
    }

    /** 给对象的（含父类）私有布尔字段赋值 */
    private static void setBoolean(Object target, String field, boolean value) {
        Class<?> c = target.getClass();
        while (c != null) {
            try {
                java.lang.reflect.Field f = c.getDeclaredField(field);
                f.setAccessible(true);
                f.setBoolean(target, value);
                return;
            } catch (NoSuchFieldException e) {
                c = c.getSuperclass();
            } catch (Throwable ignored) {
                return;
            }
        }
    }
    // ============================================================
    // 奇迹树脂（强化）：只要带在身上，永远抽中「好运」
    // ============================================================

    /** 强化奇迹树脂在身上？ */
    public static boolean luckActive() {
        return isEnhancedLevel(WondrousResin.class);
    }

    /**
     * 每回合调用：强化树脂在背包里时，把原版留给测试用的
     * {@code WondrousResin.forcePositive} 打开，于是
     * {@code positiveCurseEffectChance()} 恒为 1.0——只会抽中好运。
     */
    public static void luckTick() {
        WondrousResin.forcePositive = luckActive();
    }
    // ============================================================
    // 凝血试管（强化）：免疫「恐药异症」
    // ============================================================

    /** 身上带着强化凝血试管（4 级）就免疫恐药异症 */
    public static boolean bloodVialImmune() {
        return isEnhancedLevel(VialOfBlood.class);
    }
    // ============================================================
    // 混沌香炉（强化）：不再自己喷，改成存起来手动放
    // ============================================================

    /** 强化混沌香炉在身上？ */
    public static boolean censerActive() {
        return isEnhancedLevel(ChaoticCenser.class);
    }

    /** 香炉容量 = 当前等级 */
    public static int censerCapacity() {
        if (Dungeon.hero == null || Dungeon.hero.belongings == null) {
            return 0;
        }
        ChaoticCenser c = Dungeon.hero.belongings.getItem(ChaoticCenser.class);
        return c == null ? 0 : c.buffedLvl();
    }

    /** 存了几份气 */
    public static int censerStored() {
        com.shatteredpixel.shatteredpixeldungeon.actors.buffs.CenserStorage s =
                com.shatteredpixel.shatteredpixeldungeon.actors.buffs.CenserStorage.get();
        return s == null ? 0 : s.gasses.size();
    }

    /** 攒气速度：与原版 300/(等级+1) 回合一份一致 */
    private static float censerRate() {
        return 300.0f / (Math.max(1, censerCapacity()) + 1);
    }

    /** 每回合调用：攒气；存档里存着，不喷出来 */
    public static void censerTick() {
        if (!censerActive()) {
            return;
        }
        int cap = censerCapacity();
        com.shatteredpixel.shatteredpixeldungeon.actors.buffs.CenserStorage s =
                com.shatteredpixel.shatteredpixeldungeon.actors.buffs.CenserStorage.ensure();
        if (s == null || cap <= 0) {
            return;
        }
        if (s.gasses.size() >= cap) {
            s.progress = 0f;
            return;
        }
        s.progress += 1.0f / Math.max(1f, censerRate());
        if (s.progress >= 1.0f) {
            s.progress -= 1.0f;
            s.gasses.add(randomGas());
            GLog.i("香炉又闷住了一口" + Messages.get(s.gasses.get(s.gasses.size() - 1), "name") + "。");
            Item.updateQuickslot();
        }
    }

    /** 从原版的九种气体里抽一种 */
    private static Class<? extends com.shatteredpixel.shatteredpixeldungeon.actors.blobs.Blob> randomGas() {
        Class<?>[] pool = new Class<?>[]{
                com.shatteredpixel.shatteredpixeldungeon.actors.blobs.ToxicGas.class,
                com.shatteredpixel.shatteredpixeldungeon.actors.blobs.ConfusionGas.class,
                com.shatteredpixel.shatteredpixeldungeon.actors.blobs.StenchGas.class,
                com.shatteredpixel.shatteredpixeldungeon.actors.blobs.StormCloud.class,
                com.shatteredpixel.shatteredpixeldungeon.actors.blobs.SmokeScreen.class,
                com.shatteredpixel.shatteredpixeldungeon.actors.blobs.Regrowth.class,
                com.shatteredpixel.shatteredpixeldungeon.actors.blobs.Inferno.class,
                com.shatteredpixel.shatteredpixeldungeon.actors.blobs.Blizzard.class,
                com.shatteredpixel.shatteredpixeldungeon.actors.blobs.CorrosiveGas.class
        };
        return (Class<? extends com.shatteredpixel.shatteredpixeldungeon.actors.blobs.Blob>)
                com.watabou.utils.Random.element(pool);
    }

    /** 手动选一个位置，把存着的气放出来 */
    public static void beginCenserRelease(com.shatteredpixel.shatteredpixeldungeon.actors.hero.Hero hero) {
        com.shatteredpixel.shatteredpixeldungeon.actors.buffs.CenserStorage s =
                com.shatteredpixel.shatteredpixeldungeon.actors.buffs.CenserStorage.get();
        if (s == null || s.gasses.isEmpty()) {
            GLog.w("香炉里还什么都没闷下。");
            return;
        }
        com.shatteredpixel.shatteredpixeldungeon.scenes.GameScene.selectCell(censerTargeter);
    }

    private static final com.shatteredpixel.shatteredpixeldungeon.scenes.CellSelector.Listener censerTargeter =
            new com.shatteredpixel.shatteredpixeldungeon.scenes.CellSelector.Listener() {
                @Override
                public void onSelect(Integer cell) {
                    if (cell == null) {
                        return;
                    }
                    com.shatteredpixel.shatteredpixeldungeon.actors.buffs.CenserStorage s =
                            com.shatteredpixel.shatteredpixeldungeon.actors.buffs.CenserStorage.get();
                    if (s == null || s.gasses.isEmpty()) {
                        return;
                    }
                    Class<? extends com.shatteredpixel.shatteredpixeldungeon.actors.blobs.Blob> gas =
                            s.gasses.remove(0);
                    int qty = gas == com.shatteredpixel.shatteredpixeldungeon.actors.blobs.Inferno.class
                            || gas == com.shatteredpixel.shatteredpixeldungeon.actors.blobs.Blizzard.class
                            || gas == com.shatteredpixel.shatteredpixeldungeon.actors.blobs.CorrosiveGas.class
                            ? 250 : 300;
                    com.shatteredpixel.shatteredpixeldungeon.scenes.GameScene.add(
                            com.shatteredpixel.shatteredpixeldungeon.actors.blobs.Blob.seed(cell, qty, gas));
                    com.watabou.noosa.audio.Sample.INSTANCE.play("sounds/gas.mp3");
                    GLog.p("香炉吐出一团" + Messages.get(gas, "name") + "。");
                    Item.updateQuickslot();
                    if (com.shatteredpixel.shatteredpixeldungeon.Dungeon.hero != null) {
                        com.shatteredpixel.shatteredpixeldungeon.Dungeon.hero.spendAndNext(1.0f);
                    }
                }

                @Override
                public String prompt() {
                    return "选一个位置，把香炉里闷着的气放出来";
                }
            };
    // ============================================================
    // 雪貂绒束（强化）：共享闪避倍率往回退，玩家这边单独补回来
    // ============================================================

    /**
     * 额外等级给玩家的专属闪避加成（敌我不共享）。
     * 每多一级 +25%，用来抵消共享倍率退档带来的损失。
     */
    public static float ferretHeroBonus() {
        if (Dungeon.hero == null || Dungeon.hero.belongings == null) {
            return 1.0f;
        }
        if (!isEnhancedLevel(FerretTuft.class)) {
            return 1.0f;
        }
        int level = levelOf(FerretTuft.class);
        return 1.0f + 0.25f * (level - 3);
    }
    // ============================================================
    // 幻象裂镜（强化）：每 150 回合在脚下触发一次「探地」
    // ============================================================

    /** 每隔多少回合触发一次 */
    public static final int SPYGLASS_PERIOD = 150;

    /** 强化幻象裂镜在身上？ */
    public static boolean spyglassActive() {
        return isEnhancedLevel(CrackedSpyglass.class);
    }

    /** 每回合调用：数到 150 回合就在脚下探一次地 */
    public static void spyglassTick() {
        Hero hero = Dungeon.hero;
        if (hero == null || Dungeon.level == null) {
            return;
        }
        if (!spyglassActive()) {
            return;
        }
        com.shatteredpixel.shatteredpixeldungeon.actors.buffs.SpyglassTimer timer =
                com.shatteredpixel.shatteredpixeldungeon.actors.buffs.SpyglassTimer.ensure();
        if (timer == null) {
            return;
        }
        if (++timer.ticks < SPYGLASS_PERIOD) {
            return;
        }
        timer.ticks = 0;
        GLog.i("镜片里闪过一片地貌——脚下一段路被你看清了。");
        revealArea(hero.pos);
    }

    /** 复刻「明示符石」（探地符石）的效果 */
    private static void revealArea(int cell) {
        if (Dungeon.level == null) {
            return;
        }
        final int DIST = 20;
        com.watabou.utils.Point c = Dungeon.level.cellToPoint(cell);
        int[] rounding = com.shatteredpixel.shatteredpixeldungeon.mechanics.ShadowCaster.rounding[DIST];
        boolean noticed = false;
        for (int y = Math.max(0, c.y - DIST); y <= Math.min(Dungeon.level.height() - 1, c.y + DIST); y++) {
            int left;
            if (rounding[Math.abs(c.y - y)] < Math.abs(c.y - y)) {
                left = c.x - rounding[Math.abs(c.y - y)];
            } else {
                left = DIST;
                while (rounding[left] < rounding[Math.abs(c.y - y)]) {
                    left--;
                }
                left = c.x - left;
            }
            int right = Math.min(Dungeon.level.width() - 1, c.x + c.x - left);
            left = Math.max(0, left);
            for (int curr = left + y * Dungeon.level.width();
                 curr <= right + y * Dungeon.level.width(); curr++) {
                com.shatteredpixel.shatteredpixeldungeon.scenes.GameScene.checkedCell(curr, cell);
                Dungeon.level.mapped[curr] = true;
                if (!Dungeon.level.secret[curr]) {
                    continue;
                }
                Dungeon.level.discover(curr);
                if (!Dungeon.level.heroFOV[curr]) {
                    continue;
                }
                com.shatteredpixel.shatteredpixeldungeon.scenes.GameScene
                        .discoverTile(curr, Dungeon.level.map[curr]);
                com.shatteredpixel.shatteredpixeldungeon.items.scrolls.ScrollOfMagicMapping
                        .discover(curr);
                noticed = true;
            }
        }
        if (noticed) {
            com.watabou.noosa.audio.Sample.INSTANCE.play("sounds/secret.mp3");
        }
        com.watabou.noosa.audio.Sample.INSTANCE.play("sounds/teleport.mp3");
        com.shatteredpixel.shatteredpixeldungeon.scenes.GameScene.updateFog();
    }
    // ============================================================
    // 位面日晷（强化）：夜间危险不再加码，改成兑现成掉落 + 每层可校准一次
    // ============================================================

    /** 强化位面日晷在身上？ */
    public static boolean sundialActive() {
        return isEnhancedLevel(DimensionalSundial.class);
    }

    /** 现在是不是「夜间」（与原版判定一致：20:00–7:59） */
    public static boolean isNightNow() {
        int hour = java.util.GregorianCalendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY);
        return hour >= 20 || hour <= 7;
    }

    /** 本层是否已校准成白昼 */
    public static boolean sundialCalibrated() {
        return com.shatteredpixel.shatteredpixeldungeon.actors.buffs.SundialCalibration.calibratedNow();
    }

    /** 还能不能校准（每层一次） */
    public static boolean canCalibrate() {
        return sundialActive() && !sundialCalibrated();
    }

    /** 校准：把这一层锁成白昼 */
    public static void calibrate(Hero hero) {
        if (hero == null || !canCalibrate()) {
            return;
        }
        com.shatteredpixel.shatteredpixeldungeon.actors.buffs.SundialCalibration c =
                com.shatteredpixel.shatteredpixeldungeon.actors.buffs.SundialCalibration.get();
        if (c == null) {
            c = Buff.affect(hero,
                    com.shatteredpixel.shatteredpixeldungeon.actors.buffs.SundialCalibration.class);
        }
        if (c == null) {
            return;
        }
        c.depth = Dungeon.depth;
        GLog.p("你把晷影摆正了——这一层的怪物会按白昼的节奏出现。");
        Item.updateQuickslot();
        hero.spendAndNext(1.0f);
    }

    /**
     * 夜间的额外掉落加成：每多一级 +10%（4 级 +10%、5 级 +20%、6 级 +30%）。
     * 只在夜间、带着强化日晷、且本层没被校准成白昼时生效。
     */
    public static float sundialNightLootBonus() {
        if (!sundialActive() || sundialCalibrated() || !isNightNow()) {
            return 0f;
        }
        int extra = levelOf(DimensionalSundial.class) - 3;
        return extra <= 0 ? 0f : 0.1f * extra;
    }

    // ============================================================
    // 遗忘碎片（强化）：背包里的「无知」也算力量
    // ============================================================

    /** 强化遗忘碎片在身上？ */
    public static boolean shardActive() {
        return isEnhancedLevel(ShardOfOblivion.class);
    }

    /**
     * 背包里每件未鉴定物品 +5% 掉落（最多 10 件 → +50%）。
     * 原版只算装备槽，这里把「囤着不鉴定的东西」也算进去。
     */
    public static float shardBackpackBonus() {
        if (!shardActive()) {
            return 0f;
        }
        Hero hero = Dungeon.hero;
        if (hero == null || hero.belongings == null) {
            return 0f;
        }
        int n = 0;
        for (Item it : hero.belongings.backpack.items) {
            if (it != null && !it.isIdentified()) {
                n++;
                if (n >= 10) {
                    break;
                }
            }
        }
        return 0.05f * n;
    }
}
