/*
 * Decompiled with CFR 0.152.
 */
package com.shatteredpixel.shatteredpixeldungeon.items.artifacts;

import com.shatteredpixel.shatteredpixeldungeon.Dungeon;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.Blindness;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.Buff;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.MagicImmune;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.Regeneration;
import com.shatteredpixel.shatteredpixeldungeon.actors.hero.Hero;
import com.shatteredpixel.shatteredpixeldungeon.actors.hero.HeroClass;
import com.shatteredpixel.shatteredpixeldungeon.actors.hero.Talent;
import com.shatteredpixel.shatteredpixeldungeon.actors.mobs.Mob;
import com.shatteredpixel.shatteredpixeldungeon.effects.particles.ElmoParticle;
import com.shatteredpixel.shatteredpixeldungeon.items.Generator;
import com.shatteredpixel.shatteredpixeldungeon.items.Item;
import com.shatteredpixel.shatteredpixeldungeon.items.artifacts.Artifact;
import com.shatteredpixel.shatteredpixeldungeon.items.bags.Bag;
import com.shatteredpixel.shatteredpixeldungeon.items.bags.ScrollHolder;
import com.shatteredpixel.shatteredpixeldungeon.items.rings.RingOfEnergy;
import com.shatteredpixel.shatteredpixeldungeon.items.scrolls.Scroll;
import com.shatteredpixel.shatteredpixeldungeon.items.scrolls.ScrollOfIdentify;
import com.shatteredpixel.shatteredpixeldungeon.items.scrolls.ScrollOfLullaby;
import com.shatteredpixel.shatteredpixeldungeon.items.scrolls.ScrollOfMagicMapping;
import com.shatteredpixel.shatteredpixeldungeon.items.scrolls.ScrollOfRage;
import com.shatteredpixel.shatteredpixeldungeon.items.scrolls.ScrollOfRemoveCurse;
import com.shatteredpixel.shatteredpixeldungeon.items.scrolls.ScrollOfRetribution;
import com.shatteredpixel.shatteredpixeldungeon.items.scrolls.ScrollOfTerror;
import com.shatteredpixel.shatteredpixeldungeon.items.scrolls.ScrollOfTransmutation;
import com.shatteredpixel.shatteredpixeldungeon.items.scrolls.exotic.ExoticScroll;
import com.shatteredpixel.shatteredpixeldungeon.journal.Catalog;
import com.shatteredpixel.shatteredpixeldungeon.messages.Messages;
import com.shatteredpixel.shatteredpixeldungeon.scenes.GameScene;
import com.shatteredpixel.shatteredpixeldungeon.sprites.ItemSprite;
import com.shatteredpixel.shatteredpixeldungeon.sprites.ItemSpriteSheet;
import com.shatteredpixel.shatteredpixeldungeon.utils.GLog;
import com.shatteredpixel.shatteredpixeldungeon.windows.WndBag;
import com.shatteredpixel.shatteredpixeldungeon.windows.WndOptions;
import com.watabou.noosa.Game;
import com.watabou.noosa.audio.Sample;
import com.watabou.utils.Bundle;
import com.watabou.utils.Callback;
import com.watabou.utils.Random;
import com.watabou.utils.Reflection;
import java.util.ArrayList;

public class UnstableSpellbook
extends Artifact {
    public static final String AC_READ = "READ";
    public static final String AC_ADD = "ADD";
    private final ArrayList<Class> scrolls;
    private static final String SCROLLS = "scrolls";
    // ===== MOD: 被撕毁的页面 =====
    private final ArrayList<String> tornPages = new ArrayList<>();
    private int tearPenalty = 0;
    private static final String TORN_PAGES = "torn_pages";
    private static final String TEAR_PENALTY = "tear_penalty";
    // ===== MOD end ====
    // ===== MOD: 复读 / 人格立场 =====
    public static final String AC_REPEAT = "REPEAT";
    public static final int STANCE_FRIENDLY = 0;   // 法师 / 牧师
    public static final int STANCE_NEUTRAL = 1;    // 女猎手 / 盗贼 / 决斗家
    public static final int STANCE_NASTY = 2;      // 战士
    /** 最近读过的卷轴（或秘卷）类名 */
    private String lastScroll;
    /** 恶劣立场下已经骂过几次（三次以后就懒得骂了） */
    private int tearCurses = 0;
    private static final String LAST_SCROLL = "last_scroll";
    private static final String TEAR_CURSES = "tear_curses";
    // ===== MOD end ====
    protected WndBag.ItemSelector itemSelector;

    public UnstableSpellbook() {
        this.image = ItemSpriteSheet.ARTIFACT_SPELLBOOK;
        this.levelCap = 10;
        this.charge = (int)((float)this.level() * 0.6f) + 2;
        this.partialCharge = 0.0f;
        this.chargeCap = (int)((float)this.level() * 0.6f) + 2;
        this.defaultAction = AC_READ;
        this.scrolls = new ArrayList();
        this.itemSelector = new WndBag.ItemSelector(){

            @Override
            public String textPrompt() {
                return Messages.get(UnstableSpellbook.class, "prompt", new Object[0]);
            }

            @Override
            public Class<? extends Bag> preferredBag() {
                return ScrollHolder.class;
            }

            @Override
            public boolean itemSelectable(Item item) {
                return item instanceof Scroll && item.isIdentified() && UnstableSpellbook.this.scrolls.contains(item.getClass());
            }

            @Override
            public void onSelect(Item item) {
                if (item != null && item instanceof Scroll && item.isIdentified()) {
                    Hero hero = Dungeon.hero;
                    for (int i = 0; i <= 1 && i < UnstableSpellbook.this.scrolls.size(); ++i) {
                        if (!UnstableSpellbook.this.scrolls.get(i).equals(item.getClass())) continue;
                        hero.sprite.operate(hero.pos);
                        hero.busy();
                        hero.spend(2.0f);
                        Sample.INSTANCE.play("sounds/burning.mp3");
                        hero.sprite.emitter().burst(ElmoParticle.FACTORY, 12);
                        UnstableSpellbook.this.scrolls.remove(i);
                        item.detach(hero.belongings.backpack);
                        UnstableSpellbook.this.upgrade();
                        Dungeon.hero.trackUpgrade(UnstableSpellbook.this, 1);
                        Catalog.countUse(UnstableSpellbook.class);
                        GLog.i(Messages.get(UnstableSpellbook.class, "infuse_scroll", new Object[0]), new Object[0]);
                        return;
                    }
                    GLog.w(Messages.get(UnstableSpellbook.class, "unable_scroll", new Object[0]), new Object[0]);
                } else if (item instanceof Scroll && !item.isIdentified()) {
                    GLog.w(Messages.get(UnstableSpellbook.class, "unknown_scroll", new Object[0]), new Object[0]);
                }
            }
        };
        this.setupScrolls();
    }

    private void setupScrolls() {
        this.scrolls.clear();
        Class<?>[] scrollClasses = Generator.Category.SCROLL.classes;
        float[] probs = (float[])Generator.Category.SCROLL.defaultProbsTotal.clone();
        int i = Random.chances(probs);
        while (i != -1) {
            this.scrolls.add(scrollClasses[i]);
            probs[i] = 0.0f;
            i = Random.chances(probs);
        }
        this.scrolls.remove(ScrollOfTransmutation.class);
    }

    @Override
    public ArrayList<String> actions(Hero hero) {
        ArrayList<String> actions = super.actions(hero);
        if (this.isEquipped(hero) && this.charge > 0 && !this.cursed && hero.buff(MagicImmune.class) == null) {
            actions.add(AC_READ);
        }
        if (this.isEquipped(hero) && this.level() < this.levelCap && !this.cursed && hero.buff(MagicImmune.class) == null) {
            actions.add(AC_ADD);
        }
        // MOD: 查看被撕毁的页面
        if (!this.tornPages.isEmpty()) {
            actions.add("TORN");
        }
        // MOD: 通过试炼后可以「复读」最近读过的那张卷轴 / 秘卷
        if (ArtifactTrial.isEnhanced(this) && this.lastScroll != null && !this.cursed
                && this.isEquipped(hero) && hero.buff(MagicImmune.class) == null) {
            actions.add(AC_REPEAT);
        }
        return actions;
    }

    @Override
    public String actionName(String action, Hero hero) {
        if ("TORN".equals(action)) {
            return "查看被撕毁的页面";
        }
        if (AC_REPEAT.equals(action)) {
            return "复读";
        }
        return super.actionName(action, hero);
    }

    public void execute(Hero hero, String action) {
        super.execute(hero, action);
        if (hero.buff(MagicImmune.class) != null) {
            return;
        }
        if (action.equals(AC_READ)) {
            if (hero.buff(Blindness.class) != null) {
                GLog.w(Messages.get(this, "blinded", new Object[0]), new Object[0]);
            } else if (!this.isEquipped(hero)) {
                GLog.i(Messages.get(Artifact.class, "need_to_equip", new Object[0]), new Object[0]);
            } else if (this.charge <= 0) {
                GLog.i(Messages.get(this, "no_charge", new Object[0]), new Object[0]);
            } else if (this.cursed) {
                GLog.i(Messages.get(this, "cursed", new Object[0]), new Object[0]);
            } else {
                this.doReadEffect(hero);
            }
        } else if (action.equals("TORN")) {
            this.syncChargeCap();
            GameScene.show(new WndTornPages(this));
        } else if (AC_REPEAT.equals(action)) {
            this.repeatLast(hero);
        } else if (action.equals(AC_ADD)) {
            GameScene.selectItem(this.itemSelector);
        }
    }

    /** MOD: 撕页确认窗口 */
    public static class WndTear extends com.shatteredpixel.shatteredpixeldungeon.ui.Window {
        public WndTear(final UnstableSpellbook book, final Hero hero, final Scroll scroll) {
            int w = com.shatteredpixel.shatteredpixeldungeon.scenes.PixelScene.landscape() ? 156 : 128;
            float pos = 2f;
            com.shatteredpixel.shatteredpixeldungeon.ui.RenderedTextBlock title =
                    com.shatteredpixel.shatteredpixeldungeon.scenes.PixelScene.renderTextBlock("无序魔典", 9);
            title.hardlight(TITLE_COLOR);
            title.setPos(2f, pos);
            this.add(title);
            pos = title.bottom() + 4f;

            String body = "书页翻动，这一次浮现的是《" + scroll.trueName() + "》的纹路。\n\n"
                    + "要照常使用它，还是把这一页撕掉？\n\n"
                    + "撕掉后，《" + scroll.trueName() + "》不会再从魔典中出现，充能上限永久 -1，"
                    + "并且这次还要额外消耗 1 点充能。";
            com.shatteredpixel.shatteredpixeldungeon.ui.RenderedTextBlock text =
                    com.shatteredpixel.shatteredpixeldungeon.scenes.PixelScene.renderTextBlock(body, 6);
            text.maxWidth(w - 8);
            text.setPos(2f, pos);
            this.add(text);
            pos = text.bottom() + 5f;

            float half = (w - 2f) / 2f;
            com.shatteredpixel.shatteredpixeldungeon.ui.RedButton yes =
                    new com.shatteredpixel.shatteredpixeldungeon.ui.RedButton("照常使用") {
                        @Override
                        protected void onClick() {
                            WndTear.this.hide();
                            book.modCast(hero, scroll);
                        }
                    };
            yes.setRect(0f, pos, half, 18f);
            this.add(yes);

            com.shatteredpixel.shatteredpixeldungeon.ui.RedButton no =
                    new com.shatteredpixel.shatteredpixeldungeon.ui.RedButton("撕掉这一页") {
                        @Override
                        protected void onClick() {
                            WndTear.this.hide();
                            book.tearPage(scroll);
                        }
                    };
            no.setRect(half + 2f, pos, half, 18f);
            this.add(no);
            pos += 22f;
            this.resize(w, (int) pos);
        }
    }

    /** MOD: 查看被撕毁的页面 */
    public static class WndTornPages extends com.shatteredpixel.shatteredpixeldungeon.ui.Window {
        public WndTornPages(final UnstableSpellbook book) {
            int w = com.shatteredpixel.shatteredpixeldungeon.scenes.PixelScene.landscape() ? 150 : 124;
            float pos = 2f;
            com.shatteredpixel.shatteredpixeldungeon.ui.RenderedTextBlock title =
                    com.shatteredpixel.shatteredpixeldungeon.scenes.PixelScene.renderTextBlock("被撕毁的页面", 9);
            title.hardlight(TITLE_COLOR);
            title.setPos(2f, pos);
            this.add(title);
            pos = title.bottom() + 4f;

            if (book.tornPages.isEmpty()) {
                com.shatteredpixel.shatteredpixeldungeon.ui.RenderedTextBlock empty =
                        com.shatteredpixel.shatteredpixeldungeon.scenes.PixelScene.renderTextBlock("魔典完好无损。", 6);
                empty.maxWidth(w - 8);
                empty.setPos(2f, pos);
                this.add(empty);
                pos = empty.bottom() + 4f;
            } else {
                for (final String fqn : new ArrayList<>(book.tornPages)) {
                    String label;
                    try {
                        Scroll sample = (Scroll)Class.forName(fqn).newInstance();
                        int have = 0;
                        if (Dungeon.hero != null && Dungeon.hero.belongings != null) {
                            for (Item it : Dungeon.hero.belongings.backpack.items) {
                                if (it.getClass().getName().equals(fqn)) {
                                    have += it.quantity();
                                }
                            }
                        }
                        label = sample.trueName() + "（持有 " + have + "，点击粘回）";
                    } catch (Throwable t) {
                        label = fqn;
                    }
                    com.shatteredpixel.shatteredpixeldungeon.ui.RedButton btn =
                            new com.shatteredpixel.shatteredpixeldungeon.ui.RedButton(label) {
                                @Override
                                protected void onClick() {
                                    try {
                                        if (book.restorePage(Class.forName(fqn), Dungeon.hero)) {
                                            WndTornPages.this.hide();
                                        }
                                    } catch (Throwable ignored) {
                                    }
                                }
                            };
                    btn.setRect(0f, pos, w - 4f, 18f);
                    this.add(btn);
                    pos += 20f;
                }
            }
            this.resize(w, (int)(pos + 2f));
        }
    }

    /** MOD: 充能上限 = 基础 - 撕页惩罚（下限 1） */
    public void syncChargeCap() {
        int base = (int)((float)this.level() * 0.6f) + 2;
        int cap = Math.max(1, base - this.tearPenalty);
        this.chargeCap = cap;
        if (this.charge > cap) {
            this.charge = cap;
        }
    }

    /** MOD: 撕掉这一页（A3：本次充能已扣，再额外扣 1 点，不施放） */
    public void tearPage(Scroll scroll) {
        String name = scroll.getClass().getName();
        if (!this.tornPages.contains(name)) {
            this.tornPages.add(name);
        }
        this.tearPenalty++;
        this.charge = Math.max(0, this.charge - 1);
        this.syncChargeCap();
        GLog.p("你撕下了这一页。《" + scroll.trueName() + "》不会再从魔典中出现（充能上限 -1）。");
        this.tearReaction();   // MOD: 撕页之后，按立场看魔典的反应
        Item.updateQuickslot();
    }

    // ============================================================
    // MOD: 人格立场 / 复读 / 撕页反应
    // ============================================================

    /** 博学的魔典看不起智力低下的人，说话的态度看你的职业 */
    public int stance() {
        Hero hero = Dungeon.hero;
        if (hero == null) {
            return STANCE_NEUTRAL;
        }
        if (hero.heroClass == HeroClass.MAGE || hero.heroClass == HeroClass.CLERIC) {
            return STANCE_FRIENDLY;   // 同行：法师、牧师
        }
        if (hero.heroClass == HeroClass.HUNTRESS || hero.heroClass == HeroClass.ROGUE
                || hero.heroClass == HeroClass.DUELIST) {
            return STANCE_NEUTRAL;    // 能看懂字的
        }
        return STANCE_NASTY;          // 战士：在它眼里是「会走路的斧头」
    }

    /** MOD: 复读最近读过的那张卷轴：普通 2 点充能，秘卷 3 点 */
    public void repeatLast(Hero hero) {
        if (this.lastScroll == null || hero == null) {
            return;
        }
        Class<?> cls;
        try {
            cls = Class.forName(this.lastScroll);
        } catch (Throwable t) {
            return;
        }
        boolean exotic = ExoticScroll.class.isAssignableFrom(cls);
        int cost = exotic ? 3 : 2;
        String name = "那张卷轴";
        try {
            name = ((Scroll) Reflection.newInstance(cls)).trueName();
        } catch (Throwable ignored) {
        }
        // 撕掉了的那一页，再也复读不出来 —— 这时按立场回应
        if (this.tornPages.contains(this.lastScroll)) {
            GLog.w(this.repeatRefusal(name));
            return;
        }
        if (this.charge < cost) {
            GLog.i("魔典的充能不够。" + (exotic ? "复读一张秘卷需要 " + cost + " 点。" : "复读一张卷轴需要 " + cost + " 点。"));
            return;
        }
        this.charge -= cost;
        Scroll scroll = (Scroll) Reflection.newInstance(cls);
        scroll.anonymize();
        scroll.talentChance = 0.0f;
        curItem = scroll;
        curUser = hero;
        GLog.i(this.repeatLine(name));
        this.checkForArtifactProc(hero, scroll);
        scroll.doRead();
        Talent.onArtifactUsed(hero);
        Item.updateQuickslot();
    }

    /** 撕掉的那一页被要求复读时，按立场的回应 */
    private String repeatRefusal(String name) {
        switch (this.stance()) {
            case STANCE_FRIENDLY:
                return "「这张……」书页轻轻翻了翻，「你把它撕掉了。我帮不了你。"
                        + "下次要撕之前，先跟我说一声，好吗。」";
            case STANCE_NEUTRAL:
                return "「做不到。」书页干脆地合上，「那一页不在我身上了。」";
            default:
                return "「哈？」书页抖了一下，像是看傻子，「你把它撕了，现在又让我念给你听？」\n"
                        + "「你这记性——是提前把脑子也一起撕了吧，老糊涂。」";
        }
    }

    /** 成功复读时的立场台词 */
    private String repeatLine(String name) {
        switch (this.stance()) {
            case STANCE_FRIENDLY:
                return "「《" + name + "》是吧，我记着呢。」书页温和地展开，「照着念就是了。」";
            case STANCE_NEUTRAL:
                return "「复读。」魔典翻开那一页，「别指望我讲第二遍。」";
            default:
                return "「行吧行吧，再念一遍。」书页不耐烦地哗啦一下，「反正你也记不住。」";
        }
    }

    /** MOD: 撕页之后的人格反应（文本单独抽出来，方便无图形环境核对） */
    private void tearReaction() {
        GLog.i(this.tearReactionText());
        this.checkTornToBones();
    }

    String tearReactionText() {
        switch (this.stance()) {
            case STANCE_FRIENDLY:
                return "书页窸窣了一下，像是在叹气：\n「……我明白。换作是我，也会这么做的。」";
            case STANCE_NEUTRAL:
                return "书脊上的书签忽然立了起来，像一只眼睛。\n它瞪着你，但没有阻止。";
            default:
                this.tearCurses++;
                if (this.tearCurses == 1) {
                    return "「愚蠢。粗鲁。野蛮。」魔典一字一顿，「你配不上我这一页。」";
                } else if (this.tearCurses == 2) {
                    return "「又是这样。」它冷笑，「你这双只配握斧头的手，知道什么叫『知识』吗？」";
                } else if (this.tearCurses == 3) {
                    return "「我记下了。你撕掉的每一页，将来都会从你身上撕回来。」";
                } else {
                    return "魔典不再骂你了。\n\n书页安安静静——安静得让你后颈发凉。";
                }
        }
    }

    /** MOD: +10 满级、又被撕到只剩 1 点充能上限时的特殊台词 */
    private void checkTornToBones() {
        if (this.level() < this.levelCap || this.chargeCap > 1) {
            return;
        }
        GLog.i(this.tornToBonesText());
        GLog.n("「我被撕得薄到……已经不能被称为一本书了。」\n\n「早知道，当初就烂在柜子上。」");
    }

    String tornToBonesText() {
        switch (this.stance()) {
            case STANCE_FRIENDLY:
                return "书上的字迹委屈到了极点，缩成小小的一团：\n「……我已经，只剩这么一点点了。」";
            case STANCE_NEUTRAL:
                return "书页上什么都没有。\n\n不是空白，是那种「已经不知道该说什么」的沉默。";
            default:
                return "书页中央缓缓挤出一个小小的、歪歪扭扭的颜文字：(-_-)\n\n"
                        + "那大概是它能做出的、最像白眼的玩意儿了。";
        }
    }

    /** MOD: 把撕下的页面粘回去（消耗一张对应卷轴） */
    public boolean restorePage(Class<?> scrollClass, Hero hero) {
        if (hero == null || hero.belongings == null) {
            return false;
        }
        String name = scrollClass.getName();
        if (!this.tornPages.contains(name)) {
            return false;
        }
        Scroll found = null;
        for (Item it : hero.belongings.backpack.items) {
            if (it.getClass() == scrollClass) {
                found = (Scroll)it;
                break;
            }
        }
        if (found == null) {
            GLog.i("你身上没有对应的卷轴。");
            return false;
        }
        if (found.quantity() > 1) {
            found.quantity(found.quantity() - 1);
        } else {
            found.detach(hero.belongings.backpack);
        }
        this.tornPages.remove(name);
        this.tearPenalty = Math.max(0, this.tearPenalty - 1);
        this.syncChargeCap();
        GLog.p("你把这一页重新粘回了魔典（充能上限恢复 1 点）。");
        Item.updateQuickslot();
        return true;
    }

    /** MOD: 确认后的正常施放（原 doReadEffect 后半段） */
    public void modCast(Hero hero, Scroll scroll) {
        this.doReadBody(hero, scroll);
    }

    public void doReadEffect(Hero hero) {
        Scroll scroll;
        --this.charge;
        while ((scroll = (Scroll)Generator.randomUsingDefaults(Generator.Category.SCROLL)) == null
                || this.tornPages.contains(scroll.getClass().getName())   // MOD: 已撕毁的不再出现
                || (scroll instanceof ScrollOfIdentify || scroll instanceof ScrollOfRemoveCurse || scroll instanceof ScrollOfMagicMapping) && Random.Int(2) == 0
                || scroll instanceof ScrollOfTransmutation) {
        }
        // ===== MOD: 先告知将出现的卷轴，再询问是否撕掉这一页（需先通过神器试炼） =====
        this.syncChargeCap();
        if (ArtifactTrial.isEnhanced(this)) {
            GameScene.show(new WndTear(this, hero, scroll));
        } else {
            this.doReadBody(hero, scroll);
        }
    }

    /** MOD: 原 doReadEffect 的后半段（照常施放） */
    public void doReadBody(Hero hero, Scroll scroll) {
        this.lastScroll = scroll.getClass().getName();   // MOD: 记住最近读的这张
        scroll.anonymize();
        scroll.talentChance = 0.0f;
        curItem = scroll;
        curUser = hero;
        if (this.charge > 0 && !this.scrolls.contains(scroll.getClass())) {
            final Scroll fScroll = scroll;
            final ExploitHandler handler = Buff.affect(hero, ExploitHandler.class);
            handler.scroll = scroll;
            GameScene.show(new WndOptions(new ItemSprite(this), Messages.get(this, "prompt", new Object[0]), Messages.get(this, "read_empowered", new Object[0]), new String[]{scroll.trueName(), Messages.get(ExoticScroll.regToExo.get(scroll.getClass()), "name", new Object[0])}){

                @Override
                protected void onSelect(int index) {
                    handler.detach();
                    if (index == 1) {
                        Scroll scroll = Reflection.newInstance(ExoticScroll.regToExo.get(fScroll.getClass()));
                        curItem = scroll;
                        --UnstableSpellbook.this.charge;
                        scroll.anonymize();
                        scroll.talentChance = 0.0f;
                        UnstableSpellbook.this.lastScroll = scroll.getClass().getName();   // MOD: 记住这张秘卷
                        UnstableSpellbook.this.checkForArtifactProc(curUser, scroll);
                        scroll.doRead();
                        Talent.onArtifactUsed(Dungeon.hero);
                    } else {
                        UnstableSpellbook.this.checkForArtifactProc(curUser, fScroll);
                        fScroll.doRead();
                        Talent.onArtifactUsed(Dungeon.hero);
                    }
                    Item.updateQuickslot();
                }

                @Override
                public void onBackPressed() {
                }
            });
        } else {
            this.checkForArtifactProc(curUser, scroll);
            scroll.doRead();
            Talent.onArtifactUsed(Dungeon.hero);
        }
        UnstableSpellbook.updateQuickslot();
    }

    private void checkForArtifactProc(Hero user, Scroll scroll) {
        block3: {
            block2: {
                if (!(scroll instanceof ScrollOfLullaby) && !(scroll instanceof ScrollOfRetribution) && !(scroll instanceof ScrollOfTerror)) break block2;
                for (Mob mob : Dungeon.level.mobs.toArray(new Mob[0])) {
                    if (!Dungeon.level.heroFOV[mob.pos]) continue;
                    UnstableSpellbook.artifactProc(mob, this.visiblyUpgraded(), 1);
                }
                break block3;
            }
            if (!(scroll instanceof ScrollOfRage)) break block3;
            for (Mob mob : Dungeon.level.mobs.toArray(new Mob[0])) {
                UnstableSpellbook.artifactProc(mob, this.visiblyUpgraded(), 1);
            }
        }
    }

    @Override
    protected Artifact.ArtifactBuff passiveBuff() {
        return new bookRecharge();
    }

    @Override
    public void charge(Hero target, float amount) {
        if (this.charge < this.chargeCap && !this.cursed && target.buff(MagicImmune.class) == null) {
            this.partialCharge += 0.1f * amount;
            while (this.partialCharge >= 1.0f) {
                this.partialCharge -= 1.0f;
                ++this.charge;
            }
            if (this.charge >= this.chargeCap) {
                this.partialCharge = 0.0f;
            }
            UnstableSpellbook.updateQuickslot();
        }
    }

    @Override
    public Item upgrade() {
        this.chargeCap = (int)((float)(this.level() + 1) * 0.6f) + 2;
        while (!this.scrolls.isEmpty() && this.scrolls.size() > this.levelCap - 1 - this.level()) {
            this.scrolls.remove(0);
        }
        return super.upgrade();
    }

    @Override
    public void resetForTrinity(int visibleLevel) {
        super.resetForTrinity(visibleLevel);
        this.setupScrolls();
        while (!this.scrolls.isEmpty() && this.scrolls.size() > this.levelCap - 1 - this.level()) {
            this.scrolls.remove(0);
        }
    }

    @Override
    public String desc() {
        Object desc = super.desc();
        if (this.isEquipped(Dungeon.hero)) {
            if (this.cursed) {
                desc = (String)desc + "\n\n" + Messages.get(this, "desc_cursed", new Object[0]);
            }
            if (this.level() < this.levelCap && this.scrolls.size() > 0) {
                desc = (String)desc + "\n\n" + Messages.get(this, "desc_index", new Object[0]);
                desc = (String)desc + "\n_" + Messages.get(this.scrolls.get(0), "name", new Object[0]) + "_";
                if (this.scrolls.size() > 1) {
                    desc = (String)desc + "\n_" + Messages.get(this.scrolls.get(1), "name", new Object[0]) + "_";
                }
            }
        }
        if (this.level() > 0) {
            desc = (String)desc + "\n\n" + Messages.get(this, "desc_empowered", new Object[0]);
        }
        return (String) desc;
    }

    @Override
    public void storeInBundle(Bundle bundle) {
        super.storeInBundle(bundle);
        bundle.put(SCROLLS, this.scrolls.toArray(new Class[this.scrolls.size()]));
        bundle.put(TORN_PAGES, this.tornPages.toArray(new String[0]));   // MOD
        bundle.put(TEAR_PENALTY, this.tearPenalty);                       // MOD
        bundle.put(LAST_SCROLL, this.lastScroll == null ? "" : this.lastScroll);   // MOD
        bundle.put(TEAR_CURSES, this.tearCurses);                                  // MOD
    }

    @Override
    public void restoreFromBundle(Bundle bundle) {
        super.restoreFromBundle(bundle);
        this.scrolls.clear();
        if (bundle.contains(SCROLLS) && bundle.getClassArray(SCROLLS) != null) {
            for (Class scroll : bundle.getClassArray(SCROLLS)) {
                if (scroll == null) continue;
                this.scrolls.add(scroll);
            }
        }
        // ===== MOD: 读回撕毁记录并同步充能上限 =====
        this.tornPages.clear();
        if (bundle.contains(TORN_PAGES) && bundle.getStringArray(TORN_PAGES) != null) {
            for (String v : bundle.getStringArray(TORN_PAGES)) {
                if (v != null) {
                    this.tornPages.add(v);
                }
            }
        }
        this.tearPenalty = bundle.contains(TEAR_PENALTY) ? bundle.getInt(TEAR_PENALTY) : 0;
        this.lastScroll = bundle.contains(LAST_SCROLL) ? bundle.getString(LAST_SCROLL) : null;   // MOD
        if (this.lastScroll != null && this.lastScroll.isEmpty()) {
            this.lastScroll = null;
        }
        this.tearCurses = bundle.contains(TEAR_CURSES) ? bundle.getInt(TEAR_CURSES) : 0;         // MOD
        this.syncChargeCap();
        // ===== MOD end =====
    }

    public static class ExploitHandler
    extends Buff {
        public Scroll scroll;

        public ExploitHandler() {
            this.actPriority = 100;
        }

        @Override
        public boolean act() {
            curUser = Dungeon.hero;
            curItem = this.scroll;
            this.scroll.anonymize();
            this.scroll.talentChance = 0.0f;
            Game.runOnRenderThread(new Callback(){

                @Override
                public void call() {
                    scroll.doRead();
                    Item.updateQuickslot();
                }
            });
            this.detach();
            return true;
        }

        @Override
        public void storeInBundle(Bundle bundle) {
            super.storeInBundle(bundle);
            bundle.put("scroll", this.scroll);
        }

        @Override
        public void restoreFromBundle(Bundle bundle) {
            super.restoreFromBundle(bundle);
            this.scroll = (Scroll)bundle.get("scroll");
        }
    }

    public class bookRecharge
    extends Artifact.ArtifactBuff {
        public bookRecharge() {
            super();   // ArtifactBuff 的外部实例由 UnstableSpellbook extends Artifact 隐式提供
        }

        @Override
        public boolean act() {
            if (UnstableSpellbook.this.charge < UnstableSpellbook.this.chargeCap && !UnstableSpellbook.this.cursed && this.target.buff(MagicImmune.class) == null && Regeneration.regenOn()) {
                float chargeGain = 1.0f / (120.0f - (float)(UnstableSpellbook.this.chargeCap - UnstableSpellbook.this.charge) * 5.0f);
                UnstableSpellbook.this.partialCharge += (chargeGain *= RingOfEnergy.artifactChargeMultiplier(this.target));
                while (UnstableSpellbook.this.partialCharge >= 1.0f) {
                    UnstableSpellbook.this.partialCharge -= 1.0f;
                    ++UnstableSpellbook.this.charge;
                    if (UnstableSpellbook.this.charge != UnstableSpellbook.this.chargeCap) continue;
                    UnstableSpellbook.this.partialCharge = 0.0f;
                }
            }
            Item.updateQuickslot();
            this.spend(1.0f);
            return true;
        }
    }
}
