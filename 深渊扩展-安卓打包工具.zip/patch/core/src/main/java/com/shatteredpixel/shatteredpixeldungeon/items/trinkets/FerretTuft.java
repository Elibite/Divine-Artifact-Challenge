package com.shatteredpixel.shatteredpixeldungeon.items.trinkets;

import com.shatteredpixel.shatteredpixeldungeon.messages.Messages;
import com.shatteredpixel.shatteredpixeldungeon.sprites.ItemSpriteSheet;

/**
 * MOD: 原版 {@code FerretTuft} 的整类覆盖。
 *
 * <p>原版是「双方闪避一起涨」：{@code Char.hit} 里不管谁在防守，都会乘一次这个倍率，
 * 所以对玩家来说增益（自己更能闪）和负面（敌人也更能闪）是同一个数字。</p>
 *
 * <p>额外等级（4~6，需炼金工具箱通过试炼）会把**这个共享倍率**往回退一档
 * （4 级按 2 级、5 级按 1 级、6 级按 0 级），也就是说敌人那边越来越占不到便宜；
 * 玩家自己少掉的部分由 {@code TrinketPerks.ferretHeroBonus()} 单独补回来
 * （挂在 {@code Hero.defenseSkill} 上），所以越升越赚。</p>
 */
public class FerretTuft extends Trinket {

    public FerretTuft() {
        this.image = ItemSpriteSheet.FERRET_TUFT;
    }

    @Override
    protected int upgradeEnergyCost() {
        return 6 + 2 * this.level();
    }

    @Override
    public String statsDesc() {
        if (this.isIdentified()) {
            return Messages.get(this, "stats_desc",
                    Messages.decimalFormat("#.##", 100.0f * (evasionMultiplier(this.buffedLvl()) - 1.0f)));
        }
        return Messages.get(this, "typical_stats_desc",
                Messages.decimalFormat("#.##", 100.0f * (evasionMultiplier(0) - 1.0f)));
    }

    public static float evasionMultiplier() {
        return evasionMultiplier(trinketLevel(FerretTuft.class));
    }

    public static float evasionMultiplier(int level) {
        if (level <= -1) {
            return 1.0f;
        }
        // MOD: 额外等级把「敌人也更能闪」的负面往回退（4→2 级、5→1 级、6→0 级）
        int tier = level <= 3 ? level : Math.max(0, 6 - level);
        return 1.0f + 0.125f * (float) (tier + 1);
    }
}
