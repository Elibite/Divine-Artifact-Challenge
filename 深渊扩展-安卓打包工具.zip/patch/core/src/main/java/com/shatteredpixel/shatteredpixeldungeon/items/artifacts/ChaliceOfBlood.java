/*
 * MOD: 整类覆盖（原版 ChaliceOfBlood）—— 把「物理命中相邻敌人 → 流血」改成「收集怪物血液」。
 *
 * 规则：
 *  - 玩家周围一圈（8 邻格）的敌人受到**物理伤害**（伤害来源是一个 Char，即刀剑/投掷物等）时，
 *    圣杯收集「伤害的 1/10，向上取整」并存入血池
 *  - 升级圣杯（PRICK）时，血池里的血液会**先代替玩家支付**要扣的血量，不够的部分才由玩家自己掉血
 *  - 收集需要先通过神器试炼（ArtifactTrial.isEnhanced）；开启「测试时间」时默认通过
 */
package com.shatteredpixel.shatteredpixeldungeon.items.artifacts;

import com.shatteredpixel.shatteredpixeldungeon.Badges;
import com.shatteredpixel.shatteredpixeldungeon.Challenges;
import com.shatteredpixel.shatteredpixeldungeon.Dungeon;
import com.shatteredpixel.shatteredpixeldungeon.actors.Char;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.MagicImmune;
import com.shatteredpixel.shatteredpixeldungeon.actors.hero.Hero;
import com.shatteredpixel.shatteredpixeldungeon.actors.hero.HeroSubClass;
import com.shatteredpixel.shatteredpixeldungeon.actors.hero.spells.HolyWard;
import com.shatteredpixel.shatteredpixeldungeon.effects.FloatingText;
import com.shatteredpixel.shatteredpixeldungeon.effects.particles.ShadowParticle;
import com.shatteredpixel.shatteredpixeldungeon.items.Ankh;
import com.shatteredpixel.shatteredpixeldungeon.items.BloodBag;
import com.shatteredpixel.shatteredpixeldungeon.items.Item;
import com.shatteredpixel.shatteredpixeldungeon.items.Waterskin;
import com.shatteredpixel.shatteredpixeldungeon.items.artifacts.Artifact;
import com.shatteredpixel.shatteredpixeldungeon.items.wands.WandOfLivingEarth;
import com.shatteredpixel.shatteredpixeldungeon.journal.Catalog;
import com.shatteredpixel.shatteredpixeldungeon.messages.Messages;
import com.shatteredpixel.shatteredpixeldungeon.plants.Earthroot;
import com.shatteredpixel.shatteredpixeldungeon.scenes.GameScene;
import com.shatteredpixel.shatteredpixeldungeon.sprites.ItemSprite;
import com.shatteredpixel.shatteredpixeldungeon.sprites.ItemSpriteSheet;
import com.shatteredpixel.shatteredpixeldungeon.utils.GLog;
import com.shatteredpixel.shatteredpixeldungeon.windows.WndOptions;
import com.watabou.noosa.audio.Sample;
import com.watabou.utils.Bundle;
import com.watabou.utils.Random;

import java.util.ArrayList;

public class ChaliceOfBlood
extends Artifact {
    public static final String AC_PRICK = "PRICK";
    public static final String AC_BAG = "BAG";
    public static final String AC_FINAL = "FINAL";

    // ===== MOD: 血池 =====
    private static final String BLOOD = "blood";
    /** 收集到的怪物血液，升级圣杯时先代替玩家扣血 */
    private int blood = 0;
    // ===== MOD: 立场 / 终祭 =====
    private int pureUpgrades = 0;          // 完全用自己的血完成的升级次数
    private boolean usedMixedBlood = false;    // 用过混入怪物血的血
    private boolean usedFullMonsterBag = false;// 用过整袋怪物血
    private boolean awakened = false;          // 已完成终祭，11 级
    private static final String PURE = "pure_upgrades";
    private static final String MIXED = "used_mixed";
    private static final String FULLBAG = "used_full_bag";
    private static final String AWAKENED = "awakened";
    // ===== MOD end =====

    public int blood() {
        return this.blood;
    }

    /** MOD: 用血池支付 damage 点，返回实际支付了多少（血池会相应减少） */
    int payWithBlood(int damage) {
        if (damage <= 0 || this.blood <= 0) {
            return 0;
        }
        int paid = Math.min(this.blood, damage);
        this.blood -= paid;
        return paid;
    }

    /**
     * MOD: 由 Mob.damage() 调用 —— 玩家一圈内的敌人受到物理伤害时收集血液。
     * 物理伤害的判定：伤害来源是一个 Char（刀剑、投掷物、其他怪物的近战…），法杖/卷轴/陷阱不算。
     */
    public static void collectFrom(int dmg, int mobPos, Object src) {
        if (dmg <= 0 || Dungeon.hero == null || Dungeon.hero.belongings == null || Dungeon.level == null) {
            return;
        }
        // MOD: 只收「玩家本人用近战武器」打出来的物理伤害：
        //   - 流血/中毒这类 debuff 伤害的来源是 buff，不是 hero → 被 src 判断滤掉
        //   - 法杖攻击不算近战 → 再看一眼当前攻击用的武器
        if (src != Dungeon.hero) {
            return;
        }

        if (!Dungeon.level.adjacent(mobPos, Dungeon.hero.pos)) {
            return;   // 只收「身边一圈」
        }
        // MOD: 血袋的「自动收集」——只要袋子开着，不需要圣杯装备
        BloodBag bag = Dungeon.hero.belongings.getItem(BloodBag.class);
        if (bag != null && bag.autoCollect()) {
            bag.addBlood((dmg + 9) / 10);
        }
        ChaliceOfBlood chalice = Dungeon.hero.belongings.getItem(ChaliceOfBlood.class);
        if (chalice == null || !chalice.isEquipped(Dungeon.hero) || chalice.cursed) {
            return;
        }
        if (!ArtifactTrial.isEnhanced(chalice)) {
            return;   // 需要先通过神器试炼（「测试时间」下默认通过）
        }
        int gain = (dmg + 9) / 10;   // 十分之一，向上取整
        if (gain <= 0) {
            return;
        }
        chalice.blood += gain;
    }
    // ===== MOD end =====

    public ChaliceOfBlood() {
        this.image = ItemSpriteSheet.ARTIFACT_CHALICE1;
        this.levelCap = 10;
    }

    @Override
    public ArrayList<String> actions(Hero hero) {
        ArrayList<String> actions = super.actions(hero);
        if (this.isEquipped(hero) && this.level() < this.levelCap && !this.cursed && !hero.isInvulnerable(this.getClass()) && hero.buff(MagicImmune.class) == null) {
            actions.add(AC_PRICK);
        }
        if (this.isEquipped(hero) && !this.cursed) {
            actions.add(AC_BAG);
        }
        if (this.isEquipped(hero) && !this.cursed && this.canFinalSacrifice(hero)) {
            actions.add(AC_FINAL);
        }
        return actions;
    }

    @Override
    public void execute(Hero hero, String action) {
        super.execute(hero, action);
        if (action.equals(AC_BAG)) {
            this.talkToChalice(hero);
        }
        if (action.equals(AC_FINAL)) {
            this.finalSacrifice(hero);
        }
        if (action.equals(AC_PRICK)) {
            int minDmg = this.minPrickDmg();
            int maxDmg = this.maxPrickDmg();
            int totalHeroHP = hero.HP + hero.shielding();
            float deathChance = 0.0f;
            if (totalHeroHP <= maxDmg) {
                deathChance = (float)(maxDmg - (totalHeroHP - 1)) / (float)(maxDmg - minDmg + 1);
                if (deathChance < 0.5f) {
                    deathChance = (float)Math.pow(2.0f * deathChance, 2.0) / 2.0f;
                } else if (deathChance < 1.0f) {
                    deathChance = 1.0f - deathChance;
                    deathChance = (float)Math.pow(2.0f * deathChance, 2.0) / 2.0f;
                    deathChance = 1.0f - deathChance;
                } else {
                    deathChance = 1.0f;
                }
            }
            // MOD: 血池会先代替玩家扣血，提醒一句
            String warn = Messages.get(this, "prick_warn", minDmg, maxDmg, Messages.decimalFormat("#.##", 100.0f * deathChance));
            if (this.blood > 0) {
                warn = warn + "\n\n" + "血池里存着 " + this.blood + " 点怪物血液，升级时会先代替你扣血。";
            }
            GameScene.show(new WndOptions(new ItemSprite(this), Messages.titleCase(this.name()), warn, new String[]{Messages.get(this, "yes", new Object[0]), Messages.get(this, "no", new Object[0])}){

                @Override
                protected void onSelect(int index) {
                    if (index == 0) {
                        ChaliceOfBlood.this.prick(Dungeon.hero);
                    }
                }
            });
        }
    }

    // ===== MOD: 三重立场 =====

    /** 0 = 友好（纯净的血喝得舒坦）；1 = 中立（混过怪物血）；2 = 恶劣（饿着，或喝的全是怪物血） */
    public int stance() {
        if (this.usedFullMonsterBag) {
            return UnstableSpellbook.STANCE_NASTY;
        }
        if (this.usedMixedBlood) {
            return UnstableSpellbook.STANCE_NEUTRAL;
        }
        if (this.pureUpgrades >= 2) {
            return UnstableSpellbook.STANCE_FRIENDLY;
        }
        return UnstableSpellbook.STANCE_NASTY;
    }

    // ===== MOD: 终极献祭 =====

    private boolean canFinalSacrifice(Hero hero) {
        if (this.awakened || this.level() < this.levelCap) {
            return false;
        }
        if (this.stance() != UnstableSpellbook.STANCE_FRIENDLY) {
            return false;
        }
        if (hero.HP < hero.HT) {
            return false;
        }
        return hero.belongings.getItem(Ankh.class) != null && hero.belongings.getItem(Ankh.class).quantity() > 0;
    }

    private void finalSacrifice(final Hero hero) {
        final Ankh ankh = hero.belongings.getItem(Ankh.class);
        GameScene.show(new WndOptions(new ItemSprite(this), "最后的献祭",
                "圣杯安静下来，杯壁贴着你发烫。\\n\\n「把那个十字架放进来。」它说，"
                        + "「再给我你身上几乎全部的血。只留一滴——够你活着走到下一层就行。」\\n\\n"
                        + "「之后，我真正属于你。」",
                new String[]{"把十字架和血都给它", "再想想"}) {
            @Override
            protected void onSelect(int index) {
                if (index != 0) {
                    return;
                }
                ankh.detach(hero.belongings.backpack);
                int leave = 1;
                hero.HP = Math.max(1, (int)Math.ceil(hero.HP * 0.01f));
                hero.sprite.showStatusWithIcon(0xFF0000, "-" + (hero.HT - hero.HP), FloatingText.NO_ICON);
                ChaliceOfBlood.this.levelCap = 11;
                ChaliceOfBlood.this.upgrade();
                ChaliceOfBlood.this.awakened = true;
                GLog.p("圣杯把十字架吞了下去，杯身上的血纹亮得像烧红的铁。\\n它升到了第 11 级——从现在起，它回血的速度是过去的两倍。");
            }
        });
    }

    // ===== MOD: 神器挑战下自动把水袋改造成血袋 =====

    @Override
    public boolean doEquip(Hero hero) {
        boolean ok = super.doEquip(hero);
        if (ok) {
            autoConvertSkin(hero);
        }
        return ok;
    }

    private void autoConvertSkin(Hero hero) {
        if (hero == null || hero.belongings == null || Dungeon.level == null) {
            return;
        }
        if ((Dungeon.challenges & Challenges.ARTIFACT) == 0) {
            return;
        }
        if (hero.belongings.getItem(BloodBag.class) != null) {
            return;
        }
        Waterskin skin = hero.belongings.getItem(Waterskin.class);
        if (skin == null) {
            return;
        }
        if (!this.cursed) {
            drinkAll(hero, skin);
        }
        skin.detach(hero.belongings.backpack);
        BloodBag bag = new BloodBag();
        bag.collect();
        GLog.p(this.cursed
                ? "圣杯根本不容你说话——水袋被它一口咬住，里面的水哗地淌了一地。"
                : "圣杯咬住你的水袋。它先等你把水喝完，才慢慢把它嚼成了只装血的袋子。");
    }

    /** 未诅咒的圣杯允许先把水喝光（最多灌 20 次，够把一袋喝完） */
    private void drinkAll(Hero hero, Waterskin skin) {
        for (int i = 0; i < 25; i++) {
            int vol;
            try {
                String st = skin.status();           // "12/20"
                int slash = st.indexOf(47);
                vol = slash > 0 ? Integer.parseInt(st.substring(0, slash).trim()) : 0;
            } catch (Throwable t) {
                return;
            }
            if (vol <= 0) {
                return;
            }
            skin.execute(hero, "DRINK");
        }
    }

    // ===== MOD: 和圣杯说话 / 血袋 =====

    @Override
    public String actionName(String action, Hero hero) {
        if (AC_BAG.equals(action)) {
            return "与圣杯说话";
        }
        return super.actionName(action, hero);
    }

    private void talkToChalice(final Hero hero) {
        Waterskin skin = hero.belongings.getItem(Waterskin.class);
        final boolean canConvert = skin != null && !(skin instanceof BloodBag);
        String text = canConvert
                ? "圣杯在你掌心发烫，像是在等你开口。\n\n「你的水袋……改一改，能装更多有用的东西。」"
                : "圣杯在你掌心发烫，像是不太想理你。\n\n「你那些破袋子，我已经看过了。」";
        String[] opts = canConvert
                ? new String[]{"把我的水袋改造成血袋", "算了"}
                : new String[]{"算了"};
        GameScene.show(new WndOptions(new ItemSprite(this), "蓄血圣杯", text, opts) {
            @Override
            protected void onSelect(int index) {
                if (canConvert && index == 0) {
                    convertSkin(hero);
                }
            }
        });
    }

    private void convertSkin(Hero hero) {
        Waterskin skin = hero.belongings.getItem(Waterskin.class);
        if (skin == null || skin instanceof BloodBag) {
            GLog.i("你身上没有可以改造的水袋。");
            return;
        }
        skin.detach(hero.belongings.backpack);
        BloodBag bag = new BloodBag();
        bag.collect();
        GLog.p("圣杯咬住你的水袋，慢慢嚼了嚼——它变成了一个只装血的袋子。");
    }

    /** 血袋倒进来的血，之后献祭时先替玩家扣 */
    public void receiveBagBlood(int amount) {
        if (amount > 0) {
            this.blood += amount;
        }
    }
    // ===== MOD end =====

    private int minPrickDmg() {
        return (int)Math.ceil(3.0f + 2.5f * (float)(this.level() * this.level()));
    }

    private int maxPrickDmg() {
        return (int)Math.floor(7.0f + 3.5f * (float)(this.level() * this.level()));
    }

    private void prick(Hero hero) {
        WandOfLivingEarth.RockArmor rockArmor;
        int damage = Random.NormalIntRange(this.minPrickDmg(), this.maxPrickDmg());
        Earthroot.Armor armor = hero.buff(Earthroot.Armor.class);
        if (armor != null) {
            damage = armor.absorb(damage);
        }
        if (hero.buff(MagicImmune.class) != null && hero.buff(HolyWard.HolyArmBuff.class) != null) {
            damage -= hero.subClass == HeroSubClass.PALADIN ? 3 : 1;
        }
        if ((rockArmor = hero.buff(WandOfLivingEarth.RockArmor.class)) != null) {
            damage = rockArmor.absorb(damage);
        }
        hero.sprite.operate(hero.pos);
        hero.busy();
        hero.spend(1.0f);
        GLog.w(Messages.get(this, "onprick", new Object[0]), new Object[0]);
        if ((damage -= hero.drRoll()) <= 0) {
            damage = 1;
        } else {
            Sample.INSTANCE.play("sounds/cursed.mp3");
            hero.sprite.emitter().burst(ShadowParticle.CURSE, 4 + damage / 10);
        }
        // ===== MOD: 血池里的怪物血液先代替玩家支付 =====
        int beforePay = damage;
        int paid = this.payWithBlood(damage);
        damage -= paid;
        if (paid > 0) {
            this.usedMixedBlood = true;
            if (paid >= beforePay) {
                this.usedFullMonsterBag = true;
            }
        }
        if (paid > 0) {
            GLog.i("圣杯吞下了 " + paid + " 点储存的怪物血液。");
            hero.sprite.showStatusWithIcon(0xFF0000, "-" + paid + " 血池", FloatingText.NO_ICON);
        }
        if (damage > 0) {
            hero.damage(damage, this);
        }
        // ===== MOD end =====
        if (!hero.isAlive()) {
            Badges.validateDeathFromFriendlyMagic();
            Dungeon.fail(this);
            GLog.n(Messages.get(this, "ondeath", new Object[0]), new Object[0]);
        } else {
            this.upgrade();
            if (paid == 0) {
                this.pureUpgrades++;
            }
            Dungeon.hero.trackUpgrade(this, 1);
            Catalog.countUse(this.getClass());
        }
    }

    @Override
    public Item upgrade() {
        if (this.level() >= 6) {
            this.image = ItemSpriteSheet.ARTIFACT_CHALICE3;
        } else if (this.level() >= 2) {
            this.image = ItemSpriteSheet.ARTIFACT_CHALICE2;
        }
        return super.upgrade();
    }

    @Override
    public void storeInBundle(Bundle bundle) {
        super.storeInBundle(bundle);
        bundle.put(BLOOD, this.blood);
        bundle.put(PURE, this.pureUpgrades);
        bundle.put(MIXED, this.usedMixedBlood);
        bundle.put(FULLBAG, this.usedFullMonsterBag);
        bundle.put(AWAKENED, this.awakened);   // MOD
    }

    @Override
    public void restoreFromBundle(Bundle bundle) {
        super.restoreFromBundle(bundle);
        this.blood = bundle.contains(BLOOD) ? bundle.getInt(BLOOD) : 0;
        this.pureUpgrades = bundle.contains(PURE) ? bundle.getInt(PURE) : 0;
        this.usedMixedBlood = bundle.contains(MIXED) && bundle.getBoolean(MIXED);
        this.usedFullMonsterBag = bundle.contains(FULLBAG) && bundle.getBoolean(FULLBAG);
        this.awakened = bundle.contains(AWAKENED) && bundle.getBoolean(AWAKENED);
        if (this.awakened) {
            this.levelCap = 11;
        }   // MOD
        if (this.level() >= 7) {
            this.image = ItemSpriteSheet.ARTIFACT_CHALICE3;
        } else if (this.level() >= 3) {
            this.image = ItemSpriteSheet.ARTIFACT_CHALICE2;
        }
    }

    @Override
    protected Artifact.ArtifactBuff passiveBuff() {
        return new chaliceRegen();
    }

    @Override
    public void charge(Hero target, float amount) {
        if (this.awakened) {
            amount *= 2f;   // MOD: 终祭之后回血效率翻倍
        }
        if (this.cursed || target.buff(MagicImmune.class) != null) {
            return;
        }
        if (target.isStarving()) {
            return;
        }
        float healDelay = 10.0f - (1.33f + (float)this.level() * 0.667f);
        float heal = 5.0f / (healDelay /= amount);
        if (Random.Float() < heal % 1.0f) {
            heal += 1.0f;
        }
        if (heal >= 1.0f && target.HP < target.HT) {
            target.HP = Math.min(target.HT, target.HP + (int)heal);
            target.sprite.showStatusWithIcon(65280, Integer.toString((int)heal), FloatingText.HEALING, new Object[0]);
            if (target.HP == target.HT && target instanceof Hero) {
                target.resting = false;
            }
        }
    }

    @Override
    public String desc() {
        String desc = super.desc();
        if (this.isEquipped(Dungeon.hero)) {
            desc = desc + "\n\n";
            desc = this.cursed ? desc + Messages.get(this, "desc_cursed", new Object[0]) : (this.level() == 0 ? desc + Messages.get(this, "desc_1", new Object[0]) : (this.level() < this.levelCap ? desc + Messages.get(this, "desc_2", new Object[0]) : desc + Messages.get(this, "desc_3", new Object[0])));
        }
        // MOD: 血池
        if (this.isEquipped(Dungeon.hero) && (this.blood > 0 || ArtifactTrial.isEnhanced(this))) {
            desc = desc + "\n\n" + "血池：" + this.blood + " 点怪物血液（升级圣杯时优先扣除）。";
        }
        return desc;
    }

    public class chaliceRegen
    extends Artifact.ArtifactBuff {
        public chaliceRegen() {
            super();   // CFR 产物写的是 super(ChaliceOfBlood.this)，其实外层实例由编译器自动传
        }
    }
}
