package com.shatteredpixel.shatteredpixeldungeon.items.trinkets;

import com.shatteredpixel.shatteredpixeldungeon.messages.Messages;
import com.shatteredpixel.shatteredpixeldungeon.sprites.ItemSpriteSheet;

/**
 * MOD: 原版 {@code SaltCube} 的整类覆盖。
 *
 * <p>与 4.0.2 的差别只有一处：额外等级（4~6，需炼金工具箱通过试炼）会把
 * 「降低生命恢复」的惩罚往回退一档——4 级按 2 级算、5 级按 1 级、6 级回到 0 级。
 * 减缓饥饿的好处（{@code hungerGainMultiplier}）仍按真实等级成长。</p>
 */
public class SaltCube extends Trinket {

    public SaltCube() {
        this.image = ItemSpriteSheet.SALT_CUBE;
    }

    @Override
    protected int upgradeEnergyCost() {
        return 6 + 2 * this.level();
    }

    @Override
    public String statsDesc() {
        if (this.isIdentified()) {
            return Messages.get(this, "stats_desc",
                    Messages.decimalFormat("#.##",
                            100.0f * (1.0f / hungerGainMultiplier(this.buffedLvl()) - 1.0f)),
                    Messages.decimalFormat("#.##",
                            100.0f * (1.0f - healthRegenMultiplier(this.buffedLvl()))));
        }
        return Messages.get(this, "typical_stats_desc",
                Messages.decimalFormat("#.##", 100.0f * (1.0f / hungerGainMultiplier(0) - 1.0f)),
                Messages.decimalFormat("#.##", 100.0f * (1.0f - healthRegenMultiplier(0))));
    }

    public static float hungerGainMultiplier() {
        return hungerGainMultiplier(trinketLevel(SaltCube.class));
    }

    public static float hungerGainMultiplier(int level) {
        if (level == -1) {
            return 1.0f;
        }
        return 1.0f / (1.0f + 0.25f * (float) (level + 1));
    }

    public static float healthRegenMultiplier() {
        return healthRegenMultiplier(trinketLevel(SaltCube.class));
    }

    public static float healthRegenMultiplier(int level) {
        if (level < 0) {
            return 1.0f;
        }
        // MOD: 额外等级把「恢复变慢」的惩罚往回退（4→2 级、5→1 级、6→0 级）
        int penaltyLevel = level <= 3 ? level : Math.max(0, 6 - level);
        switch (penaltyLevel) {
            case 0:
                return 0.84f;
            case 1:
                return 0.73f;
            case 2:
                return 0.66f;
            default:
                return 0.6f;
        }
    }
}
