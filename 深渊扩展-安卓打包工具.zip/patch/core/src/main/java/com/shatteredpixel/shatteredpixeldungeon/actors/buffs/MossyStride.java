package com.shatteredpixel.shatteredpixeldungeon.actors.buffs;

import com.shatteredpixel.shatteredpixeldungeon.ui.BuffIndicator;

/**
 * MOD: 苔藓丛簇（强化）——「脚下生青」的移速加成。
 *
 * <p>踩过未枯萎的高草、或者在浅水里走，会挂上这个 Buff：
 * 只要它在，英雄移速 ×1.25。效果本身由 {@code Hero.speed()} 读取。</p>
 */
public class MossyStride extends FlavourBuff {

    {
        type = buffType.POSITIVE;
        announced = false;
    }

    @Override
    public int icon() {
        return BuffIndicator.HERB_HEALING;
    }

    @Override
    public String name() {
        return "苔藓生风";
    }

    @Override
    public String desc() {
        return "脚下的草木顺着步子铺开，走得比平时轻快。";
    }
}
