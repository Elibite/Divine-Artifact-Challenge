package com.shatteredpixel.shatteredpixeldungeon.actors.blobs;

import com.shatteredpixel.shatteredpixeldungeon.Challenges;
import com.shatteredpixel.shatteredpixeldungeon.Dungeon;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.Buff;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.ShadowZoneBuff;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.ShadowZoneMark;
import com.shatteredpixel.shatteredpixeldungeon.levels.Level;
import com.watabou.utils.Bundle;

/** MOD: 自然之履的「暗影融合」区域（5×5，随楼层存档保存） */
public class ShadowZone extends Blob {

    public static final int RADIUS = 2;

    private static final String CENTER = "center";

    public int center = -1;


    {
        this.volume = 0;
        this.alwaysVisible = false;
    }

    public ShadowZone() {
    }

    public ShadowZone(int center) {
        this.center = center;
        this.volume = 0;
    }

    public boolean contains(int cell) {
        if (this.center < 0 || Dungeon.level == null) {
            return false;
        }
        int w = Dungeon.level.width();
        int cx = this.center % w;
        int cy = this.center / w;
        int x = cell % w;
        int y = cell / w;
        return Math.abs(x - cx) <= RADIUS && Math.abs(y - cy) <= RADIUS;
    }

    /** 每回合由 Hero.act() 调用 */
    public static void tick() {
        if (!com.shatteredpixel.shatteredpixeldungeon.ModContent.enabled()) {
            return;
        }
        if (Dungeon.level == null || Dungeon.hero == null) {
            return;
        }
        try {
            Blob blob = Dungeon.level.blobs.get(ShadowZone.class);
            ShadowZone zone = (blob instanceof ShadowZone) ? (ShadowZone) blob : null;
            // 只认我们造出来的区域本身，绝不把普通草地当成暗影区域
            boolean inside = com.shatteredpixel.shatteredpixeldungeon.items.artifacts.ArtifactTrial
                    .isEnhancedClass(com.shatteredpixel.shatteredpixeldungeon.items.artifacts.SandalsOfNature.class)
                    && Dungeon.hero.belongings != null
                    && Dungeon.hero.belongings.artifact()
                    instanceof com.shatteredpixel.shatteredpixeldungeon.items.artifacts.SandalsOfNature
                    && zone != null
                    && zone.contains(Dungeon.hero.pos);

            ShadowZoneMark mark = Dungeon.hero.buff(ShadowZoneMark.class);

            if (inside) {
                if (mark == null) {
                    mark = Buff.affect(Dungeon.hero, ShadowZoneMark.class);
                    if (mark != null) {
                        mark.savedView = Dungeon.hero.viewDistance;
                        applyVisionCap();
                    }
                }
                // 攻击会破除隐形，只要还在区域内就补回来
                if (Dungeon.hero.buff(ShadowZoneBuff.class) == null) {
                    Buff.affect(Dungeon.hero, ShadowZoneBuff.class, 999f);
                }
            } else if (mark != null) {
                if (Dungeon.hero.buff(ShadowZoneBuff.class) != null) {
                    Buff.detach(Dungeon.hero, ShadowZoneBuff.class);
                }
                if (mark.savedView > 0) {
                    Dungeon.hero.viewDistance = mark.savedView;
                }
                mark.detach();
            }
        } catch (Throwable ignored) {
        }
    }

    /** 视野压到 1 格，保留鹰眼天赋；有灵视时不干预 */
    public static void applyVisionCap() {
        if (Dungeon.hero == null) {
            return;
        }
        try {
            if (Dungeon.hero.buff(com.shatteredpixel.shatteredpixeldungeon.actors.buffs.MindVision.class) != null) {
                return;
            }
            int cap = 1;
            try {
                cap += Dungeon.hero.pointsInTalent(
                        com.shatteredpixel.shatteredpixeldungeon.actors.hero.Talent.EAGLE_EYE);
            } catch (Throwable ignored) {
            }
            Dungeon.hero.viewDistance = Math.max(1, cap);
        } catch (Throwable ignored) {
        }
    }

    public static void createAt(Level level, int cell) {
        if (level == null) {
            return;
        }
        level.blobs.put(ShadowZone.class, new ShadowZone(cell));
    }

    @Override
    public boolean act() {
        // 必须消耗时间，否则读档重建后 Actor 队列会死循环
        this.spend(1.0f);
        return true;
    }

    @Override
    public void storeInBundle(Bundle bundle) {
        super.storeInBundle(bundle);
        bundle.put(CENTER, this.center);
    }

    @Override
    public void restoreFromBundle(Bundle bundle) {
        super.restoreFromBundle(bundle);
        this.center = bundle.getInt(CENTER);
    }
}
