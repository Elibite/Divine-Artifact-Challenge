package com.shatteredpixel.shatteredpixeldungeon.items.spells;

import com.shatteredpixel.shatteredpixeldungeon.Dungeon;
import com.shatteredpixel.shatteredpixeldungeon.actors.hero.Hero;
import com.shatteredpixel.shatteredpixeldungeon.items.Item;
import com.shatteredpixel.shatteredpixeldungeon.levels.traps.Trap;
import com.shatteredpixel.shatteredpixeldungeon.messages.Messages;
import com.shatteredpixel.shatteredpixeldungeon.scenes.CellSelector;
import com.shatteredpixel.shatteredpixeldungeon.scenes.GameScene;
import com.shatteredpixel.shatteredpixeldungeon.sprites.ItemSprite;
import com.shatteredpixel.shatteredpixeldungeon.sprites.ItemSpriteSheet;
import com.shatteredpixel.shatteredpixeldungeon.utils.GLog;
import com.shatteredpixel.shatteredpixeldungeon.journal.Bestiary;
import com.watabou.noosa.audio.Sample;
import com.watabou.utils.Bundle;
import com.watabou.utils.Reflection;

import java.util.ArrayList;

/**
 * MOD: 陷阱晶柱 —— 由「陷阱元件」把地上的陷阱收进背包得到的道具。
 *
 * <p>每一枚只装着一个陷阱（记录类名），使用后把那股力量在身边三格内释放一次。
 * 原版 {@code ReclaimTrap} 是把陷阱存在英雄身上（一次只能存一个），
 * 这里改成**按物品存**，才能一次收走脚下一圈的陷阱。</p>
 */
public class TrapCrystal extends Item {

    public static final String AC_CAST = "CAST";

    private static final String TRAP = "trap";

    private Class<? extends Trap> storedTrap = null;

    {
        image = ItemSpriteSheet.RECLAIM_TRAP;
        stackable = false;
        bones = false;
        defaultAction = AC_CAST;
        usesTargeting = true;
    }

    public TrapCrystal() {
    }

    public TrapCrystal(Class<? extends Trap> trap) {
        this.storedTrap = trap;
    }

    public Class<? extends Trap> storedTrap() {
        return storedTrap;
    }

    @Override
    public ArrayList<String> actions(Hero hero) {
        ArrayList<String> actions = super.actions(hero);
        if (storedTrap != null) {
            actions.add(AC_CAST);
        }
        return actions;
    }

    @Override
    public void execute(Hero hero, String action) {
        super.execute(hero, action);
        if (!AC_CAST.equals(action)) {
            return;
        }
        if (storedTrap == null) {
            GLog.w("这枚晶柱里什么都没有。");
            return;
        }
        GameScene.selectCell(caster);
    }

    private final CellSelector.Listener caster = new CellSelector.Listener() {
        @Override
        public void onSelect(Integer cell) {
            if (cell == null || storedTrap == null) {
                return;
            }
            Hero hero = Dungeon.hero;
            if (hero == null || Dungeon.level == null) {
                return;
            }
            if (Dungeon.level.distance(hero.pos, cell) > 3) {
                GLog.w("晶柱的力量只能释放在身边三格内。");
                return;
            }
            if (!Dungeon.level.passable[cell] && !Dungeon.level.avoid[cell]) {
                GLog.w("那里放不开。");
                return;
            }
            if (Dungeon.level.traps.get(cell) != null) {
                GLog.w("那里已经有一个陷阱了。");
                return;
            }
            Trap t = Reflection.newInstance(storedTrap);
            t.pos = cell;
            t.reclaimed = true;
            Bestiary.countEncounter(t.getClass());
            Sample.INSTANCE.play("sounds/lightning.mp3");
            t.activate();
            TrapCrystal.this.detachAll(hero.belongings.backpack);
            hero.spendAndNext(1.0f);
            Item.updateQuickslot();
        }

        @Override
        public String prompt() {
            return "选一个位置释放晶柱里的陷阱";
        }
    };

    @Override
    public String name() {
        if (storedTrap != null) {
            return "陷阱晶柱（" + Messages.get(storedTrap, "name") + "）";
        }
        return "陷阱晶柱";
    }

    @Override
    public String desc() {
        if (storedTrap != null) {
            return "一枚封着「" + Messages.get(storedTrap, "name") + "」力量的小晶柱。\n\n"
                    + "使用后可以在身边三格内把它放出来，再触发一次。";
        }
        return "一枚空晶柱，什么也没封着。";
    }

    @Override
    public ItemSprite.Glowing glowing() {
        if (storedTrap == null) {
            return null;
        }
        try {
            return new ItemSprite.Glowing(Reflection.newInstance(storedTrap).color);
        } catch (Throwable t) {
            return null;
        }
    }

    @Override
    public boolean isUpgradable() {
        return false;
    }

    @Override
    public boolean isIdentified() {
        return true;
    }

    @Override
    public int value() {
        return 40 * Math.max(1, quantity());
    }

    @Override
    public void storeInBundle(Bundle bundle) {
        super.storeInBundle(bundle);
        if (storedTrap != null) {
            bundle.put(TRAP, storedTrap);
        }
    }

    @Override
    public void restoreFromBundle(Bundle bundle) {
        super.restoreFromBundle(bundle);
        storedTrap = bundle.contains(TRAP) ? bundle.getClass(TRAP) : null;
    }
}
