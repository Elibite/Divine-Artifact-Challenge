package com.shatteredpixel.shatteredpixeldungeon.tiles;

import com.shatteredpixel.shatteredpixeldungeon.Dungeon;
import com.shatteredpixel.shatteredpixeldungeon.levels.Level;
import com.shatteredpixel.shatteredpixeldungeon.levels.Terrain;
import com.watabou.noosa.Image;
import com.watabou.noosa.Tilemap;
import com.watabou.utils.Bundle;

/**
 * MOD: 骷髅钥匙开出来的「门」。
 *
 * <b>画面完全交给引擎</b>：门格就是原版的 {@code Terrain.DOOR}，所以引擎会按朝向自己叠好一扇门——
 *
 * <pre>
 *   横排墙：门格 RAISED_DOOR(112) + 上方一格 DOOR_OVERHANG(224)
 *   竖排墙：上方一格 DOOR_SIDEWAYS(227) + 门格 RAISED_DOOR_SIDEWAYS(116)
 *           + 门格墙裙 DOOR_SIDEWAYS_OVERHANG_CLOSED(212)
 * </pre>
 *
 * 所以本类的 {@link #updateAll(int[])} 把数据全填 -1，**一张贴图都不画**。这样关卡原有的
 * 墙面拼接一个像素都不会被动到。（早先几版把门格改成空地、再自绘门贴图，结果门上下两格的
 * 面砖全丢了——地块一动，墙面拼接就跟着坏。）
 *
 * 这个类真正负责的是三件与画面无关的事：
 * <ul>
 *   <li>把门的位置存在关卡自己的 {@code customTiles} 里，随存档保留</li>
 *   <li>检视文案（{@link #name(int, int)} / {@link #desc(int, int)}）</li>
 *   <li>检视窗口左上角的示例图标（{@link #image(int, int)}，统一用「关着的门」那张）</li>
 * </ul>
 */
public class DoorTilemap extends CustomTilemap {

    private static final String CELL = "cell";
    private static final String MAIN = "main";
    private static final String OPEN = "open";
    private static final String BEYOND = "beyond";
    private static final String BEYOND_TERRAIN = "beyond_terrain";
    private static final String CELL_TERRAIN = "cell_terrain";

    /** 门所在格（门楣画在它上面一格） */
    public int cell = -1;
    /** true = 主门，false = 副门 */
    public boolean main = true;
    /** 门里有角色时画「开着」那一帧，{@code SkeletonKey#onHeroTurn()} 每回合同步 */
    private boolean open = false;
    /** 建门时额外刨开的「门另一侧」那一格（-1 = 没有），拆门时要还原 */
    public int beyond = -1;
    /** 那一格原本的地块 */
    public int beyondTerrain = -1;
    /** 门格原本的地块（拆门时还原回去，通常是一堵墙） */
    public int cellTerrain = -1;
    /** true = 用 mod 自带的窄门图（竖排墙），false = 用关卡地块集里的正面门 */
    private boolean custom = false;

    private static final String[] REGIONS = {"sewers", "prison", "caves", "city", "halls"};

    /** 地区 -> mod 自带的窄门贴图（照着关卡地块集的文件名匹配） */
    private static String customTextureFor(String tilesTex) {
        String region = "sewers";
        if (tilesTex != null) {
            for (String r : REGIONS) {
                if (tilesTex.contains("_" + r)) {
                    region = r;
                    break;
                }
            }
        }
        return "environment/custom_tiles/skeleton_door_" + region + ".png";
    }
    public DoorTilemap() {
    }

    public DoorTilemap(int cell, boolean main, Level level) {
        this.cell = cell;
        this.main = main;
        this.custom = sidewaysAt(cell);
        this.texture = custom ? customTextureFor(level.tilesTex()) : level.tilesTex();
        layout(level);
    }

    /**
     * MOD: 这扇门在竖排墙上吗？——看**通道开在哪条轴上**：
     * 左右两侧都通（或至少比上下多）就算竖排墙，用原版的侧视门；其余（横排墙、拐角墙）画正面门。
     */
    public static boolean sidewaysAt(int cell) {
        if (Dungeon.level == null || Dungeon.level.passable == null) {
            return false;
        }
        int w = Dungeon.level.width();
        int len = Dungeon.level.length();
        if (w <= 0 || cell < w || cell >= len) {
            return false;
        }
        boolean[] pass = Dungeon.level.passable;
        int openEW = (cell % w != 0 && pass[cell - 1] ? 1 : 0)
                + (cell % w != w - 1 && cell + 1 < len && pass[cell + 1] ? 1 : 0);
        int openNS = (pass[cell - w] ? 1 : 0)
                + (cell + w < len && pass[cell + w] ? 1 : 0);
        return openEW > openNS;
    }

    /** 门格一律用真正的门地块：可通行，引擎会按朝向画完整的一扇门 */
    public static int terrainFor(int cell) {
        return Terrain.DOOR;
    }

    /** 门贴图占「门格 + 上面一格」；门在地图第一行时没有上方格子，就只画门本身 */
    private void layout(Level level) {
        int w = level.width();
        int x = cell % w;
        int y = cell / w;
        if (y > 0) {
            setRect(x, y - 1, 1, 2);
        } else {
            setRect(x, y, 1, 1);
        }
    }

    @Override
    public Tilemap create() {
        this.custom = false;
        // 读档时 Dungeon.level 才刚建好，贴图路径要等到这时候才能取
        if (this.texture == null) {
            String tex = Dungeon.level == null ? null : Dungeon.level.tilesTex();
            this.texture = tex != null ? tex : "environment/tiles_sewers.png";
        }
        Tilemap v = super.create();
        // 参考原版 Carpet 的写法：map() 内部会触发 updateMap() → updateAll(data)
        v.map(new int[this.tileW * this.tileH], this.tileW);
        return v;
    }

    /**
     * MOD: 一张都不画——两种朝向都交给引擎（横排 112+224，竖排 227+116+212），
     * 也就是和游戏自带的门完全一样。之前自己画过好几版，每一版都会跟墙面图层打架。
     * 检视用的图标/文案由 image()/name()/desc() 提供，不依赖这张贴图有没有画东西。
     */
    @Override
    protected void updateAll(int[] data) {
        java.util.Arrays.fill(data, -1);
    }

    /** 地块被改（走进去变成 OPEN_DOOR）时同步换帧 */
    @Override
    protected boolean updateCell(int cell, int[] data) {
        if (cell == this.cell) {
            updateAll(data);
            return true;
        }
        return false;
    }

    /** 门格是不是原版的「开着」地块 */
    private boolean isOpenTile() {
        return Dungeon.level != null && Dungeon.level.map != null
                && this.cell >= 0 && this.cell < Dungeon.level.length()
                && Dungeon.level.map[this.cell] == Terrain.OPEN_DOOR;
    }

    /** 换「关 / 开」两帧；贴图已建好时立刻重画 */
    public void setOpen(boolean open) {
        if (this.open == open) {
            return;
        }
        this.open = open;
        if (this.vis != null && this.vis.alive) {
            this.vis.updateMap();
        }
    }

    public boolean isOpen() {
        return this.open;
    }

    /** 检视窗口用：门洞那一格才算「门」，上面那格门楣仍然按墙 / 地板显示 */
    private boolean isDoorCell(int tileX, int tileY) {
        return tileX == 0 && tileY == this.tileH - 1;
    }

    /**
     * MOD: 检视窗口左上角的示例图。
     * 门洞那一格一律用「关着的门」那张（和原版检视门地块的图一致），
     * 否则竖排墙会拿到一块石头色的侧视门贴图，看着根本不像门。
     */
    @Override
    public Image image(int tileX, int tileY) {
        if (isDoorCell(tileX, tileY) && DungeonTerrainTilemap.instance != null) {
            Image closed = DungeonTerrainTilemap.tile(this.cell, Terrain.DOOR);
            if (closed != null) {
                return closed;
            }
        }
        return super.image(tileX, tileY);
    }

    @Override
    public String name(int tileX, int tileY) {
        if (!isDoorCell(tileX, tileY)) {
            return null;
        }
        return this.main ? "主门" : "副门";
    }

    @Override
    public String desc(int tileX, int tileY) {
        if (!isDoorCell(tileX, tileY)) {
            return null;
        }
        String to = this.main ? "副门" : "主门";
        StringBuilder sb = new StringBuilder();
        sb.append("骷髅钥匙在墙上拧出来的").append(this.main ? "主门" : "副门")
                .append("。门框严丝合缝，像是本来就在那儿。");
        sb.append("\n\n门后传来隐隐的风声——那后面似乎不是这层地牢该有的地方。");
        sb.append("\n\n踏进门后的黑暗，会被送到本层的").append(to).append("。");
        if (!hasPartner()) {
            sb.append("\n\n本层还没有").append(to).append("：先把它也开出来，门才走得通。");
        }
        return sb.toString();
    }

    /** 本层有没有另一扇（主 / 副）门 */
    private boolean hasPartner() {
        if (Dungeon.level == null || Dungeon.level.customTiles == null) {
            return false;
        }
        for (CustomTilemap t : Dungeon.level.customTiles) {
            if (t instanceof DoorTilemap && ((DoorTilemap) t).main != this.main) {
                return true;
            }
        }
        return false;
    }

    /** 从关卡里摘掉这扇门（换位置、拆门时用） */
    public void dispose() {
        if (this.vis != null) {
            this.vis.killAndErase();
            this.vis = null;
        }
    }

    @Override
    public void storeInBundle(Bundle bundle) {
        super.storeInBundle(bundle);
        bundle.put(CELL, this.cell);
        bundle.put(MAIN, this.main);
        bundle.put(OPEN, this.open);
        bundle.put(BEYOND, this.beyond);
        bundle.put(BEYOND_TERRAIN, this.beyondTerrain);
        bundle.put(CELL_TERRAIN, this.cellTerrain);
    }

    @Override
    public void restoreFromBundle(Bundle bundle) {
        super.restoreFromBundle(bundle);
        this.cell = bundle.getInt(CELL);
        this.main = bundle.getBoolean(MAIN);
        this.open = bundle.getBoolean(OPEN);
        this.beyond = bundle.getInt(BEYOND);
        this.beyondTerrain = bundle.getInt(BEYOND_TERRAIN);
        this.cellTerrain = bundle.getInt(CELL_TERRAIN);
        this.texture = null;   // 等 create() 里再取当前关卡的贴图
    }
}
