package com.shatteredpixel.shatteredpixeldungeon.actors.buffs;

import com.shatteredpixel.shatteredpixeldungeon.Dungeon;
import com.watabou.utils.Bundle;

import java.util.ArrayList;

/**
 * MOD: 时光沙漏（强化）——本层被凝滞成沙柱的高草丛。
 *
 * <p>挂在英雄身上随存档保存，所以中途读档沙柱还在；
 * 离开本层时由 {@code HourglassSand} 统一清空（沙粒回沙漏、充能上限返还）。</p>
 */
public class SandPillars extends Buff {

    /** 这些柱子在哪个深度凝成的 */
    public int depth = -1;

    /** 被凝住的格子 */
    public final ArrayList<Integer> cells = new ArrayList<>();

    private static final String DEPTH = "depth";
    private static final String CELLS = "cells";

    {
        type = buffType.NEUTRAL;
        announced = false;
    }

    public static SandPillars get() {
        return Dungeon.hero == null ? null : Dungeon.hero.buff(SandPillars.class);
    }

    public static SandPillars ensure() {
        return Dungeon.hero == null ? null : Buff.affect(Dungeon.hero, SandPillars.class);
    }

    /** 这一格是不是本层的沙柱 */
    public boolean has(int cell) {
        return depth == Dungeon.depth && cells.contains(cell);
    }

    @Override
    public void storeInBundle(Bundle bundle) {
        super.storeInBundle(bundle);
        bundle.put(DEPTH, depth);
        int[] arr = new int[cells.size()];
        for (int i = 0; i < arr.length; i++) {
            arr[i] = cells.get(i);
        }
        bundle.put(CELLS, arr);
    }

    @Override
    public void restoreFromBundle(Bundle bundle) {
        super.restoreFromBundle(bundle);
        depth = bundle.getInt(DEPTH);
        cells.clear();
        int[] arr = bundle.getIntArray(CELLS);
        if (arr != null) {
            for (int c : arr) {
                cells.add(c);
            }
        }
    }
}
