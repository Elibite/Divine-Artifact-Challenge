package com.shatteredpixel.shatteredpixeldungeon.items.artifacts;

import com.shatteredpixel.shatteredpixeldungeon.Dungeon;
import com.shatteredpixel.shatteredpixeldungeon.actors.Actor;
import com.shatteredpixel.shatteredpixeldungeon.actors.Char;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.Blindness;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.Buff;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.ForesightShared;
import com.shatteredpixel.shatteredpixeldungeon.actors.hero.Hero;
import com.shatteredpixel.shatteredpixeldungeon.actors.mobs.Mob;
import com.shatteredpixel.shatteredpixeldungeon.items.artifacts.Artifact;
import com.shatteredpixel.shatteredpixeldungeon.levels.Level;
import com.shatteredpixel.shatteredpixeldungeon.scenes.GameScene;
import com.shatteredpixel.shatteredpixeldungeon.utils.GLog;

import java.util.ArrayList;

/**
 * MOD: 先见护符的强化能力（需通过试炼，并把护符装在神器专属位上）。
 *
 * <ul>
 *   <li><b>察觉视线</b>：任何「正在直接看到你」的怪物，它看到的地方也会出现在你的视野里——
 *       等于借着它的眼睛看（每回合重新并一次）。</li>
 *   <li><b>盲它</b>：主动探测（扫视）命中的怪物会被致盲 5 回合。</li>
 * </ul>
 */
public class TalismanVision {

    /** 强化过、真的装在神器位上，而且没有处在试炼的诅咒中 */
    public static boolean active() {
        Hero hero = Dungeon.hero;
        if (hero == null || hero.belongings == null || Dungeon.level == null) {
            return false;
        }
        Artifact equipped = hero.belongings.artifact();
        if (!(equipped instanceof TalismanOfForesight)) {
            return false;
        }
        // 试炼期间神器是「被诅咒」状态：借视野 / 致盲这些能力一并关闭
        if (equipped.cursed) {
            return false;
        }
        return ArtifactTrial.isEnhancedClass(TalismanOfForesight.class);
    }

    /**
     * 每回合：把所有「玩家已经能看见」的怪物的视野，并进英雄自己的视野里。
     *
     * <p>只要玩家看得见某只怪，就能借它的眼睛；借来的区域里要是又出现了别的怪，
     * 那些怪也会接着把视野借出去（最多级联几轮，避免死循环）。</p>
     */
    public static void shareMonsterSight() {
        if (!active()) {
            return;
        }
        Hero hero = Dungeon.hero;
        Level level = Dungeon.level;
        int len = level.length();
        ArrayList<Mob> borrowed = new ArrayList<>();
        boolean changed = false;

        // 级联：A 借给玩家 → 视野里出现 B → B 也借出去
        for (int pass = 0; pass < 4; pass++) {
            boolean passChanged = false;
            for (Mob m : new ArrayList<>(level.mobs)) {
                if (m == null || m.fieldOfView == null || m.pos < 0 || m.pos >= len) {
                    continue;
                }
                // ① 它正直接看着你 → 你能感觉到它在看，直接拿到它所在格的视野
                if (m.fieldOfView[hero.pos] && level.discoverable[m.pos]) {
                    passChanged |= revealCell(level, hero, m.pos);
                }
                if (borrowed.contains(m)) {
                    continue;                      // 已经借过它的眼睛了
                }
                // 玩家看得见它吗？（自己的视野或已经并进来的视野）
                if (!hero.fieldOfView[m.pos] && !level.heroFOV[m.pos]) {
                    continue;
                }
                borrowed.add(m);
                for (int i = 0; i < len; i++) {
                    if (!m.fieldOfView[i]) {
                        continue;
                    }
                    // 跳过不可探索的格子（比如骷髅钥匙门后那片永久的黑暗）
                    if (!level.discoverable[i]) {
                        continue;
                    }
                    passChanged |= revealCell(level, hero, i);
                }
            }
            changed |= passChanged;
            if (!passChanged) {
                break;
            }
        }
        if (borrowed.isEmpty()) {
            return;
        }
        // 给每头被借视野的怪物挂一个「被窥视」标记：检视它就能看到这个状态
        for (Mob m : borrowed) {
            try {
                Buff.prolong(m, ForesightShared.class, 3f);
            } catch (Throwable ignored) {
            }
        }
        if (!changed) {
            return;
        }
        GameScene.updateFog();
        // 借来的视野里如果有怪物，得让它们真的显形（sprites + 可见敌人列表）
        for (Mob m : new ArrayList<>(level.mobs)) {
            if (m == null || m.sprite == null || m.pos < 0 || m.pos >= len) {
                continue;
            }
            boolean visible = level.heroFOV[m.pos] && m.invisible <= 0f;
            if (m.sprite.visible != visible) {
                m.sprite.visible = visible;
            }
        }
        hero.checkVisibleMobs();
    }

    /** 把一格并进英雄视野（自己看得见 / 探过 / 记住）；返回是否真的改变过 */
    private static boolean revealCell(Level level, Hero hero, int cell) {
        if (cell < 0 || cell >= level.length()) {
            return false;
        }
        boolean changed = false;
        if (!hero.fieldOfView[cell]) {
            hero.fieldOfView[cell] = true;
            changed = true;
        }
        if (!level.heroFOV[cell]) {
            level.heroFOV[cell] = true;
            changed = true;
        }
        if (!level.visited[cell]) {
            level.visited[cell] = true;
            changed = true;
        }
        return changed;
    }

    /**
     * 主动探测命中：原版会给英雄挂 {@code CharAwareness}（charID = 被察觉的怪物），
     * 这里顺着这个信号把那头怪物致盲 5 回合。
     */
    public static void onHeroBuff(Hero hero, Buff buff) {
        if (!(buff instanceof TalismanOfForesight.CharAwareness)) {
            return;
        }
        int id = ((TalismanOfForesight.CharAwareness) buff).charID;
        tlog("[add] CharAwareness charID=" + id + " active=" + active());
        if (!active()) {
            return;
        }
        blind(id);
    }

    /** 每回合扫一遍英雄身上的 {@code CharAwareness}，兜住「加 buff 那个钩子没触发」的情况 */
    public static void sweepAwareness() {
        if (!active()) {
            return;
        }
        Hero hero = Dungeon.hero;
        try {
            for (TalismanOfForesight.CharAwareness b
                    : hero.buffs(TalismanOfForesight.CharAwareness.class)) {
                if (b == null || !handled.add(b.id())) {
                    continue;                   // 这头已经处理过
                }
                tlog("[sweep] charID=" + b.charID);
                blind(b.charID);
            }
        } catch (Throwable t) {
            tlog("[sweep] failed " + t);
        }
    }

    /** 已经处理过的 CharAwareness 实例 id（避免每回合重复致盲） */
    private static final java.util.HashSet<Integer> handled = new java.util.HashSet<>();

    /** 把 charID 对应的怪物致盲 5 回合 */
    private static void blind(int charID) {
        Actor found = Actor.findById(charID);
        if (!(found instanceof Char)) {
            tlog("[blind] charID=" + charID + " → 找不到角色");
            return;
        }
        Char ch = (Char) found;
        if (ch == Dungeon.hero || !(ch instanceof Mob) || !ch.isAlive()) {
            tlog("[blind] charID=" + charID + " → 跳过 " + ch.getClass().getSimpleName());
            return;
        }
        Buff.prolong(ch, Blindness.class, 5f);
        tlog("[blind] " + ch.getClass().getSimpleName() + " 致盲 5 回合");
        GLog.i("被察觉的怪物眯起了眼，暂时看不见了。");
    }

    private static void tlog(String line) {
        try {
            com.watabou.utils.FileUtils.getFileHandle("talisman_debug.txt")
                    .writeString(line + "\n", true, "UTF-8");
        } catch (Throwable ignored) {
        }
    }
}
