/*
 * MOD: 「神器挑战」—— 干枯玫瑰的悲伤幽灵附身（灵体化）
 *
 * 注意：类名不能叫 SpiritForm —— 游戏里已有
 * com.shatteredpixel.shatteredpixeldungeon.actors.hero.spells.SpiritForm（牧师法术），
 * 会和 Regeneration 的 import 撞车。所以这里叫 GhostPossession，显示名仍是「灵体化」。
 *
 * 效果：
 *   - 不自然回复生命（Regeneration 里判断）
 *   - 不流失饱食度（Hunger 里判断）
 *   - 每 2 回合获得 1 点护盾，护盾上限 = 干枯玫瑰等级 × 2 + 5
 *   - 每获得 1 点护盾消耗玫瑰 1% 充能（充能上限 100 → 1 点）
 *   - 挑战关闭 / 玫瑰卸下 / 充能耗尽 → 附身结束
 */
package com.shatteredpixel.shatteredpixeldungeon.actors.buffs;

import com.shatteredpixel.shatteredpixeldungeon.Challenges;
import com.shatteredpixel.shatteredpixeldungeon.Dungeon;
import com.shatteredpixel.shatteredpixeldungeon.actors.hero.Hero;
import com.shatteredpixel.shatteredpixeldungeon.items.artifacts.Artifact;
import com.shatteredpixel.shatteredpixeldungeon.items.artifacts.DriedRose;
import java.lang.reflect.Field;

public class GhostPossession extends Buff {

    {
        type = buffType.POSITIVE;
        announced = true;
    }

    /** 每多少回合给 1 点护盾 */
    public static final float SHIELD_INTERVAL = 2f;

    private DriedRose rose;
    /** MOD: 被附身的幽灵本体（已从场上移除，但仍保留坐标与视距） */
    private com.shatteredpixel.shatteredpixeldungeon.actors.Char ghostBody;
    private int savedViewDistance = 0;
    private boolean viewSaved = false;
    /** MOD: 上一回合的护盾值，用于防止自动衰减 */
    private int lastShield = 0;
    private float shieldTimer = 0f;

    public void bind(DriedRose rose) {
        this.rose = rose;
    }

    public void bindBody(com.shatteredpixel.shatteredpixeldungeon.actors.Char ghost) {
        this.ghostBody = ghost;
    }

    /** MOD: 附身期间把玩家视距固定成幽灵的视距（不逐帧覆写 heroFOV，避免闪烁） */
    private void applyGhostVision(Hero hero) {
        if (this.ghostBody == null) {
            return;
        }
        if (!this.viewSaved) {
            this.savedViewDistance = hero.viewDistance;
            this.viewSaved = true;
        }
        hero.viewDistance = this.ghostBody.viewDistance;
    }

    /** MOD: 未附身时与场上的幽灵共享视野（并集）。由 Hero.act() 每回合调用。 */
    public static void shareGhostVision(Hero hero) {
        if (hero == null || Dungeon.level == null) {
            return;
        }
        if (!com.shatteredpixel.shatteredpixeldungeon.items.artifacts.ArtifactTrial
                .isEnhancedClass(com.shatteredpixel.shatteredpixeldungeon.items.artifacts.DriedRose.class)) {
            return;
        }
        // 还必须真的把干枯玫瑰装在神器位上
        if (hero.belongings == null
                || !(hero.belongings.artifact()
                instanceof com.shatteredpixel.shatteredpixeldungeon.items.artifacts.DriedRose)) {
            return;
        }
        try {
            int len = Dungeon.level.length();
            boolean[] fov = new boolean[len];
            boolean any = false;
            for (com.shatteredpixel.shatteredpixeldungeon.actors.mobs.Mob m : Dungeon.level.mobs) {
                if (m.getClass().getSimpleName().equals("GhostHero")) {
                    if (hero.viewDistance > m.viewDistance) {
                        m.viewDistance = hero.viewDistance;
                    }
                    Dungeon.level.updateFieldOfView(m, fov);
                    // 照抄灵能飞鹰：自己维护视野 + 直接点亮该处迷雾
                    Dungeon.level.updateFieldOfView(m, m.fieldOfView);
                    com.shatteredpixel.shatteredpixeldungeon.scenes.GameScene.updateFog(
                            m.pos, m.viewDistance + 1);
                    // 让幽灵自身格子保持可见，避免精灵被裁剪掉
                    Dungeon.level.heroFOV[m.pos] = true;
                    try {
                        m.sprite.visible = true;
                    } catch (Throwable ignored) {
                    }
                    any = true;
                }
            }
            if (any) {
                for (int i = 0; i < len && i < Dungeon.level.heroFOV.length; i++) {
                    if (fov[i]) {
                        Dungeon.level.heroFOV[i] = true;
                    }
                }
            }
        } catch (Throwable ignored) {
        }
    }

    @Override
    public boolean act() {
        if (!(target instanceof Hero)) {
            detach();
            return true;
        }
        if (!com.shatteredpixel.shatteredpixeldungeon.items.artifacts.ArtifactTrial
                .isEnhancedClass(com.shatteredpixel.shatteredpixeldungeon.items.artifacts.DriedRose.class)) {
            detach();
            return true;
        }
        if (((Hero) target).belongings == null
                || !(((Hero) target).belongings.artifact()
                instanceof com.shatteredpixel.shatteredpixeldungeon.items.artifacts.DriedRose)) {
            detach();
            return true;
        }

        Hero hero = (Hero) target;
        if (this.rose == null && hero.belongings != null) {
            this.rose = hero.belongings.getItem(DriedRose.class);
        }
        if (this.rose == null || !this.rose.isEquipped(hero)) {
            detach();
            return true;
        }

        // MOD: 玫瑰没有充能时不再提供护盾（增益本身保留）
        if (roseCharge(this.rose) <= 0) {
            spend(TICK);
            return true;
        }

        applyGhostVision(hero);

        // MOD: 附身期间不会因为「极度饥饿」掉血 —— 饿了就补饱食度，直到脱离饥饿
        Hunger hunger = hero.buff(Hunger.class);
        if (hunger != null && hunger.isStarving()) {
            hunger.satisfy(200f);
        }

        // MOD: 护盾在达到上限前不衰减 —— 若被(Barrier 自身衰减)扣了，就补回来
        if (this.lastShield > 0) {
            Barrier cur = hero.buff(Barrier.class);
            int now = (cur == null) ? 0 : cur.shielding();
            if (now < this.lastShield) {
                Barrier b2 = Buff.affect(hero, Barrier.class);
                b2.setShield(Math.min(this.lastShield, this.rose.level() * 2 + 5));
                now = b2.shielding();
            }
            this.lastShield = now;
        }

        this.shieldTimer += 1f;
        if (this.shieldTimer >= SHIELD_INTERVAL) {
            this.shieldTimer -= SHIELD_INTERVAL;

            int cap = this.rose.level() * 2 + 5;
            Barrier barrier = target.buff(Barrier.class);
            int current = (barrier == null) ? 0 : barrier.shielding();
            if (current < cap) {
                Barrier b = Buff.affect(target, Barrier.class);
                b.setShield(current + 1);
                this.lastShield = current + 1;
                // 1% 充能（玫瑰充能上限 100 → 1 点）
                setRoseCharge(this.rose, roseCharge(this.rose) - 1);
                if (roseCharge(this.rose) <= 0) {
                    detach();
                    return true;
                }
            }
        }

        spend(TICK);
        return true;
    }

    /** 玫瑰充能是 Artifact 的 protected 字段，用反射读写，避免整类覆盖 DriedRose。 */
    private static int roseCharge(DriedRose rose) {
        try {
            Field f = Artifact.class.getDeclaredField("charge");
            f.setAccessible(true);
            return f.getInt(rose);
        } catch (Throwable t) {
            return 0;
        }
    }

    private static void setRoseCharge(DriedRose rose, int value) {
        try {
            int cap = 100;
            try {
                Field c = Artifact.class.getDeclaredField("chargeCap");
                c.setAccessible(true);
                cap = c.getInt(rose);
            } catch (Throwable ignored) {
            }
            Field f = Artifact.class.getDeclaredField("charge");
            f.setAccessible(true);
            f.setInt(rose, Math.max(0, Math.min(cap, value)));
            DriedRose.updateQuickslot();
        } catch (Throwable ignored) {
        }
    }

    /** MOD: 状态栏图标 = 干枯玫瑰。icon() 必须返回有效下标，否则指示器会跳过。 */
    @Override
    public int icon() {
        return 0;
    }

    @Override
    public void tintIcon(com.watabou.noosa.Image icon) {
        try {
            if (this.rose == null && target instanceof Hero) {
                Hero h = (Hero) target;
                if (h.belongings != null) {
                    this.rose = h.belongings.getItem(DriedRose.class);
                }
            }
            if (this.rose != null) {
                com.shatteredpixel.shatteredpixeldungeon.sprites.ItemSprite s =
                        new com.shatteredpixel.shatteredpixeldungeon.sprites.ItemSprite(this.rose.image());
                icon.texture(s.texture);
                icon.frame(s.frame());
                icon.resetColor();
            }
        } catch (Throwable ignored) {
        }
    }

    @Override
    public void detach() {
        if (this.viewSaved && target instanceof Hero) {
            ((Hero) target).viewDistance = this.savedViewDistance;
        }
        super.detach();
    }

    @Override
    public String name() {
        return "灵体化";
    }

    @Override
    public String desc() {
        return "悲伤幽灵附身于你。\n\n期间不会自然回复生命，也不会流失饱食度；"
                + "每 2 回合获得 1 点护盾（上限 = 干枯玫瑰等级 × 2 + 5）。\n"
                + "每获得 1 点护盾会消耗干枯玫瑰 1% 的充能，充能耗尽时附身结束。";
    }
}
