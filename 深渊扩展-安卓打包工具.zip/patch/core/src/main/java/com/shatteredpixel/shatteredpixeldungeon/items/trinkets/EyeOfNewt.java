package com.shatteredpixel.shatteredpixeldungeon.items.trinkets;

import com.shatteredpixel.shatteredpixeldungeon.messages.Messages;
import com.shatteredpixel.shatteredpixeldungeon.sprites.ItemSpriteSheet;

/**
 * MOD: 原版 {@code EyeOfNewt} 的整类覆盖。
 *
 * <p>与 4.0.2 的差别只有一处：额外等级（4~6，需炼金工具箱通过试炼）会把
 * 「缩短视距」的惩罚往回退一档——4 级按 2 级算、5 级按 1 级、6 级回到 0 级的惩罚。
 * 心灵视距（{@code mindVisionRange}）仍按真实等级成长。</p>
 */
public class EyeOfNewt extends Trinket {

    public EyeOfNewt() {
        this.image = ItemSpriteSheet.EYE_OF_NEWT;
    }

    @Override
    protected int upgradeEnergyCost() {
        return 6 + 2 * this.level();
    }

    @Override
    public String statsDesc() {
        if (this.isIdentified()) {
            return Messages.get(this, "stats_desc",
                    Messages.decimalFormat("#.##", 100.0f * (1.0f - visionRangeMultiplier(this.buffedLvl()))),
                    mindVisionRange(this.buffedLvl()));
        }
        return Messages.get(this, "typical_stats_desc",
                Messages.decimalFormat("#.##", 100.0f * (1.0f - visionRangeMultiplier(0))),
                mindVisionRange(0));
    }

    public static float visionRangeMultiplier() {
        return visionRangeMultiplier(trinketLevel(EyeOfNewt.class));
    }

    public static float visionRangeMultiplier(int level) {
        if (level < 0) {
            return 1.0f;
        }
        // MOD: 额外等级把视距惩罚往回退（4→2 级、5→1 级、6→0 级）
        int penaltyLevel = level <= 3 ? level : Math.max(0, 6 - level);
        return 0.875f - 0.125f * (float) penaltyLevel;
    }

    public static int mindVisionRange() {
        return mindVisionRange(trinketLevel(EyeOfNewt.class));
    }

    public static int mindVisionRange(int level) {
        if (level < 0) {
            return 0;
        }
        return 2 + level;
    }
}
