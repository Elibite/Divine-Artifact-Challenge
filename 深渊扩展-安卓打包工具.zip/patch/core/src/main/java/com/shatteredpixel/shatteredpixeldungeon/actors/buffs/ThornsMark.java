package com.shatteredpixel.shatteredpixeldungeon.actors.buffs;

import com.shatteredpixel.shatteredpixeldungeon.Dungeon;
import com.watabou.utils.Bundle;

import java.util.HashSet;

/**
 * MOD: 「荆棘丛生」的记账本——记录哪些楼层已经撒过荆棘门。
 *
 * 存在的理由：荆棘门本身是站在门格上的怪物，存档会跟着关卡一起保存；
 * 但「这一层已经掷过骰」这件事没地方存，读档后如果不记账就会重新掷一次，
 * 把玩家已经砍开的门又缠上荆棘（甚至换一批门）。所以把楼层号记在英雄身上。
 *
 * 和 ArtifactTrial 一样是「不参与调度」的 Buff（不覆盖 act，纯粹挂着存数据）。
 */
public class ThornsMark extends Buff {

    private static final String DEPTHS = "depths";

    private final HashSet<Integer> depths = new HashSet<>();

    {
        type = buffType.NEUTRAL;
        announced = false;
    }

    public static ThornsMark get() {
        return Dungeon.hero == null ? null : Dungeon.hero.buff(ThornsMark.class);
    }

    public static ThornsMark ensure() {
        return Dungeon.hero == null ? null : Buff.affect(Dungeon.hero, ThornsMark.class);
    }

    /** 这层已经布置过荆棘门了 */
    public boolean done(int depth) {
        return depths.contains(depth);
    }

    public void mark(int depth) {
        depths.add(depth);
    }

    @Override
    public void storeInBundle(Bundle bundle) {
        super.storeInBundle(bundle);
        StringBuilder sb = new StringBuilder();
        for (int d : depths) {
            if (sb.length() > 0) {
                sb.append(',');
            }
            sb.append(d);
        }
        bundle.put(DEPTHS, sb.toString());
    }

    @Override
    public void restoreFromBundle(Bundle bundle) {
        super.restoreFromBundle(bundle);
        String raw = bundle.getString(DEPTHS);
        if (raw == null || raw.isEmpty()) {
            return;
        }
        for (String part : raw.split(",")) {
            if (part.isEmpty()) {
                continue;
            }
            try {
                depths.add(Integer.parseInt(part.trim()));
            } catch (NumberFormatException ignored) {
            }
        }
    }
}
