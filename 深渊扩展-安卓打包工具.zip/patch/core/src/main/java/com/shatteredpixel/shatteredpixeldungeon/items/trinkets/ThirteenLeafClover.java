package com.shatteredpixel.shatteredpixeldungeon.items.trinkets;

import com.shatteredpixel.shatteredpixeldungeon.messages.Messages;
import com.shatteredpixel.shatteredpixeldungeon.sprites.ItemSpriteSheet;
import com.watabou.utils.Random;

/**
 * MOD: 原版 {@code ThirteenLeafClover} 的整类覆盖。
 *
 * <p>与 4.0.2 的差别只有一处：额外等级（4~6，需炼金工具箱通过试炼）会把
 * 「造成最小伤害」的概率再往下压一档——每多一级，最小伤害的概率 −10%
 * （40% → 30% → 20% → 10%）。</p>
 */
public class ThirteenLeafClover extends Trinket {

    private static float MAX_CHANCE = 0.6f;

    public ThirteenLeafClover() {
        this.image = ItemSpriteSheet.CLOVER;
    }

    @Override
    protected int upgradeEnergyCost() {
        return 6 + 2 * this.level();
    }

    @Override
    public String statsDesc() {
        if (this.isIdentified()) {
            return Messages.get(this, "stats_desc",
                    Math.round(MAX_CHANCE * 100.0f * alterHeroDamageChance(this.buffedLvl())),
                    Math.round((1.0f - MAX_CHANCE) * 100.0f * alterHeroDamageChance(this.buffedLvl())));
        }
        return Messages.get(this, "typical_stats_desc",
                Math.round(MAX_CHANCE * 100.0f * alterHeroDamageChance(0)),
                Math.round((1.0f - MAX_CHANCE) * 100.0f * alterHeroDamageChance(0)));
    }

    public static float alterHeroDamageChance() {
        return alterHeroDamageChance(trinketLevel(ThirteenLeafClover.class));
    }

    public static float alterHeroDamageChance(int level) {
        if (level <= -1) {
            return 0.0f;
        }
        return 0.25f + 0.25f * (float) level;
    }

    /**
     * MOD: 伤害掷骰。原版固定 60% 取最大值、40% 取最小值；
     * 额外等级（>3）每多一级，取最小值的概率再降 10%。
     */
    public static int alterDamageRoll(int min, int max) {
        float maxChance = MAX_CHANCE;
        int level = trinketLevel(ThirteenLeafClover.class);
        if (level > 3) {
            maxChance = Math.min(1.0f, MAX_CHANCE + 0.1f * (level - 3));
        }
        if (Random.Float() < maxChance) {
            return max;
        }
        return min;
    }
}
