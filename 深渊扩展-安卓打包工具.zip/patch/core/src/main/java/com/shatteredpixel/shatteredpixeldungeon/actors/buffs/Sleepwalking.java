package com.shatteredpixel.shatteredpixeldungeon.actors.buffs;

import com.shatteredpixel.shatteredpixeldungeon.Challenges;
import com.shatteredpixel.shatteredpixeldungeon.Dungeon;
import com.shatteredpixel.shatteredpixeldungeon.actors.Char;
import com.shatteredpixel.shatteredpixeldungeon.actors.mobs.Mob;
import com.shatteredpixel.shatteredpixeldungeon.ui.BuffIndicator;
import com.watabou.utils.Random;

import java.util.HashSet;

/**
 * MOD: 挑战「梦游之症」。
 *
 * 怪物生成后第一次进入沉睡时，50% 概率获得本 buff（只掷一次骰，见 {@link #tick()}）。
 * 之后真正的移动由 Mob.act() 里的梦游分支负责：沉睡 + 有本 buff 时，每两回合随机挪一格。
 * 英雄只是出现在视野里不算惊扰；**在视野里移动**才算，被惊扰后摘掉 buff 回到原版沉睡逻辑。
 *
 * 注意 type 必须是 NEUTRAL/POSITIVE：原版 Mob.Sleeping.act() 会「只要身上有 NEGATIVE buff 就立刻惊醒」，
 * 用 NEGATIVE 会让怪物刚获得梦游就醒过来，根本走不到 Mob 的梦游分支。
 */
public class Sleepwalking extends Buff {

    {
        type = buffType.NEUTRAL;
        announced = false;
    }

    private static final HashSet<Integer> ROLLED = new HashSet<>();

    /**
     * MOD: 检视图标。Buff.icon() 默认返回 BuffIndicator.NONE(=127)，BuffIndicator 会直接跳过这类 buff，
     * 所以不重写就完全看不到图标。借「困倦」图标表示睡得迷迷糊糊还在走。
     */
    @Override
    public int icon() {
        return BuffIndicator.DROWSY;
    }

    @Override
    public String name() {
        return "梦游症";
    }

    @Override
    public String desc() {
        return "它在沉睡中不安地梦游。";
    }

    @Override
    public boolean act() {
        spend(TICK);
        return true;
    }

    /** 每回合由 Hero.act() 调用：沉睡中的敌人各掷一次骰，50% 获得梦游症 */
    public static void tick() {
        if (!com.shatteredpixel.shatteredpixeldungeon.ModContent.enabled()) {
            return;
        }
        if (Dungeon.level == null || !Dungeon.isChallenged(Challenges.SLEEPWALK)) {
            return;
        }
        try {
            for (Mob m : Dungeon.level.mobs.toArray(new Mob[0])) {
                if (m == null || !m.isAlive()) {
                    continue;
                }
                if (m.alignment != Char.Alignment.ENEMY || m.state != m.SLEEPING) {
                    continue;
                }
                if (!ROLLED.contains(m.id())) {
                    ROLLED.add(m.id());
                    if (Random.Int(2) == 0) {
                        Buff.affect(m, Sleepwalking.class);
                    }
                }
            }
        } catch (Throwable ignored) {
        }
    }
}
