package com.shatteredpixel.shatteredpixeldungeon;

/**
 * MOD: 自制内容的总开关。
 *
 * <p>由「挑战」界面顶部的勾选框控制；关掉时所有自制挑战、神器试炼强化、
 * 饰品强化、荆棘门、暗影区域、梦游、测试魔盒等等统统不出现也不生效，
 * 界面行为与原版一致。</p>
 */
public class ModContent {

    public static boolean enabled() {
        try {
            return SPDSettings.modContent();
        } catch (Throwable t) {
            return false;
        }
    }

    public static void setEnabled(boolean on) {
        SPDSettings.modContent(on);
    }

    public static void toggle() {
        setEnabled(!enabled());
    }
}
