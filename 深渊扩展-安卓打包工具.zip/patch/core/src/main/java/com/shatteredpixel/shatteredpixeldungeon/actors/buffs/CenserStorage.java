package com.shatteredpixel.shatteredpixeldungeon.actors.buffs;

import com.shatteredpixel.shatteredpixeldungeon.Dungeon;
import com.shatteredpixel.shatteredpixeldungeon.actors.blobs.Blob;
import com.watabou.utils.Bundle;

import java.util.ArrayList;

/**
 * MOD: 混沌香炉（强化）——存起来的几口「坏气」。
 *
 * <p>强化后的香炉不再自己往外喷，而是把攒下的气体存在这里
 * （上限 = 香炉等级），由玩家手动挑地方放出来。</p>
 */
public class CenserStorage extends Buff {

    /** 每一份：要放出来的气体类型 */
    public final ArrayList<Class<? extends Blob>> gasses = new ArrayList<>();

    /** 攒气的进度（0~1 之间累积） */
    public float progress = 0f;

    private static final String GASSES = "gasses";
    private static final String PROGRESS = "progress";

    {
        type = buffType.NEUTRAL;
        announced = false;
    }

    public static CenserStorage get() {
        return Dungeon.hero == null ? null : Dungeon.hero.buff(CenserStorage.class);
    }

    public static CenserStorage ensure() {
        return Dungeon.hero == null ? null : Buff.affect(Dungeon.hero, CenserStorage.class);
    }

    @Override
    public void storeInBundle(Bundle bundle) {
        super.storeInBundle(bundle);
        String[] names = new String[gasses.size()];
        for (int i = 0; i < names.length; i++) {
            names[i] = gasses.get(i).getName();
        }
        bundle.put(GASSES, names);
        bundle.put(PROGRESS, progress);
    }

    @Override
    public void restoreFromBundle(Bundle bundle) {
        super.restoreFromBundle(bundle);
        gasses.clear();
        String[] names = bundle.getStringArray(GASSES);
        if (names != null) {
            for (String n : names) {
                try {
                    Class<?> c = Class.forName(n);
                    if (Blob.class.isAssignableFrom(c)) {
                        gasses.add(c.asSubclass(Blob.class));
                    }
                } catch (Throwable ignored) {
                }
            }
        }
        progress = bundle.getFloat(PROGRESS);
    }
}
