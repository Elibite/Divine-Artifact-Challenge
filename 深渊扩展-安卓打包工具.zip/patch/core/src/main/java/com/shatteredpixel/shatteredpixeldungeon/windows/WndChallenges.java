/*
 * MOD: 挑战选择界面（覆盖原版 WndChallenges）
 *
 * 相对原版：
 *   1. 「神器挑战」固定显示在**最后一行**（按显示顺序重排，不改 Challenges 的数组顺序，
 *      所以以后新增的挑战会自动排在它前面）
 *   2. 「神器挑战」按钮为蓝色（条件不满足时灰色）
 *   3. 「神器挑战」需要**其余挑战全部开启**（「测试时间」不计入），条件按 NAME_IDS 动态计算
 *   4. 神器挑战描述里的「必须开启全部 {N} 个挑战」——{N} 也按 NAME_IDS 实时算，
 *      以后新增挑战时**不需要**改 properties 文案
 *
 * 上色说明：CheckBox 不在 Visual 继承链上（没有 hardlight），但它继承 StyledButton，
 * 可访问 protected 的 NinePatch bg；Visual.color(int) 是直接设色（不是叠加），
 * 所以给 bg 上蓝色即可得到蓝底按钮。为 null 时完全不碰颜色（否则会把原版红色覆盖成白色）。
 */
package com.shatteredpixel.shatteredpixeldungeon.windows;

import com.shatteredpixel.shatteredpixeldungeon.Challenges;
import com.shatteredpixel.shatteredpixeldungeon.SPDSettings;
import com.shatteredpixel.shatteredpixeldungeon.ShatteredPixelDungeon;
import com.shatteredpixel.shatteredpixeldungeon.messages.Messages;
import com.shatteredpixel.shatteredpixeldungeon.scenes.PixelScene;
import com.shatteredpixel.shatteredpixeldungeon.ui.CheckBox;
import com.shatteredpixel.shatteredpixeldungeon.ui.IconButton;
import com.shatteredpixel.shatteredpixeldungeon.ui.Icons;
import com.shatteredpixel.shatteredpixeldungeon.ui.RenderedTextBlock;
import com.shatteredpixel.shatteredpixeldungeon.ui.Window;

import java.util.ArrayList;

public class WndChallenges extends Window {

    private static final int WIDTH = 120;
    private static final int TTL_HEIGHT = 16;
    /** 单行高度：14 个挑战要挤进横屏 240px 的 UI 高度里，16px 会被切掉最后一行 */
    private static final int BTN_HEIGHT = 14;
    private static final int GAP = 0;

    /** 固定在最后一行的挑战 id */
    private static final String GATED_ID = "artifact_challenge";
    /** 不参与前置条件统计的挑战 id */
    private static final String IGNORED_ID = "test_time";
    /** 描述文案里「全部 {N} 个挑战」的占位符 */
    private static final String COUNT_TOKEN = "{N}";
    /** 神器挑战可用时的颜色（蓝） */
    private static final int ARTIFACT_COLOR = 0x2F6FD0;
    /** 条件未满足时的灰色 */
    private static final int LOCKED_COLOR = 0x6E6E6E;

    private boolean editable;
    /** 显示顺序下的勾选框 */
    private ArrayList<CheckBox> boxes;
    /** 与 boxes 对应的 Challenges 原始下标 */
    private ArrayList<Integer> boxIndex;
    private TintedCheckBox gatedBox;
    private int gatedOrigIndex = -1;

    /** 可换背景色的 CheckBox；tint 为 null 时不动任何颜色。 */
    private static class TintedCheckBox extends CheckBox {
        private Integer tintColor;

        TintedCheckBox(String label, Integer color) {
            super(label);
            this.tintColor = color;
        }

        void tint(int color) {
            this.tintColor = color;
            applyTint();
        }

        private void applyTint() {
            if (tintColor != null && bg != null) {
                bg.color(tintColor);
            }
        }

        @Override
        protected void layout() {
            super.layout();
            applyTint();
        }
    }

    /** 一次性诊断：把挑战窗口的开关/点击/保存都记进 thorns_debug.txt */
    private static void log(String s) {
        try {
            com.watabou.utils.FileUtils.getFileHandle("thorns_debug.txt")
                    .writeString("[WndChallenges] " + s + "\n", true, "UTF-8");
        } catch (Throwable ignored) {
        }
    }

    public WndChallenges(int checked, boolean editable) {
        this.editable = editable;
        log("open editable=" + editable + " checked=" + checked + " nameCount=" + Challenges.NAME_IDS.length);

        RenderedTextBlock title = PixelScene.renderTextBlock(
                Messages.get(this, "title", new Object[0]), 12);
        title.hardlight(0xFFFF44);
        title.setPos((120.0f - title.width()) / 2.0f, (16.0f - title.height()) / 2.0f);
        PixelScene.align(title);
        this.add(title);

        // MOD: 自制内容总开关（放在最上面；不勾就只有原版内容）
        com.shatteredpixel.shatteredpixeldungeon.ui.CheckBox modBox =
                new com.shatteredpixel.shatteredpixeldungeon.ui.CheckBox("启用深渊扩展（自制挑战与效果）") {
                    @Override
                    protected void onClick() {
                        super.onClick();
                        com.shatteredpixel.shatteredpixeldungeon.ModContent.setEnabled(checked());
                        // 关掉时把自制挑战一并取消勾选
                        if (!checked()) {
                            int mask = com.shatteredpixel.shatteredpixeldungeon.Challenges.ARTIFACT
                                    | com.shatteredpixel.shatteredpixeldungeon.Challenges.SLEEPWALK
                                    | com.shatteredpixel.shatteredpixeldungeon.Challenges.THORNS
                                    | com.shatteredpixel.shatteredpixeldungeon.Challenges.TEST_TIME
                                    | com.shatteredpixel.shatteredpixeldungeon.Challenges.PRICE_GOUGING;
                            com.shatteredpixel.shatteredpixeldungeon.SPDSettings.challenges(
                                    com.shatteredpixel.shatteredpixeldungeon.SPDSettings.challenges() & ~mask);
                        }
                        hide();
                        com.shatteredpixel.shatteredpixeldungeon.ShatteredPixelDungeon.scene().add(
                                new WndChallenges(com.shatteredpixel.shatteredpixeldungeon.SPDSettings.challenges(), editable));
                    }
                };
        modBox.checked(com.shatteredpixel.shatteredpixeldungeon.ModContent.enabled());
        modBox.setRect(0, 17.0f, 120.0f, BTN_HEIGHT);
        this.add(modBox);

        // 显示顺序：除「神器挑战」外保持原顺序，最后补上「神器挑战」
        int n = Challenges.NAME_IDS.length;
        int gatedOrig = -1;
        for (int i = 0; i < n; i++) {
            if (GATED_ID.equals(Challenges.NAME_IDS[i])) {
                gatedOrig = i;
                break;
            }
        }
        this.gatedOrigIndex = gatedOrig;

        final boolean modOn = com.shatteredpixel.shatteredpixeldungeon.ModContent.enabled();
        ArrayList<Integer> order = new ArrayList<>();
        for (int idx : displayOrder()) {
            String id = Challenges.NAME_IDS[idx];
            if (!modOn && (GATED_ID.equals(id) || "sleepwalk".equals(id) || "thorns".equals(id)
                    || "test_time".equals(id) || "price_gouging".equals(id))) {
                continue;
            }
            order.add(idx);
        }

        this.boxes = new ArrayList<>();
        this.boxIndex = new ArrayList<>();
        float pos = 17.0f + BTN_HEIGHT;
        for (int slot = 0; slot < order.size(); ++slot) {
            final int orig = order.get(slot);
            final String challenge = Challenges.NAME_IDS[orig];
            final boolean gated = (orig == gatedOrig);

            String label = Messages.titleCase(Messages.get(Challenges.class, challenge, new Object[0]));
            CheckBox cb = new TintedCheckBox(label, gated ? Integer.valueOf(ARTIFACT_COLOR) : null) {
                @Override
                protected void onClick() {
                    super.onClick();
                    log("click " + challenge + " -> checked=" + checked() + " active=" + active);
                    applyGate();
                }
            };

            cb.checked((checked & Challenges.MASKS[orig]) != 0);
            cb.active = editable;

            if (gated) {
                this.gatedBox = (TintedCheckBox) cb;
            }

            if (slot > 0) {
                pos += GAP;
            }
            cb.setRect(0.0f, pos, 104.0f, BTN_HEIGHT);
            this.add(cb);
            this.boxes.add(cb);
            this.boxIndex.add(orig);

            IconButton info = new IconButton(Icons.get(Icons.INFO)) {
                @Override
                protected void onClick() {
                    super.onClick();
                    String desc = Messages.get(Challenges.class, challenge + "_desc", new Object[0]);
                    if (gated) {
                        // MOD: 描述里「全部 {N} 个挑战」的 N 按 NAME_IDS 实时计算，新增挑战后文案不用改
                        desc = desc.replace(COUNT_TOKEN, countText(requiredCount()));
                    }
                    ShatteredPixelDungeon.scene().add(new WndMessage(desc));
                }
            };
            info.setRect(cb.right(), pos, 16.0f, BTN_HEIGHT);
            this.add(info);
            pos = cb.bottom();
        }

        applyGate();
        this.resize(120, (int) pos);
        log("built boxes=" + this.boxes.size() + " height=" + pos);
    }

    /** 显示顺序（元素是 Challenges 的原始下标）：「神器挑战」固定排最后。 */
    static int[] displayOrder() {
        int n = Challenges.NAME_IDS.length;
        int gated = -1;
        for (int i = 0; i < n; i++) {
            if (GATED_ID.equals(Challenges.NAME_IDS[i])) {
                gated = i;
                break;
            }
        }
        int[] out = new int[n];
        int k = 0;
        for (int i = 0; i < n; i++) {
            if (i != gated) {
                out[k++] = i;
            }
        }
        if (gated >= 0) {
            out[n - 1] = gated;
        }
        return out;
    }

    /**
     * MOD: 前置条件里要凑齐的挑战个数（= NAME_IDS 去掉「神器挑战」自己和「测试时间」）。
     * 「神器挑战」的描述文案里写的是「必须开启全部 {N} 个挑战」，{N} 由这个方法实时算出来，
     * 所以以后新增挑战**不需要**再去改 properties 里的文案。
     */
    static int requiredCount() {
        int n = 0;
        for (String id : Challenges.NAME_IDS) {
            if (GATED_ID.equals(id) || IGNORED_ID.equals(id)) {
                continue;
            }
            n++;
        }
        return n;
    }

    /** MOD: {N} 的渲染文本 —— 中文用「十一」这种写法，其它语言用阿拉伯数字。 */
    static String countText(int n) {
        String code = Messages.lang() == null ? "" : Messages.lang().code();
        if ("zh".equals(code)) {
            return chineseNumber(n);
        }
        return Integer.toString(n);
    }

    /** MOD: 0~99 转中文数字（十一、十二、二十三…），超出范围退回阿拉伯数字。 */
    static String chineseNumber(int n) {
        String[] digit = {"零", "一", "二", "三", "四", "五", "六", "七", "八", "九"};
        if (n < 0 || n > 99) {
            return Integer.toString(n);
        }
        if (n < 10) {
            return digit[n];
        }
        int tens = n / 10;
        int ones = n % 10;
        return (tens == 1 ? "" : digit[tens]) + "十" + (ones == 0 ? "" : digit[ones]);
    }

    /**
     * 「神器挑战」的前置条件：除它自己和「测试时间」之外，所有挑战都必须已勾选。
     * 条件不满足时自动取消勾选并置灰。
     */
    private void applyGate() {
        if (this.gatedBox == null || this.gatedOrigIndex < 0) {
            return;
        }
        boolean allOthersOn = true;
        for (int i = 0; i < this.boxes.size(); i++) {
            int orig = this.boxIndex.get(i);
            if (orig == this.gatedOrigIndex) {
                continue;
            }
            if (IGNORED_ID.equals(Challenges.NAME_IDS[orig])) {
                continue;
            }
            if (!this.boxes.get(i).checked()) {
                allOthersOn = false;
                break;
            }
        }

        // MOD: 只在**可编辑**时自动取消勾选；只读展示（进游戏后点开）时保留真实状态，
        // 否则新加挑战后，玩家会看到「神器挑战被取消」的假象（其实它一直开着，只是前置没凑齐）
        if (this.editable && !allOthersOn && this.gatedBox.checked()) {
            this.gatedBox.checked(false);
        }
        this.gatedBox.active = this.editable && allOthersOn;
        this.gatedBox.tint(allOthersOn ? ARTIFACT_COLOR : LOCKED_COLOR);
    }

    @Override
    public void onBackPressed() {
        if (this.editable) {
            applyGate();
            int value = 0;
            for (int i = 0; i < this.boxes.size(); ++i) {
                if (!this.boxes.get(i).checked()) {
                    continue;
                }
                value |= Challenges.MASKS[this.boxIndex.get(i)];
            }
            log("save value=" + value + " boxes=" + this.boxes.size());
            SPDSettings.challenges(value);
        }
        super.onBackPressed();
    }
}
