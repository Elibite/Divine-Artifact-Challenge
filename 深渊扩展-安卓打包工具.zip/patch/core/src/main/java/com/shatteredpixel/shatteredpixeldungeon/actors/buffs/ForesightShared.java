package com.shatteredpixel.shatteredpixeldungeon.actors.buffs;

import com.shatteredpixel.shatteredpixeldungeon.ui.BuffIndicator;

/**
 * MOD: 先见护符（强化）——这头怪物的视野正被「借」给玩家。
 *
 * <p>只是个标记：由 {@code TalismanVision} 在共享视野时每回合刷新，
 * 停止共享后自然过期消失。检视这头怪物时能看到它的状态图标，
 * 从而知道「它正在被先见护符偷看」。</p>
 */
public class ForesightShared extends FlavourBuff {

    {
        type = buffType.NEUTRAL;
        announced = false;
    }

    @Override
    public int icon() {
        return BuffIndicator.MIND_VISION;
    }

    @Override
    public String name() {
        return "被窥视";
    }

    @Override
    public String desc() {
        return "先见护符正借它的眼睛看东西。";
    }
}
