package com.shatteredpixel.shatteredpixeldungeon.items.food;

import com.shatteredpixel.shatteredpixeldungeon.actors.hero.Hero;
import com.shatteredpixel.shatteredpixeldungeon.items.Item;
import com.shatteredpixel.shatteredpixeldungeon.items.artifacts.HornCandy;
import com.shatteredpixel.shatteredpixeldungeon.utils.GLog;
import com.watabou.noosa.audio.Sample;

/**
 * MOD: 口哨糖 —— 强化后的丰饶之角用充能吹制的糖果（每 1 点充能吹 3 颗）。
 *
 * <ul>
 *   <li>含着**不花回合**，也不顶饿（不加饱食度）；</li>
 *   <li>吃完人一下精神起来（清心 + 短暂轻快）；</li>
 *   <li>代价：那声细细的哨音会把附近的敌人招过来。</li>
 * </ul>
 */
public class WhistleCandy extends Food {

    /**
     * MOD: 自定义贴图 —— 一对像素同心圆（淡粉），画在物品图集空白格 (240,496) 上，
     * 对应图集下标 511（见 tools/build_candy_texture.py；图集本身随 jar 打包覆盖原版）。
     */
    public static final int IMAGE = 511;

    {
        image = IMAGE;
        energy = 0f;             // 不加饱食度
        stackable = true;
        bones = false;
        defaultAction = AC_EAT;
    }

    @Override
    public String name() {
        return "口哨糖";
    }

    @Override
    public String desc() {
        return "一小块硬糖，含在嘴里会发出细细的哨音。\n\n"
                + "不顶饿，也不长力气——它只是把号角里那点别人的吃相吹给你听。";
    }

    @Override
    public void execute(Hero hero, String action) {
        if (!AC_EAT.equals(action)) {
            super.execute(hero, action);
            return;
        }
        // 不调用 Food 的流程：不吃回合、不加饱食度；
        // 自己也不带任何效果——纯粹用来触发号角「借来的吃相」。
        this.detach(hero.belongings.backpack);
        hero.sprite.operate(hero.pos);
        Sample.INSTANCE.play("sounds/eat.mp3");
        boolean triggered = HornCandy.rollBorrowTalent();
        if (!triggered) {
            GLog.i("糖在嘴里化开，一声细细的哨音散了出去，没人应和。");
        }
        Item.updateQuickslot();
    }
}
