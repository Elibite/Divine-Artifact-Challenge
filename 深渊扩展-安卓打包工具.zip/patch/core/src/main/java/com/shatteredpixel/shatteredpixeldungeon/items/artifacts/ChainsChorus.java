package com.shatteredpixel.shatteredpixeldungeon.items.artifacts;

import com.shatteredpixel.shatteredpixeldungeon.Dungeon;
import com.shatteredpixel.shatteredpixeldungeon.actors.hero.Hero;
import com.shatteredpixel.shatteredpixeldungeon.utils.GLog;
import com.watabou.utils.Random;

import java.lang.reflect.Field;

/**
 * MOD: 「虚空锁链」里那些灵魂的只言片语（人格：死者的回响合唱）。
 *
 * <p>这条链子里挤着一堆被它拖过来的灵魂碎片，它们渴望同伴：
 * 充能（也就是链中的灵魂）越多，声音越杂、越爱抢话、态度越好。</p>
 *
 * <p>这里只负责一个小机制：**每当充能上涨**，有 25% 的概率让灵魂们为新同伴欢呼一句。</p>
 */
public class ChainsChorus {

    /** 上一次看到的锁链充能数（-1 = 还没记录） */
    private static int lastCharge = -1;

    /** 新灵魂加入时的欢呼（25% 触发，随机取一条） */
    private static final String[] CHEERS = {
            "「——又多一个。」\n「往里挤挤，还有位置。」",
            "「轻点，新来的在挣。」\n「……挣一会儿就不挣了。」",
            "「记下了。」\n「记在锁链上，一环一个名字。」",
            "「都响一声，给他听听。」\n于是锁链齐齐地响了一声，像是在笑。"
    };

    /** 每回合调用：充能上涨时掷一次骰子 */
    public static void tick() {
        Hero hero = Dungeon.hero;
        if (hero == null || hero.belongings == null) {
            return;
        }
        if (!com.shatteredpixel.shatteredpixeldungeon.ModContent.enabled()) {
            return;
        }
        // 只在神器挑战里生效
        if (!Dungeon.isChallenged(com.shatteredpixel.shatteredpixeldungeon.Challenges.ARTIFACT)) {
            lastCharge = -1;
            return;
        }
        Artifact artifact = hero.belongings.artifact();
        if (!(artifact instanceof EtherealChains)) {
            lastCharge = -1;
            return;
        }
        int charge = readCharge(artifact);
        if (charge < 0) {
            return;
        }
        if (lastCharge >= 0 && charge > lastCharge) {
            for (int i = 0; i < charge - lastCharge; i++) {
                if (Random.Int(4) == 0) {
                    GLog.i(CHEERS[Random.Int(CHEERS.length)]);
                }
            }
        }
        lastCharge = charge;
    }

    private static int readCharge(Artifact a) {
        try {
            Field f = Artifact.class.getDeclaredField("charge");
            f.setAccessible(true);
            return f.getInt(a);
        } catch (Throwable t) {
            return -1;
        }
    }
}
