/*
 * MOD: 测试模式入口道具「测试魔盒」
 *
 * 功能：
 *   1. 打开刷物品面板（WndSpawner）
 *   2. 传送至指定楼层
 *   3. 一键测试：给一套 +50 装备与 99 个消耗品
 *   4. 镐子：把地图上任意一格刨成空地（Terrain.EMPTY）
 *
 * 发放逻辑在 Hero 的 MOD 补丁里（开启「测试时间」挑战时每局自动给一个）。
 */
package com.shatteredpixel.shatteredpixeldungeon.items;

import com.shatteredpixel.shatteredpixeldungeon.Dungeon;
import com.shatteredpixel.shatteredpixeldungeon.GamesInProgress;
import com.shatteredpixel.shatteredpixeldungeon.actors.hero.Hero;
import com.shatteredpixel.shatteredpixeldungeon.items.armor.PlateArmor;
import com.shatteredpixel.shatteredpixeldungeon.items.armor.glyphs.AntiMagic;
import com.shatteredpixel.shatteredpixeldungeon.items.rings.RingOfFuror;
import com.shatteredpixel.shatteredpixeldungeon.items.rings.RingOfHaste;
import com.shatteredpixel.shatteredpixeldungeon.items.scrolls.exotic.ScrollOfForesight;
import com.shatteredpixel.shatteredpixeldungeon.items.weapon.enchantments.Projecting;
import com.shatteredpixel.shatteredpixeldungeon.items.weapon.melee.Whip;
import com.shatteredpixel.shatteredpixeldungeon.levels.Level;
import com.shatteredpixel.shatteredpixeldungeon.levels.Terrain;
import com.shatteredpixel.shatteredpixeldungeon.scenes.CellSelector;
import com.shatteredpixel.shatteredpixeldungeon.scenes.GameScene;
import com.shatteredpixel.shatteredpixeldungeon.scenes.InterlevelScene;
import com.shatteredpixel.shatteredpixeldungeon.sprites.ItemSpriteSheet;
import com.shatteredpixel.shatteredpixeldungeon.utils.GLog;
import com.shatteredpixel.shatteredpixeldungeon.windows.WndOptions;
import com.shatteredpixel.shatteredpixeldungeon.windows.WndSpawner;
import com.watabou.noosa.Game;
import com.watabou.utils.Callback;

import java.util.ArrayList;

public class TestBox extends Item {

    public static final String AC_OPEN = "OPEN";
    public static final String AC_TELEPORT = "TELEPORT";
    public static final String AC_LOADOUT = "LOADOUT";
    public static final String AC_DIG = "DIG";

    /** 一键测试的装备目标等级 */
    private static final int LOADOUT_LEVEL = 50;
    /** 一键测试的消耗品数量 */
    private static final int LOADOUT_STACK = 99;

    {
        // 外观使用 Yendor 护符（Amulet）同款贴图
        image = ItemSpriteSheet.AMULET;
        defaultAction = AC_OPEN;
        stackable = false;
        unique = true;
    }

    @Override
    public String name() {
        return "测试魔盒";
    }

    @Override
    public String desc() {
        return "测试模式道具。\n\n点击「打开」可任取游戏内任何物品，用于快速验证数值与机制。"
                + "\n\n「传送」可直接前往指定楼层。"
                + "\n\n「一键测试」会给你一套 +" + LOADOUT_LEVEL + " 的测试装备与 "
                + LOADOUT_STACK + " 个消耗品。"
                + "\n\n「镐子」可以点地图上任意一格，把它刨成空地（墙、水、门、陷阱都能刨）。";
    }

    @Override
    public ArrayList<String> actions(Hero hero) {
        ArrayList<String> actions = super.actions(hero);
        // 去掉 drop / throw：测试道具不该被误丢或误投
        actions.clear();
        actions.add(AC_OPEN);
        actions.add(AC_TELEPORT);
        actions.add(AC_LOADOUT);
        actions.add(AC_DIG);
        return actions;
    }

    @Override
    public String actionName(String action, Hero hero) {
        if (AC_OPEN.equals(action)) {
            return "打开";
        }
        if (AC_TELEPORT.equals(action)) {
            return "传送";
        }
        if (AC_LOADOUT.equals(action)) {
            return "一键测试";
        }
        if (AC_DIG.equals(action)) {
            return "镐子";
        }
        return super.actionName(action, hero);
    }

    @Override
    public void execute(Hero hero, String action) {
        if (AC_OPEN.equals(action)) {
            GameScene.cancel();
            GameScene.show(new WndSpawner());
            return;
        }
        if (AC_TELEPORT.equals(action)) {
            showFloorPicker();
            return;
        }
        if (AC_LOADOUT.equals(action)) {
            giveTestLoadout();
            return;
        }
        if (AC_DIG.equals(action)) {
            digTile();
            return;
        }
        super.execute(hero, action);
    }

    /** MOD: 镐子 —— 选任意一格，把它刨成空地 */
    private void digTile() {
        GameScene.selectCell(new CellSelector.Listener() {
            @Override
            public void onSelect(Integer cell) {
                if (cell == null) {
                    return;
                }
                if (cell < 0 || cell >= Dungeon.level.length()) {
                    return;
                }
                Level.set(cell, Terrain.EMPTY);          // Level.set 会顺手清掉那格的陷阱
                Dungeon.level.plants.remove(cell);       // 植物也一起清掉
                GameScene.updateMap();                   // 地块变了，整张图重算
                Dungeon.observe();
                GLog.i("这一格被刨成了空地。");
            }

            @Override
            public String prompt() {
                return "选一格，把它刨成空地";
            }
        });
    }

    @Override
    public boolean isUpgradable() {
        return false;
    }

    @Override
    public boolean isIdentified() {
        return true;
    }

    // ==================================================================
    // 传送：先选区间，再选具体楼层
    // ==================================================================

    private void showFloorPicker() {
        final String[] groups = {
                "第 1 - 5 层", "第 6 - 10 层", "第 11 - 15 层",
                "第 16 - 20 层", "第 21 - 25 层", "第 26 层"
        };
        GameScene.show(new WndOptions("传送", "选择楼层区间：", groups) {
            @Override
            protected void onSelect(int index) {
                super.onSelect(index);
                if (index == groups.length - 1) {
                    teleportTo(26);
                    return;
                }
                final int base = index * 5 + 1;
                String[] floors = new String[5];
                for (int i = 0; i < 5; i++) {
                    floors[i] = "第 " + (base + i) + " 层";
                }
                GameScene.show(new WndOptions("传送", "选择目标楼层：", floors) {
                    @Override
                    protected void onSelect(int i) {
                        super.onSelect(i);
                        teleportTo(base + i);
                    }
                });
            }
        });
    }

    private void teleportTo(final int depth) {
        if (Dungeon.hero == null) {
            return;
        }

        // 不能自己改 Dungeon.depth 后手动 switchLevel：那等于绕过了游戏的换层流程
        //（Mob.holdAllies / 存档 / 加载线程 / 场景重建 都在 InterlevelScene 里），
        // 在 act() 执行期间直接换关会崩溃。改用 Mode.RETURN，由游戏自己完成加载。
        InterlevelScene.mode = InterlevelScene.Mode.RETURN;
        InterlevelScene.returnDepth = depth;
        InterlevelScene.returnBranch = 0;
        InterlevelScene.returnPos = -1;   // -1：由 switchLevel 自动挑一个有效的落点

        Game.runOnRenderThread(new Callback() {
            @Override
            public void call() {
                Game.switchScene(InterlevelScene.class);
            }
        });
        GLog.p("正在传送至第 " + depth + " 层…");
    }

    // ==================================================================
    // 一键测试
    // ==================================================================

    private void giveTestLoadout() {
        Hero hero = Dungeon.hero;
        if (hero == null || hero.belongings == null) {
            return;
        }

        // 戒指：疾速之戒、狂怒之戒
        give(hero, new RingOfHaste().upgrade(LOADOUT_LEVEL));
        give(hero, new RingOfFuror().upgrade(LOADOUT_LEVEL));

        // 武器：索敌长鞭（长鞭 + Projecting 索敌附魔）
        Whip whip = new Whip();
        whip.upgrade(LOADOUT_LEVEL);
        whip.enchant(new Projecting());
        give(hero, whip);

        // 护甲：敌法板甲（板甲 + AntiMagic 敌法符文）
        PlateArmor armor = new PlateArmor();
        armor.upgrade(LOADOUT_LEVEL);
        armor.inscribe(new AntiMagic());
        give(hero, armor);

        // 消耗品：火把、先见秘卷
        Item torch = new Torch();
        torch.quantity(LOADOUT_STACK);
        give(hero, torch);

        Item scroll = new ScrollOfForesight();
        scroll.quantity(LOADOUT_STACK);
        give(hero, scroll);

        // 魔能透视合剂
        Item sight = new com.shatteredpixel.shatteredpixeldungeon.items.potions.exotic.PotionOfMagicalSight();
        sight.quantity(LOADOUT_STACK);
        give(hero, sight);

        GLog.p("一键测试：已发放 +" + LOADOUT_LEVEL + " 装备与 " + LOADOUT_STACK + " 个消耗品。");
    }

    private static void give(Hero hero, Item item) {
        if (item == null) {
            return;
        }
        item.identify(true);
        if (!item.doPickUp(hero)) {
            Dungeon.level.drop(item, hero.pos);
        }
    }
}
