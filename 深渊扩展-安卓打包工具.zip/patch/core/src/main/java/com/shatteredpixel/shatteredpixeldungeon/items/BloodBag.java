/*
 * MOD: 血袋 —— 被蓄血圣杯改造过的水袋。
 *
 * 规则：
 *  - 只装血，失去储水功能：不能从治疗之井 / 水洼 / 露珠里灌水（fill() / collectDew() 都是空的）
 *  - 容量 = 当前圣杯等级下、献祭时「可能承受的最小伤害」（3 + 2.5 * lv^2 取上整）
 *  - 可以割腕把自己的血存进去；也可以在袋子上偷偷开启「自动收集周围怪物血液」
 *  - 满了会在左下角弹绿字，提醒可以着手献祭
 *  - 献祭前可以手动把袋里的血倒进圣杯（倒进去的血会先替玩家扣）
 */
package com.shatteredpixel.shatteredpixeldungeon.items;

import com.shatteredpixel.shatteredpixeldungeon.Dungeon;
import com.shatteredpixel.shatteredpixeldungeon.actors.hero.Hero;
import com.shatteredpixel.shatteredpixeldungeon.items.artifacts.ChaliceOfBlood;
import com.shatteredpixel.shatteredpixeldungeon.sprites.ItemSpriteSheet;
import com.shatteredpixel.shatteredpixeldungeon.utils.GLog;
import com.watabou.utils.Bundle;

import java.util.ArrayList;

public class BloodBag extends Waterskin {

    public static final String AC_STORE = "STORE";
    public static final String AC_AUTO = "AUTO";
    public static final String AC_POUR = "POUR";

    private int blood = 0;
    private boolean autoCollect = false;
    private boolean fullHinted = false;

    private static final String BLOOD = "blood";
    private static final String AUTO = "auto";
    private static final String HINTED = "hinted";

    public BloodBag() {
        super();
        this.image = ItemSpriteSheet.WATERSKIN;
        this.defaultAction = null;
    }

    @Override
    public String name() {
        return "血袋";
    }

    public int blood() {
        return this.blood;
    }

    public boolean autoCollect() {
        return this.autoCollect;
    }

    /** 容量 = 当前圣杯等级下、献祭可能承受的最小伤害 */
    public int capacity() {
        int lvl = 0;
        if (Dungeon.hero != null && Dungeon.hero.belongings != null) {
            ChaliceOfBlood chalice = Dungeon.hero.belongings.getItem(ChaliceOfBlood.class);
            if (chalice != null) {
                lvl = chalice.level();
            }
        }
        return (int)Math.ceil(3.0f + 2.5f * (float)(lvl * lvl));
    }

    /** 往袋里加血，返回实际加进去的量 */
    public int addBlood(int amount) {
        if (amount <= 0) {
            return 0;
        }
        int cap = this.capacity();
        int room = cap - this.blood;
        if (room <= 0) {
            return 0;
        }
        int added = Math.min(room, amount);
        this.blood += added;
        if (this.blood >= cap && !this.fullHinted) {
            this.fullHinted = true;
            GLog.p("血袋满了——" + this.blood + "/" + cap + "。可以着手献祭圣杯了。");
        }
        Waterskin.updateQuickslot();
        return added;
    }

    /** 倒空血袋，返回倒出来的量 */
    public int drainAll() {
        int out = this.blood;
        this.blood = 0;
        this.fullHinted = false;
        Waterskin.updateQuickslot();
        return out;
    }

    // ===== 失去储水功能 =====
    @Override
    public void fill() {
    }

    @Override
    public void collectDew(Dewdrop dew) {
    }

    @Override
    public boolean isFull() {
        return this.blood >= this.capacity();
    }

    @Override
    public String status() {
        return this.blood + "/" + this.capacity();
    }

    @Override
    public String info() {
        return "一只被蓄血圣杯改造过的水袋。袋壁发黑，摸上去还带着温度。\n\n"
                + "它只装血，再也装不下水了——井里打上来的水，一滴都进不去。\n\n"
                + "血量：" + this.blood + "/" + this.capacity() + "\n"
                + "自动收集：" + (this.autoCollect
                        ? "已开启（周围有谁流血，它会悄悄收进袋里）"
                        : "未开启") + "\n\n"
                + "献祭圣杯之前，可以把袋里的血倒进圣杯，让它先替你流。";
    }

    @Override
    public ArrayList<String> actions(Hero hero) {
        ArrayList<String> actions = super.actions(hero);
        actions.remove("DRINK");
        if (this.blood < this.capacity()) {
            actions.add(AC_STORE);
        }
        actions.add(AC_AUTO);
        if (this.blood > 0) {
            actions.add(AC_POUR);
        }
        return actions;
    }

    @Override
    public String actionName(String action, Hero hero) {
        if (AC_STORE.equals(action)) {
            return "割开手腕，把血存进去";
        }
        if (AC_AUTO.equals(action)) {
            return this.autoCollect ? "关掉自动收集" : "偷偷开启自动收集";
        }
        if (AC_POUR.equals(action)) {
            return "把血倒进圣杯";
        }
        return super.actionName(action, hero);
    }

    @Override
    public void execute(Hero hero, String action) {
        super.execute(hero, action);
        if (AC_STORE.equals(action)) {
            int room = this.capacity() - this.blood;
            int amount = Math.min(room, Math.max(1, hero.HT / 10));
            amount = Math.min(amount, Math.max(1, hero.HP - 1));
            int added = this.addBlood(amount);
            if (added <= 0) {
                GLog.i("袋里装不下了。");
                return;
            }
            hero.spend(1.0f);
            hero.busy();
            hero.damage(added, this);
            GLog.i("你把 " + added + " 点血挤进了血袋（" + this.blood + "/" + this.capacity() + "）。");
        } else if (AC_AUTO.equals(action)) {
            this.autoCollect = !this.autoCollect;
            GLog.i(this.autoCollect
                    ? "血袋悄悄张开了一道口子——周围有谁流血，它会自己收着。"
                    : "血袋合上了。");
        } else if (AC_POUR.equals(action)) {
            ChaliceOfBlood chalice = hero.belongings.getItem(ChaliceOfBlood.class);
            if (chalice == null) {
                GLog.i("圣杯不在你身上。");
                return;
            }
            int out = this.drainAll();
            chalice.receiveBagBlood(out);
            hero.spend(1.0f);
            GLog.p("你把血袋里的 " + out + " 点血倒进了圣杯。");
        }
    }

    @Override
    public void storeInBundle(Bundle bundle) {
        super.storeInBundle(bundle);
        bundle.put(BLOOD, this.blood);
        bundle.put(AUTO, this.autoCollect);
        bundle.put(HINTED, this.fullHinted);
    }

    @Override
    public void restoreFromBundle(Bundle bundle) {
        super.restoreFromBundle(bundle);
        this.blood = bundle.getInt(BLOOD);
        this.autoCollect = bundle.getBoolean(AUTO);
        this.fullHinted = bundle.getBoolean(HINTED);
    }
}
