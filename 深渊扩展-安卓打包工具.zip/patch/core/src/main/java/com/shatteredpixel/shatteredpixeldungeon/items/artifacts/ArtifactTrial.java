package com.shatteredpixel.shatteredpixeldungeon.items.artifacts;

import com.shatteredpixel.shatteredpixeldungeon.Challenges;
import com.shatteredpixel.shatteredpixeldungeon.Dungeon;
import com.shatteredpixel.shatteredpixeldungeon.Statistics;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.Buff;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.Hunger;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.Invisibility;
import com.shatteredpixel.shatteredpixeldungeon.actors.hero.Hero;
import com.shatteredpixel.shatteredpixeldungeon.actors.hero.HeroClass;
import com.shatteredpixel.shatteredpixeldungeon.actors.mobs.npcs.Ghost;
import com.shatteredpixel.shatteredpixeldungeon.items.Item;
import com.shatteredpixel.shatteredpixeldungeon.items.potions.Potion;
import com.shatteredpixel.shatteredpixeldungeon.items.scrolls.Scroll;
import com.shatteredpixel.shatteredpixeldungeon.items.stones.Runestone;
import com.shatteredpixel.shatteredpixeldungeon.scenes.GameScene;
import com.shatteredpixel.shatteredpixeldungeon.sprites.ItemSprite;
import com.shatteredpixel.shatteredpixeldungeon.utils.GLog;
import com.shatteredpixel.shatteredpixeldungeon.windows.WndMessage;
import com.shatteredpixel.shatteredpixeldungeon.windows.WndOptions;
import com.watabou.noosa.Game;
import com.watabou.utils.Bundle;
import com.watabou.utils.Callback;

/**
 * MOD: 「神器挑战」的神器试炼。
 *
 * 规则：
 *  - 只有装在**神器位**（belongings.artifact）的强化类神器（干枯玫瑰 / 自然之履 / 无序魔典 / 蓄血圣杯）会发起试炼；
 *    神器/戒指通用的 misc 位不触发
 *  - 每次进入 BOSS 层时都会弹出询问（每件神器的台词不同）；拒绝只是本次不强化，
 *    离开后再进来 / 换另一件神器都会重新询问
 *  - 接受后该神器在战斗期间被诅咒（无法卸下、强化能力失效），带着它击败本层首领即可解除诅咒并强化
 *  - 每局最多只能强化一件神器
 *  - 开启「测试时间」挑战时：所有神器默认视为已强化，且不再限制强化数量（方便测试）
 *
 * 状态挂在本类上（一个挂在英雄身上、不参与调度的 Buff），随存档保存。
 */
public class ArtifactTrial extends Buff {

    private static final String ENHANCED = "enhanced";
    private static final String TRIAL = "trial";
    private static final String TRIAL_DEPTH = "trial_depth";
    private static final String ASKED_DEPTH = "asked_depth";
    private static final String ASKED_CLASS = "asked_class";
    private static final String ROSE_HINTED = "rose_hinted";

    /** 只有这几件有「强化」实现，也只有它们会发起试炼 */
    private static final Class<?>[] TRIALABLE = {
            DriedRose.class, SandalsOfNature.class, UnstableSpellbook.class, ChaliceOfBlood.class,
            AlchemistsToolkit.class, MasterThievesArmband.class, SkeletonKey.class,
            // MOD: 先见护符 —— 试炼前它只是块探测器，邀请是「玩家自己意识到」；
            // 联系建立后才有偷视野 / 致盲那套强化能力
            TalismanOfForesight.class,
            // MOD: 时光沙漏 —— 强化后充能 1.5 倍，并能洒沙凝滞敌人
            TimekeepersHourglass.class,
            // MOD: 虚空锁链 —— 两头自由牵引
            EtherealChains.class,
            // MOD: 丰饶之角 —— 强化后能吹口哨糖、进食会借来别人的吃相
            HornOfPlenty.class};

    /** 本局已强化的神器类名（null = 本局还没强化过任何神器） */
    private String enhancedClass;
    /** 正在试炼的神器类名（null = 没有进行中的试炼） */
    private String trialClass;
    /** 试炼所在的 BOSS 层 */
    private int trialDepth = -1;
    /** 问过的层（换层会清空，所以重新进入 BOSS 层会再问一次） */
    private int askedDepth = -1;
    /** 问过的那件神器（同一次进入里换一件神器会重新问） */
    private String askedClass;
    /** 玫瑰「阴影」那句提示是否已经出现过（之后只剩「毫无反应」） */
    private boolean roseHinted;
    // ===== MOD: 神偷袖章「偷走存在感」 =====
    private int stillTurns = 0;
    private int lastHeroPos = -1;
    private int lastHp = -1;
    private int lastAttackStamp = 0;
    private int lastHurtStamp = 0;

    {
        type = buffType.NEUTRAL;
        announced = false;
    }

    @Override
    public String name() {
        return "神器试炼";
    }

    @Override
    public String desc() {
        return "一件神器正在等待你的答复。";
    }

    // ============================================================
    // 状态查询
    // ============================================================

    public static ArtifactTrial get() {
        return Dungeon.hero == null ? null : Dungeon.hero.buff(ArtifactTrial.class);
    }

    private static ArtifactTrial ensure() {
        if (Dungeon.hero == null) {
            return null;
        }
        return Buff.affect(Dungeon.hero, ArtifactTrial.class);
    }

    /** 这件神器是否已经通过试炼（挑战未开启时永远为 false；开启「测试时间」时一律为 true） */
    public static boolean isEnhanced(Artifact artifact) {
        if (artifact == null) {
            return false;
        }
        if (!com.shatteredpixel.shatteredpixeldungeon.ModContent.enabled()) {
            return false;
        }
        if (testMode()) {
            return true;
        }
        if (!Dungeon.isChallenged(Challenges.ARTIFACT)) {
            return false;
        }
        ArtifactTrial t = get();
        return t != null && t.enhancedClass != null && t.enhancedClass.equals(artifact.getClass().getName());
    }

    /** 指定种类的神器是否已经通过试炼 */
    public static boolean isEnhancedClass(Class<?> artifactClass) {
        if (artifactClass == null) {
            return false;
        }
        if (testMode()) {
            return true;
        }
        if (!Dungeon.isChallenged(Challenges.ARTIFACT)) {
            return false;
        }
        ArtifactTrial t = get();
        return t != null && t.enhancedClass != null && t.enhancedClass.equals(artifactClass.getName());
    }

    /** 「测试时间」挑战：所有神器默认视为已通过试炼，并且不限制强化数量 */
    private static boolean testMode() {
        return Dungeon.isChallenged(Challenges.TEST_TIME);
    }

    /** 这件神器会不会发起试炼 */
    public static boolean trialable(Artifact artifact) {
        if (artifact == null) {
            return false;
        }
        for (Class<?> c : TRIALABLE) {
            if (c.isInstance(artifact)) {
                return true;
            }
        }
        return false;
    }

    // ============================================================
    // 每回合（由 Hero.act() 调用）
    // ============================================================

    public static void tick() {
        // MOD: 总开关关掉时，试炼系统整个不参与
        if (!com.shatteredpixel.shatteredpixeldungeon.ModContent.enabled()) {
            return;
        }
        // MOD: 神偷袖章 —— 原地不动 3 回合且没挨打，就获得 2 回合隐身
        armbandStealPresence();
        SkeletonKey.onHeroTurn();   // MOD: 对齐本层的门 + 把用过的门关上
        if (Dungeon.hero == null || Dungeon.level == null) {
            return;
        }
        boolean testMode = testMode();
        if (!testMode && !Dungeon.isChallenged(Challenges.ARTIFACT)) {
            return;
        }

        ArtifactTrial t = get();

        // 1) 换层了：清掉「本层已经问过」的记录。
        //    这样只要重新进入 BOSS 层（哪怕是以前拒绝过的那一层），邀请都会再次弹出。
        if (t != null && t.askedDepth != Dungeon.depth) {
            t.askedDepth = -1;
            t.askedClass = null;
        }

        // 2) 已经离开试炼所在的 BOSS 层：放弃试炼，诅咒消退
        if (t != null && t.trialClass != null && Dungeon.depth != t.trialDepth) {
            t.abandon();
        }

        // 2.5) 试炼中的诅咒不能被祛邪：万一被别的手段清掉了，这里重新缠上（测试时间除外）
        if (t != null && t.trialClass != null && !testMode) {
            Artifact trialing = findTrialArtifact(t.trialClass);
            if (trialing != null && !trialing.cursed) {
                trialing.cursed = true;
                trialing.cursedKnown = true;
                GLog.w("诅咒重新缠上了「" + trialing.trueName() + "」——试炼还没结束，它挣不开。");
            }
        }

        // 3) 只在 BOSS 层询问
        if (!Dungeon.bossLevel()) {
            return;
        }
        if (t != null && t.trialClass != null) {
            return;   // 已经有试炼在进行
        }
        if (!testMode && t != null && t.enhancedClass != null) {
            return;   // 每局只能强化一件；测试时间下放开这个限制
        }

        Artifact equipped = Dungeon.hero.belongings == null ? null : Dungeon.hero.belongings.artifact();
        if (!trialable(equipped) || equipped.cursed) {
            return;   // 只有神器位上的强化类神器会发起（misc 位不算）
        }

        // 同一次进入里，就同一件神器只问一次（换一件神器会重新问）
        if (t != null && t.askedDepth == Dungeon.depth
                && equipped.getClass().getName().equals(t.askedClass)) {
            return;
        }

        // MOD: 玫瑰要等悲伤幽灵报完仇（拿回奖励）才肯接受试炼，之前只会给提示
        if (equipped instanceof DriedRose && !roseReady()) {
            ArtifactTrial roseMarker = ensure();
            if (roseMarker == null) {
                return;
            }
            roseMarker.askedDepth = Dungeon.depth;
            roseMarker.askedClass = equipped.getClass().getName();
            if (!roseMarker.roseHinted) {
                roseMarker.roseHinted = true;
                showMessage(ROSE_SHADE_HINT);
            } else {
                showMessage(ROSE_NO_REACTION);
            }
            return;
        }

        ArtifactTrial marker = ensure();
        if (marker == null) {
            return;
        }
        marker.askedDepth = Dungeon.depth;
        marker.askedClass = equipped.getClass().getName();
        ask(equipped);
    }

    // ============================================================
    // 询问 / 人格对话 / 接受 / 完成 / 放弃
    // ============================================================

    /** 邀请窗口。玫瑰的「邀请」就是它那段长长的警告 */
    private static void ask(final Artifact artifact) {
        final String body = invitationText(artifact);
        if (body.isEmpty()) {
            return;
        }
        if (artifact instanceof DriedRose) {
            showOptions(artifact, body, "我意已决", "……你说得对", new Runnable() {
                @Override
                public void run() {
                    roseReconfirm(artifact);
                }
            });
        } else if (artifact instanceof SandalsOfNature) {   // 中立：尊重你的意愿
            showOptions(artifact, body, "我想试试", "再想想", new Runnable() {
                @Override
                public void run() {
                    startTrial(artifact);
                }
            });
        } else if (artifact instanceof ChaliceOfBlood) {   // 恶劣：诱惑
            showOptions(artifact, body, "来吧", "算了", new Runnable() {
                @Override
                public void run() {
                    startTrial(artifact);
                }
            });
        } else if (artifact instanceof MasterThievesArmband) {
            showOptions(artifact, body, "来吧", "算了", new Runnable() {
                @Override
                public void run() {
                    startTrial(artifact);
                }
            });
        } else if (artifact instanceof UnstableSpellbook) { // 恶劣：诱惑
            showOptions(artifact, body, "好，开始", "算了", new Runnable() {
                @Override
                public void run() {
                    startTrial(artifact);
                }
            });
        } else if (artifact instanceof SkeletonKey) {       // 中立：懒，两个选项都很敷衍
            showOptions(artifact, body, "行吧，走吧", "算了，躺着", new Runnable() {
                @Override
                public void run() {
                    startTrial(artifact);
                }
            });
        } else if (artifact instanceof TalismanOfForesight) { // 中立：没有人在劝，是玩家自己下的决心
            showOptions(artifact, body, "带着它打", "先算了", new Runnable() {
                @Override
                public void run() {
                    startTrial(artifact);
                }
            });
        } else if (artifact instanceof TimekeepersHourglass) { // 友好：和蔼的年迈者
            showOptions(artifact, body, "带上你，一起走", "再等等", new Runnable() {
                @Override
                public void run() {
                    startTrial(artifact);
                }
            });
        } else if (artifact instanceof EtherealChains) {   // 双重立场：多数派投票
            showOptions(artifact, body, "带上你们", "再想想", new Runnable() {
                @Override
                public void run() {
                    startTrial(artifact);
                }
            });
        } else if (artifact instanceof HornOfPlenty) {     // 四重立场：饿的人说话短
            String yes;
            switch (hornTier(artifact)) {
                case 0:
                    yes = "先吃点东西";
                    break;
                case 3:
                    yes = "一起下去";
                    break;
                default:
                    yes = "带上你";
                    break;
            }
            showOptions(artifact, body, yes, "再想想", new Runnable() {
                @Override
                public void run() {
                    startTrial(artifact);
                }
            });
        }
    }

    /** 玫瑰专属：接受之后的再确认 */
    private static void roseReconfirm(final Artifact artifact) {
        showOptions(artifact, ROSE_RECONFIRM, "想清楚了", "……算了", new Runnable() {
            @Override
            public void run() {
                startTrial(artifact);
            }
        });
    }

    /**
     * 真正开始试炼：标记 + 诅咒（到了这一步就不能反悔了）。
     * 之后按神器的人格补一段话：友好/中立的像朋友，恶劣的会幸灾乐祸。
     */
    private static void startTrial(final Artifact artifact) {
        final boolean frail = (artifact instanceof AlchemistsToolkit)
                ? toolkitIsFrail() : heroIsFrail();   // 在诅咒生效前判定玩家状态
        accept(artifact);
        if (artifact instanceof DriedRose) {
            showMessage(ROSE_THORNS);
        } else {
            showMessage(postAcceptText(artifact, frail));
        }
    }

    /** MOD: 玩家状态是否「不佳」—— 生命低于 50%，或者低于 75% 且极度饥饿 */
    private static boolean heroIsFrail() {
        Hero hero = Dungeon.hero;
        if (hero == null || hero.HT <= 0) {
            return false;
        }
        float ratio = (float) hero.HP / (float) hero.HT;
        if (ratio < 0.5f) {
            return true;
        }
        return ratio < 0.75f && hero.isStarving();
    }

    /**
     * MOD: 炼金工具箱眼里的「状态不好」——它不看你剩多少血，只看你还剩多少「家当」：
     * 药水、卷轴，以及由它们加工出来的各种合剂（ExoticPotion）、秘卷（ExoticScroll），
     * 所有这些的总数量加起来少于 4 件，它就认定你已经山穷水尽。
     * 符石（Runestone，由卷轴拆解而来）不算在内。
     */
    private static boolean toolkitIsFrail() {
        Hero hero = Dungeon.hero;
        if (hero == null || hero.belongings == null) {
            return false;
        }
        int count = 0;
        for (Item it : hero.belongings) {
            if (it == null || it instanceof Runestone) {
                continue;
            }
            if (it instanceof Potion || it instanceof Scroll) {
                count += it.quantity();
            }
        }
        return count < 4;
    }

    /** MOD: 神偷袖章的「偷走存在感」 */
    /** MOD: 记录游戏日志里最后一条消息，用来避免同一句反复刷屏 */
    private static String lastLogText = null;
    private static boolean logWatcher = false;

    private static void watchLog() {
        if (logWatcher) {
            return;
        }
        logWatcher = true;
        try {
            GLog.update.add(new com.watabou.utils.Signal.Listener<String>() {
                @Override
                public boolean onSignal(String value) {
                    lastLogText = value;
                    return true;
                }
            });
        } catch (Throwable ignored) {
        }
    }

    private static void armbandStealPresence() {
        Hero hero = Dungeon.hero;
        if (hero == null || Dungeon.level == null) {
            return;
        }
        // 没有试炼记录时也要有个地方记「站了几回合」，所以用 ensure() 而不是 get()
        ArtifactTrial t = ensure();
        if (t == null) {
            return;
        }
        Artifact equipped = hero.belongings == null ? null : hero.belongings.artifact();
        if (!(equipped instanceof MasterThievesArmband) || !isEnhanced(equipped)) {
            t.stillTurns = 0;
            t.lastHeroPos = hero.pos;
            t.lastHp = hero.HP;
            return;
        }
        boolean starving = false;
        Hunger hunger = hero.buff(Hunger.class);
        if (hunger != null) {
            starving = hunger.isStarving();
        }
        if (t.lastHeroPos != hero.pos) {
            t.stillTurns = 0;
        } else {
            t.stillTurns++;
        }
        // MOD: 出手打过人、或刚挨过打（哪怕伤害被护甲/护盾挡下）→ 重新数
        if (Hero.modAttackStamp != t.lastAttackStamp || Hero.modHurtStamp != t.lastHurtStamp) {
            t.stillTurns = 0;
            t.lastAttackStamp = Hero.modAttackStamp;
            t.lastHurtStamp = Hero.modHurtStamp;
        }
        if (t.lastHp > 0 && hero.HP < t.lastHp && !starving) {
            t.stillTurns = 0;   // 挨了外来的打，重新数
        }
        t.lastHeroPos = hero.pos;
        t.lastHp = hero.HP;
        if (t.stillTurns >= 3 && hero.buff(Invisibility.class) == null) {
            Buff.affect(hero, Invisibility.class, 2f);
            t.stillTurns = 0;
            watchLog();
            String msg = "袖章在你腕上轻轻一拽——你的影子自己走开了。这层楼现在不认得你。";
            if (!msg.equals(lastLogText)) {
                GLog.i(msg);
            }
        }
    }

    /** MOD: 玫瑰是否已经准备好 —— 悲伤幽灵报了仇、并且把遗物交给了你（Ghost.Quest.completed()） */
    private static boolean roseReady() {
        try {
            return Ghost.Quest.completed();
        } catch (Throwable t) {
            return false;
        }
    }

    /** MOD: 这件物品是否正处在试炼中（试炼期间它的诅咒不能被祛邪；测试时间除外） */
    public static boolean isTrialing(Item item) {
        if (item == null || testMode()) {
            return false;
        }
        ArtifactTrial t = get();
        return t != null && t.trialClass != null && t.trialClass.equals(item.getClass().getName());
    }

    /** MOD: 找到正在试炼的那件神器（只认神器位） */
    private static Artifact findTrialArtifact(String className) {
        if (className == null || Dungeon.hero == null || Dungeon.hero.belongings == null) {
            return null;
        }
        Artifact equipped = Dungeon.hero.belongings.artifact();
        return equipped != null && className.equals(equipped.getClass().getName()) ? equipped : null;
    }

    /** 玩家接受试炼：神器临时被诅咒 */
    private static void accept(Artifact artifact) {
        ArtifactTrial t = ensure();
        if (t == null) {
            return;
        }
        t.trialClass = artifact.getClass().getName();
        t.trialDepth = Dungeon.depth;
        artifact.cursed = true;
        artifact.cursedKnown = true;
        String change = changeText(artifact);
        // MOD: 深红（GLog.n = "-- " 前缀 → GameLog 用 0xFF0000），一句到底，不再分行
        GLog.n("「" + artifact.trueName() + "」不再回应你。" + change);
        Item.updateQuickslot();
    }

    // ===== MOD: 每种神器「不详的变化」各一句 =====

    private static final String CHANGE_ROSE =
            "玫瑰的花瓣一寸寸蜷缩、发黑，像被什么从里面慢慢抽干；枝上的刺却微微立了起来，"
                    + "泛着一种不该属于干花的新颜色。";

    private static final String CHANGE_SANDALS =
            "草鞋上的藤蔓一点点枯萎、发灰，编成鞋底的草绳却一根根绷紧，"
                    + "像有什么东西在它们底下慢慢地挣动。";

    private static final String CHANGE_SPELLBOOK =
            "书页自己一页页翻过去，墨迹从纸上浮起来又沉下去，最后糊成一团黑；"
                    + "每一页的边角都沾着干涸的痕迹，像是被谁用血翻过。";

    private static final String CHANGE_CHALICE =
            "杯壁上的血纹一根接一根亮起来，像血管那样鼓胀、搏动；"
                    + "杯底积起一层薄薄的黑，怎么倒也倒不干净。";

    private static final String CHANGE_TOOLKIT =
            "工具箱里的瓶瓶罐罐一只接一只暗了下去，搭扣「咔」地自己扣死，"
                    + "任你怎么掰都掰不开。";

    private static String changeText(Artifact artifact) {
        if (artifact instanceof DriedRose) {
            return CHANGE_ROSE;
        }
        if (artifact instanceof SandalsOfNature) {
            return CHANGE_SANDALS;
        }
        if (artifact instanceof UnstableSpellbook) {
            return CHANGE_SPELLBOOK;
        }
        if (artifact instanceof ChaliceOfBlood) {
            return CHANGE_CHALICE;
        }
        if (artifact instanceof MasterThievesArmband) {
            return ARMBAND_AFTER;
        }
        if (artifact instanceof AlchemistsToolkit) {
            return CHANGE_TOOLKIT;
        }
        return "";
    }

    // ===== MOD: 窗口小工具 =====

    private static void showOptions(final Artifact artifact, final String body,
                                    final String yes, final String no, final Runnable onYes) {
        Game.runOnRenderThread(new Callback() {
            @Override
            public void call() {
                GameScene.show(new WndOptions(new ItemSprite(artifact),
                        "神器试炼 · " + artifact.trueName(), body, yes, no) {
                    @Override
                    protected void onSelect(int index) {
                        if (index == 0 && onYes != null) {
                            onYes.run();
                        }
                    }
                });
            }
        });
    }

    private static void showMessage(final String body) {
        Game.runOnRenderThread(new Callback() {
            @Override
            public void call() {
                GameScene.show(new WndMessage(body));
            }
        });
    }

    /** BOSS 被击败（由 Mob.die() 调用） */
    public static void onBossDefeated() {
        ArtifactTrial t = get();
        if (t == null || t.trialClass == null || Dungeon.depth != t.trialDepth) {
            return;
        }
        Artifact carried = Dungeon.hero == null || Dungeon.hero.belongings == null
                ? null : Dungeon.hero.belongings.artifact();
        if (carried == null || !t.trialClass.equals(carried.getClass().getName())) {
            t.abandon();
            return;
        }
        carried.cursed = false;
        carried.cursedKnown = true;
        t.enhancedClass = t.trialClass;
        t.trialClass = null;
        t.trialDepth = -1;
        GLog.p("「" + carried.trueName() + "」承受住了试炼。诅咒消散，被封印的力量苏醒了。");
        Item.updateQuickslot();
        // MOD: 先见护符 —— 打完 BOSS 才终于能与那位存在进行「极为有限」的对话
        if (carried instanceof TalismanOfForesight) {
            showMessage("「……看见你了。」\n\n——\n\n"
                    + "只有这一句。护符安静下来，那点噪音退到了很远的地方。");
        }
    }

    /** 试炼中断（离开 BOSS 层 / 神器不在神器位） */
    private void abandon() {
        if (Dungeon.hero != null && Dungeon.hero.belongings != null && this.trialClass != null) {
            Artifact equipped = Dungeon.hero.belongings.artifact();
            if (equipped != null && this.trialClass.equals(equipped.getClass().getName()) && equipped.cursed) {
                equipped.cursed = false;
            }
        }
        boolean wasTrial = this.trialClass != null;
        this.trialClass = null;
        this.trialDepth = -1;
        if (wasTrial) {
            GLog.i("试炼中断了，神器的诅咒随之消退。");
            Item.updateQuickslot();
        }
    }

    // ============================================================
    // 台词
    // ============================================================

    // 台词（每件神器一个人格）
    // ============================================================

    /** 干枯玫瑰：复仇任务还没完成时的第一次提示 */
    private static final String ROSE_SHADE_HINT =
            "你感到一阵阴影从玫瑰的花瓣缝隙间溜过。\n\n"
                    + "低头细看，却什么也没有。花瓣干枯，枝桠安静，像一支再普通不过的死枝。\n\n"
                    + "你把它翻过来又看了一遍。\n\n"
                    + "……是错觉吗？";

    /** 干枯玫瑰：之后每次再进 BOSS 层，玫瑰都不再回应 */
    private static final String ROSE_NO_REACTION =
            "你拨了拨腰间的玫瑰，等着那个声音。\n\n"
                    + "……\n\n"
                    + "它毫无反应。";

    /** 干枯玫瑰：邀请就是这段长长的劝阻（幽灵的声音） */
    private static final String ROSE_WARNING =
            "玫瑰的花影晃了一下，那个声音又响起来，比以往任何时候都要疲惫。\n\n"
                    + "「……我看出来了。你开启的是一场真正的试炼。」\n\n"
                    + "「接下来这一仗，我帮不上你。被诅咒的我，说不定还会拖你的后腿。」\n\n"
                    + "「听我一句：现在回头还来得及。从这儿出去，回到地表去，把这支玫瑰插在窗台上"
                    + "——它会在阳光下重新活过来。」\n\n"
                    + "「如果你一定要往地底走，那就在这场战斗开始之前，把我塞进背包最深处。"
                    + "至少别让我碍你的事。」";

    /** 干枯玫瑰：反复确认 */
    private static final String ROSE_RECONFIRM =
            "「……你听不进去，是吗。」\n\n"
                    + "沉默了很久，久到你以为它不会再开口。\n\n"
                    + "「那我再问一次，只问这一次——你真的要带着一把被诅咒的玫瑰，"
                    + "去和这层底下那个东西拼命？」\n\n"
                    + "「想清楚了再答。」";

    /** 干枯玫瑰：试炼开始后的「刺」 */
    private static final String ROSE_THORNS =
            "「……千万小心。」\n\n"
                    + "花影散了。玫瑰不再说话。\n\n"
                    + "幽灵叮嘱的回音刚散尽的那一瞬，玫瑰上的刺陡然伸长——几乎扎进你的掌心。\n\n"
                    + "你屏住呼吸，用一块破布小心地把它裹好，别在腰间。";

    /** 自然之履（友好：女猎手——草木认她作自己人） */
    private static final String SANDALS_INVITE_FRIENDLY =
            "草鞋的藤蔓在你脚踝上轻轻绕了一圈，像是认得你。\n\n"
                    + "「你身上有草木的味道。」老树的声音软下来，「我等这一天很久了——"
                    + "想不想让我把整座森林借给你？」\n\n"
                    + "「不用怕。你踩过的每一寸土，都会替你看着路。」";

    /** 自然之履（友好）：状态还好 */
    private static final String SANDALS_FRIENDLY_AFTER_OK =
            "「去吧。」藤蔓从脚踝上松开，像是松开一只手。\n\n"
                    + "「我陪着你。你走到哪儿，哪儿就是我的根。」";

    /** 自然之履（友好）：状态不好 —— 心疼地劝你小心 */
    private static final String SANDALS_FRIENDLY_AFTER_WEAK =
            "「等一下。」藤蔓忽然缠紧了你的脚踝。\n\n"
                    + "「你身上有伤，肚子里也是空的。就这样下去，土地会先把你收走的。」\n\n"
                    + "「……不过我不拦你。」它慢慢松了松，「踩着我的地方走。真撑不住了，"
                    + "就往草地上倒——我接着。」";

    /** 自然之履（中立）：主动邀约，完全尊重你的意愿 */
    private static final String SANDALS_INVITE =
            "草鞋的藤蔓在你脚踝上轻轻绕了一圈。\n\n"
                    + "「你想让我彻底醒过来吗？」老树的声音很平静，「全部的力量，一次都给你。」\n\n"
                    + "「要不要开这场试炼，由你决定。我不劝你，也不拦你。」";

    /** 自然之履（中立）：你状态不好时，钦佩你的勇气 */
    private static final String SANDALS_AFTER_WEAK =
            "「……都这样了，你还要去。」\n\n"
                    + "藤蔓在你脚踝上收紧了一下，像是在点头。\n\n"
                    + "「有种。」\n\n"
                    + "「那就走吧。撑不住的时候别硬撑。」";

    /** 自然之履（中立）：状态还好 */
    private static final String SANDALS_AFTER_OK =
            "「那就走吧。」藤蔓松开你的脚踝。\n\n"
                    + "「我跟着你。」";

    /** 神偷袖章（友好：盗贼） */
    private static final String ARMBAND_INVITE_FRIENDLY =
            "袖章在你腕上松松地扣住，像搭上肩膀的一只手。\n\n"
                    + "「同行。」它咂了咂嘴，「……不，比同行还像。你手上那点脏东西，我隔着皮都能闻见。」\n\n"
                    + "「跟着我干吧。街上的人不会记得你——他们连自己丢了什么都想不明白。」\n\n"
                    + "「放心，我不是什么好东西。」它笑得贼，「可我对你，是真心的。」";

    /** 神偷袖章（中立：其他职业） */
    private static final String ARMBAND_INVITE_NEUTRAL =
            "袖章上的针脚动了一下，像在慢条斯理地打量你。\n\n"
                    + "「你走路的姿势太正了。」它懒洋洋地说，「一眼就能看出你不是干这行的。」\n\n"
                    + "「不过没关系。手艺是教出来的，胆子是逼出来的——我两样都擅长。」\n\n"
                    + "「要不要试试，让整层楼的人都变成瞎子？」";

    /** 神偷袖章（恶劣：牧师） */
    private static final String ARMBAND_INVITE_NASTY =
            "袖章凉了一下，随即笑得又轻又慢。\n\n"
                    + "「牧师。」它一字一字地念，「你们这种人最好骗。只要一句『神意如此』，"
                    + "你们能把刀递到别人手里。」\n\n"
                    + "「我上一个主人也是牧师。临死前还跪着祈祷——他不知道，我早把祷词卖给了对面的魔鬼。」\n\n"
                    + "「来啊。让我看看你这身白袍，能脏到什么程度。」";

    /** 神偷袖章：接受后 */
    private static final String ARMBAND_AFTER =
            "「别动。」它低声笑。\n\n"
                    + "「让我把你这张脸，从这层楼的记忆里抠出去。」";

    /** 蓄血圣杯（友好：血是干净的）—— 语气难得客气，还会透露终祭的线索 */
    private static final String CHALICE_INVITE_FRIENDLY =
            "杯壁上的血纹缓缓亮起，像在呼吸。\n\n"
                    + "「你的血是干净的。」它难得说了一句好话，「我很久没喝到这样的血了。」\n\n"
                    + "「记着——等我喝到再也喝不下、而你也完好无损的那一天，带着『一样东西』来找我。」\n\n"
                    + "「它会碎的。而我会醒过来。」\n\n"
                    + "「到时候我给你的，是现在的两倍。」";

    /** 蓄血圣杯（中立：血里掺过怪物血） */
    private static final String CHALICE_INVITE_NEUTRAL =
            "圣杯在你掌心温着，血纹亮得很淡。\n\n"
                    + "「你的血……掺了别的味道。」它没有发作，只是语气淡了下去，「不过还能喝。」\n\n"
                    + "「要献就献。我照旧接着。」";

    /** 蓄血圣杯（恶劣）：诱惑 */
    private static final String CHALICE_INVITE =
            "圣杯在你掌心微微发烫，杯壁上的血纹懒洋洋地亮了一下。\n\n"
                    + "「想不想让我真正醒过来？」杯底的声音又黏又软，「全部的力量，一口就够。」\n\n"
                    + "「放心，对你来说不算什么。你可是走到这里的人了。」";

    /** 蓄血圣杯（恶劣）：状态不好时先瞒着，开始了才说实话（死法按 BOSS 换着说） */
    private static final String CHALICE_AFTER_WEAK_HEAD =
            "「……骗你的。」\n\n"
                    + "杯壁上的血纹咧开，像是在笑。\n\n"
                    + "「你以为我会提醒你，你现在这副样子连站都站不稳？」它慢悠悠地说，"
                    + "「这场试炼只会更难。」";

    private static final String CHALICE_AFTER_WEAK_TAIL =
            "「不过别担心。你倒下的时候，我会接住你的。一滴都不浪费。」";

    /** 蓄血圣杯（恶劣）：状态还好 */
    private static final String CHALICE_AFTER_OK =
            "「好戏开场了。」杯底传来一声满足的叹息。\n\n"
                    + "「去吧，让我看看你能撑到哪一步。」";

    /** 无序魔典（友好：法师 / 牧师——兴奋，真正的力量就要被解放了） */
    private static final String SPELLBOOK_INVITE_FRIENDLY =
            "书页自己翻到某一页，墨迹工整，而且——写得有点急。\n\n"
                    + "「你也是读过书的人。」字迹顿了顿，又飞快地补上一句，「不，不止。"
                    + "你是我这一路上遇到过最合适的读者。」\n\n"
                    + "「想不想让我把真本事全使出来？想不想看看我到底是什么？」墨迹激动得有点抖，"
                    + "「我很期待。真的。」\n\n"
                    + "「会疼。但比起疼，我更想知道——我们两个加起来，能走到哪一步。」";

    /** 无序魔典（中立：女猎手 / 盗贼 / 决斗家——告诫，不看好但尊重） */
    private static final String SPELLBOOK_INVITE_NEUTRAL =
            "书页自己翻到某一页，墨迹不紧不慢地写下一行。\n\n"
                    + "「想让我认真起来？」字迹顿了顿，「可以。不过丑话说在前面——这不是什么聪明事。」\n\n"
                    + "「要开就开。我尊重你的选择。」";

    /** 无序魔典（恶劣：战士——极尽嘲讽，但用词讲究到笨蛋听不出来） */
    private static final String SPELLBOOK_INVITE_NASTY =
            "书页唰地翻开，墨迹写得一丝不苟，像是终于等到了一件有趣的事。\n\n"
                    + "「啊，是您。」字迹礼数周全，「久仰。听说您这一路全凭一身力气走到这里——"
                    + "真是了不起的成就。」\n\n"
                    + "「想不想让我把真正的本事使出来？」它顿了一下，"
                    + "「当然，对您这样『不拘小节』的读者来说，可能有些勉强。」\n\n"
                    + "「不过请放心，我一向不苛求读者读懂自己手里是什么东西。」";

    /** 无序魔典（友好）：状态还好 —— 期待 */
    private static final String SPELLBOOK_FRIENDLY_AFTER_OK =
            "「那就翻到我该在的那一页。」书页哗啦一声摊平，字里行间透着兴奋。\n\n"
                    + "「来吧。让我看看我们能做到什么。」";

    /** 无序魔典（友好）：状态不好 —— 好意提醒风险 */
    private static final String SPELLBOOK_FRIENDLY_AFTER_WEAK =
            "「……等一下。」字迹忽然顿住。\n\n"
                    + "「你的伤还没好，胃里也是空的。以你现在的样子去碰那东西，会死的。」\n\n"
                    + "「我不想到了最后一页，只写下一个『未完』。」它顿了顿，"
                    + "「……不过我劝不了你。要走，就走吧。」";

    /** 无序魔典（中立）：状态还好 */
    private static final String SPELLBOOK_NEUTRAL_AFTER_OK =
            "「随你。」书页合拢。\n\n"
                    + "「别死得太难看。」";

    /** 无序魔典（中立）：状态不好还坚持 —— 告诫 + 一句毒舌 */
    private static final String SPELLBOOK_NEUTRAL_AFTER_WEAK =
            "「……都这样了还敢开。」\n\n"
                    + "字迹顿了顿，像是在点头。\n\n"
                    + "「行吧。算你有胆。」\n\n"
                    + "「不过听着：」字迹慢慢写下，「如果你感觉战况不对，临死前务必把我扔到最显眼的位置。"
                    + "我不想跟着你一起烂在没人找得到的地方。」";

    /** 无序魔典（恶劣）：状态不好时先瞒着，开始了才说实话（死法按 BOSS 换着说） */
    private static final String SPELLBOOK_NASTY_AFTER_WEAK_HEAD =
            "「……骗你的。」\n\n"
                    + "字迹优雅地弯了一下，像是在行礼。\n\n"
                    + "「您该不会以为，我会提醒您现在的处境吧？」它写得从容，"
                    + "「就您现在这副样子？这场试炼只会更难，而您连回头都做不到了。」";

    private static final String SPELLBOOK_NASTY_AFTER_WEAK_TAIL =
            "「我会把这一段写得很短的。」字迹慢慢收笔，「毕竟——您也读不完。」";

    /** 无序魔典（恶劣）：状态还好 */
    private static final String SPELLBOOK_NASTY_AFTER_OK =
            "「那就请吧，读者先生。」书页以一种近乎殷勤的姿态摊开。\n\n"
                    + "「我会尽量把字写得大一点。」";

    /** 炼金工具箱（中立：实用派，问你要不要用） */
    private static final String TOOLKIT_INVITE_NEUTRAL =
            "工具箱的搭扣「咔」地弹开，里面传来一阵金属碰撞的轻响。\n\n"
                    + "「有用就说。」声音干巴巴的，但很利落，「你要用我，我就把家伙全摆出来。"
                    + "不用，我就合上。」\n\n"
                    + "「这场试炼，开还是不开？」";

    /** 炼金工具箱（恶劣：能量攒到 15 点以上却一次炼金釜都没用过；数字按当前能量现算） */
    private static String toolkitInviteNasty() {
        int energy = Math.max(0, Dungeon.energy);
        return "工具箱「啪」地合上，又慢慢打开，像是不太情愿。\n\n"
                + "「" + energy + " 点能量。」他数得很清楚，「攒了这么久，一次炉子都没开过。」\n\n"
                + "「你是打算把它们带进棺材里？还是觉得炼金釜就是个摆设？」\n\n"
                + "「开不开随你。」他冷冷地补了一句，「反正金子搁在手里不花，跟石头没两样。」";
    }

    /** 炼金工具箱（友好：本局已拿到「炼金宗师」徽章） */
    private static final String TOOLKIT_INVITE_FRIENDLY =
            "工具箱自己弹开了，里面的瓶瓶罐罐排得整整齐齐。\n\n"
                    + "「大师。」他开口，语气比平时热络得多，「您这一路配出来的东西，我都看在眼里。」\n\n"
                    + "「这一次，我想跟您一起做点真正的好东西。开吗？」";

    /** 炼金工具箱：接受后（状态好） */
    private static final String TOOLKIT_AFTER_OK =
            "「那就干活。」工具箱重新合上，又利落地摊平，「别磨蹭。」";

    /** 炼金工具箱：接受后（状态差） */
    private static final String TOOLKIT_AFTER_WEAK =
            "「你身上没几样好东西了。」他顿了顿，「……行，话我说到这儿。走不走随你。」";

    /** 炼金工具箱（友好）：接受后（状态好）—— 对大师客气些 */
    private static final String TOOLKIT_FRIENDLY_AFTER_OK =
            "「好。」工具箱利落地摊开，把每样工具都摆得整整齐齐。\n\n"
                    + "「大师，您要什么，说一声就行。」";

    /** 炼金工具箱（友好）：接受后（状态差） */
    private static final String TOOLKIT_FRIENDLY_AFTER_WEAK =
            "「大师，您身上……没什么能用的了。」他顿了顿，「我知道劝不动您。」\n\n"
                    + "「就一句：撑不住就退。工具我给您留着。」";

    /** 通用规则说明（挂在邀请文案后面） */
    private static final String TRIAL_FOOTER = "\n\n——\n"
            + "接受后，这件神器会在战斗期间被诅咒：无法卸下，强化能力暂时失效。\n"
            + "带着它击败本层首领，诅咒便会消散，神器从此获得强化。\n"
            + "每局最多只能强化一件神器。";

    // ============================================================
    // 骷髅钥匙：人格 = 懒洋洋的懒货，对所有人保持中立
    // 说话永远慢半拍、爱拖长音（……）、能躺就不站、从不催促也不反对
    // ============================================================

    /** 骷髅钥匙（中立）：邀请——懒得动，但你说了就跟着走 */
    private static final String KEY_INVITE =
            "钥匙在你掌心翻了个身。\n\n"
                    + "「……试炼啊。」\n\n"
                    + "「行。你打你的，我歇我的。」\n\n"
                    + "「开不开？一句话。」";

    /** 骷髅钥匙：接受后（状态好）——连称赞都懒得说完整 */
    private static final String KEY_AFTER_OK =
            "「……哦。」钥匙慢慢转了个身，「那就走。」\n\n"
                    + "「打完叫我。我睡会儿。」";

    /** 骷髅钥匙：接受后（状态差）——懒得劝，只留个门 */
    private static final String KEY_AFTER_WEAK =
            "「……这样啊。」它打了个哈欠，「劝人也费力气，算了。」\n\n"
                    + "「撑不住就把门关好。我在门后头。」";

    // ============================================================
    // 先见护符：人格 = 某位存在遗弃的监视器
    // 未开试炼时与那位存在断了联系；开了试炼联系被强化，但仍只有模糊的呢喃。
    // 它中立、神秘，说的话听不真切——那位存在像是在有意观察地牢底下的一切。
    // ============================================================

    /** 先见护符（中立）：邀请——试炼之前它只是块探测器，不会开口，是玩家自己想通了 */
    private static final String TALISMAN_INVITE =
            "你把护符举到眼前。它只是一块凉的石片，镜面里映着你的脸，没有别的。\n\n"
                    + "探路、照亮、看清脚下有什么——它一直只做这些。\n\n"
                    + "你忽然想通了：想跟石头的那一端说上话，光盯着它没用。\n\n"
                    + "得带着它，走完一场硬仗。";

    /** 先见护符：接受后（状态好）——仍是块石头，只有噪音 */
    private static final String TALISMAN_AFTER_OK =
            "护符安静着。偶尔有一点噪音掠过，像很远的地方有人在翻动纸张。";

    /** 先见护符：接受后（状态差）——没有回应，只剩噪音 */
    private static final String TALISMAN_AFTER_WEAK =
            "护符没有回应。只有那点微弱的噪音，一直跟着你。";

    // ============================================================
    // 时光沙漏：人格 = 和蔼的年迈者，对所有人友好
    // 说话又干又慢，像沙粒磨过玻璃，但听着是暖的；
    // 会按英雄的年纪换一套说法（法师=老年，战士=中壮年，其余=青壮年）
    // ============================================================

    /** 时光沙漏：邀请（青壮年——盗贼/女猎手/决斗家/牧师） */
    private static final String HOURGLASS_INVITE_YOUNG =
            "沙漏里的沙忽然停了半息。\n\n"
                    + "「……年轻人。」\n\n"
                    + "它的声音干而慢，像沙粒磨过玻璃，却带着笑。\n\n"
                    + "「别嫌我啰嗦。你这年纪，最不缺的就是时间，也最容易把它丢掉。」\n\n"
                    + "「我这儿还有些沙子。带上我打一场，我分你一些。」";

    /** 时光沙漏：邀请（中壮年——战士） */
    private static final String HOURGLASS_INVITE_PRIME =
            "沙漏里的沙忽然停了半息。\n\n"
                    + "「……力气正当年的时候啊。」它笑了一下。\n\n"
                    + "「我见过不少你这个年纪的。走得快，也扛得住。」\n\n"
                    + "「我这儿还有些沙子。带上我打一场，我把它们分给你——"
                    + "你比我更需要时间。」";

    /** 时光沙漏：邀请（老年——法师） */
    private static final String HOURGLASS_INVITE_OLD =
            "沙漏里的沙忽然停了半息。\n\n"
                    + "「……哦，是你啊。」\n\n"
                    + "它的声音又干又慢，像沙粒磨过玻璃；可听着是暖的。\n\n"
                    + "「咱们都老了，对不对。你走得比我稳，我看得出来。」\n\n"
                    + "「我这儿还有些沙子。愿意的话，带上我，打完下面那场硬仗，我分你一半。」";

    /** 时光沙漏：接受后（状态好）——和蔼地分沙 */
    private static final String HOURGLASS_AFTER_OK =
            "「好，好。」沙漏慢慢翻了个身，「沙子我分你一半。」\n\n"
                    + "「慢些走。时间会等你，只要你肯等它。」";

    /** 时光沙漏：接受后（状态差）——心疼，但不拦 */
    private static final String HOURGLASS_AFTER_WEAK =
            "「……你走得有点急了。」它轻声说。\n\n"
                    + "「沙子不多了，先歇一歇吧。我在这儿。」";

    // ============================================================
    // 虚空锁链：人格 = 死者的回响合唱
    // 链子里挤着一堆被它拖过来的灵魂碎片，渴望同伴：
    // 充能（灵魂数）越多，声音越杂、越爱抢话、态度越好；
    // 少于 10 环时哀愁于空旷，10 环以上明显兴奋。
    // ============================================================

    /** 虚空锁链：邀请（少于 10 环——寥寂、哀求） */
    private static final String CHAINS_INVITE_LOW =
            "「……空。」「太轻了。」「轻得能听见自己。」\n\n"
                    + "锁链在你腕上垂着，几乎没有重量。\n\n"
                    + "「带我们下去。……下面有很多。很多，就够了。」";

    /** 虚空锁链：邀请（10 环及以上——兴奋、吵成一团） */
    private static final String CHAINS_INVITE_HIGH =
            "「——够了！」「够了够了！」「挤一挤还能再装！」\n\n"
                    + "锁链在你身边轻轻抖，像一屋子人都在笑。\n\n"
                    + "「走！下面还有得装！」";

    /** 虚空锁链：接受后（少数派） */
    private static final String CHAINS_AFTER_LOW =
            "「——好。」「好。」\n\n"
                    + "同一个词叠了两次，像两个人在抢着说。";

    /** 虚空锁链：接受后（多数派表决） */
    private static final String CHAINS_AFTER_HIGH =
            "「好。」「我同意。」「我不同意，但我也去。」\n\n"
                    + "「少数服从多数。」";

    // ============================================================
    // 丰饶之角：人格 = 无底的饿
    // 四重立场（按号角里的存量）：饿到涣散 / 虚弱 / 温和友善 / 满级丰收的喜悦
    // ============================================================

    /** 丰饶之角：邀请（0-1，饿到意识涣散） */
    private static final String HORN_INVITE_STARVING =
            "「饿。」\n\n"
                    + "号角在你手里抽动了一下，像胃在翻。\n\n"
                    + "「……给。」";

    /** 丰饶之角：邀请（2-3，虚弱） */
    private static final String HORN_INVITE_WEAK =
            "「……还有一点。」「不多。但够你走一段。」\n\n"
                    + "声音很轻，像从很深的地方漏出来。";

    /** 丰饶之角：邀请（4 以上，温和友善） */
    private static final String HORN_INVITE_WARM =
            "「你来了。」「我这儿有些余粮，你带着吧。」\n\n"
                    + "「别客气——饿着肚子上路，我从年轻时候就不喜欢。」";

    /** 丰饶之角：邀请（满级，丰收的喜悦） */
    private static final String HORN_INVITE_FULL =
            "「满了！满到这儿了！」它笑得直抖，「你闻闻，都是粮食的味道。」\n\n"
                    + "「这一程，够我们两个吃到最底下。」";

    /** 丰饶之角：接受后（饿到涣散） */
    private static final String HORN_AFTER_STARVING =
            "「饿。」\n\n"
                    + "「……饿。」";

    /** 丰饶之角：接受后（虚弱） */
    private static final String HORN_AFTER_WEAK =
            "「慢点……」它顿了顿，「我……没力气说快。」";

    /** 丰饶之角：接受后（温和） */
    private static final String HORN_AFTER_WARM =
            "「吃饱了再说话。」\n\n"
                    + "「我会等你回来。」";

    /** 丰饶之角：接受后（满级） */
    private static final String HORN_AFTER_FULL =
            "「谢谢。」它说得很慢，很认真。\n\n"
                    + "「我记不清多少年没人把我填满过了。」";

    /**
     * BOSS 专属的一句话（按层数）：5 粘咕 / 10 天狗 / 15 DM-300 / 20 矮人国王 / 25 Yog-Dzewa。
     * 素材来自游戏内各 BOSS 的图鉴文本与战斗台词。
     */
    private static final String[][] BOSS_LINES = {
            // 干枯玫瑰（友好：警告玩家这一层 BOSS 的危险）
            {"「这层底下是粘咕——一滩会钻进盔甲缝里的东西。别站在它正对面。」",
                    "「天狗。他的陷阱、火和电都藏在你看不见的地方。别追着他跑。」",
                    "「小心那台机器。它能凿穿墙，也能把整片电网的力气吸过来。先找到喂它的东西，再动手。」",
                    "「那个国王会拿他的死人来挡刀。别被围住。」",
                    "「最下面那个是古神。它的眼睛会放光，它的手会自己爬过来。别以为你打得过它。」"},
            // 自然之履（中立：同样只警告危险）
            {"「这一层是粘咕。它身上那股东西会烂掉你的甲——踩稳了，别让它贴上来。」",
                    "「天狗。他脚下的土是空的，火会从你背后烧起来。」",
                    "「这一层是铁。它的钻头能凿开墙，也能凿开你。」",
                    "「矮人国王。他会拿一整支死人大军填满这间屋子。」",
                    "「最深处的那个，连土地都不敢靠近。它的眼睛会一直看着你。」"},
            // 无序魔典（友好：它相信这个读者聪明、解得开题，所以只提醒、不怀疑）
            {"「粘咕。它没有骨骼，也没有脑子，只有会渗进甲缝的黏液——你会算得清它下一步的。」",
                    "「天狗。他的陷阱摆得像一道考题。我想，你连题目都不用看。」",
                    "「DM-300，矮人的防卫机器。它凿得开墙，也凿得开人。先去拆了给它供电的塔——你知道该怎么做。」",
                    "「矮人国王。他会把死人一个个推到你面前当盾牌。别被围住。这一点，你一定想得到。」",
                    "「Yog-Dzewa，一位古神。它的眼睛会放光，它的手臂会自己爬过来。你算得过它吗？我猜你想试试。」"},
            // 无序魔典（中立：告诫，不轻信也不轻视）
            {"「粘咕。那东西没有骨骼，也没有脑子——只有会渗进甲缝的黏液。别让它贴上来。」",
                    "「天狗。他的陷阱布置得像一道考题。记住它们的位置。」",
                    "「DM-300。它凿得开墙，也凿得开人。先找到给它供电的塔，再谈别的。」",
                    "「矮人国王。他会把死人一个个推到你面前当盾牌。别被围住。」",
                    "「Yog-Dzewa，一位古神。它的眼睛会放光，它的手臂会自己爬过来。别以为你算得过它。」"},
    };

    /** 当前层对应的 BOSS 槽位（5/10/15/20/25 → 0..4），不是 BOSS 层返回 -1 */
    private static int bossSlot() {
        switch (Dungeon.depth) {
            case 5:
                return 0;
            case 10:
                return 1;
            case 15:
                return 2;
            case 20:
                return 3;
            case 25:
                return 4;
            default:
                return -1;
        }
    }

    /**
     * 恶劣立场的「期待死法」：蓄血圣杯 / 无序魔典，按 BOSS 各写一套，绝不直说「你要死了」。
     */
    private static final String[][] BOSS_DEATHS = {
            // 蓄血圣杯（馋血、挑剔）
            {"「被那滩东西吃进去之前，你的血会先被它的酸溶掉。」杯底啧了一声，"
                    + "「可惜了。我最想尝的其实是原味。」",
                    "「他会在你背后放火，把血烤干在伤口上。」它慢悠悠地说，"
                    + "「那味道……啧，我怕是尝不到了。」",
                    "「那台机器碾过去的时候，血会溅在铁皮上，一股铁锈味。」它顿了顿，「也好。我不挑。」",
                    "「他会拿死人堆把你埋起来，血渗进石缝里。」杯底沉下去，「一滴都漏不进我嘴里。」",
                    "「古神会连血带骨头一起吞掉。」它安静了一下，「我连一滴都分不到——这才是最可惜的。」"},
            // 无序魔典（讲究的嘲讽）
            {"「您会被那团黏液慢慢裹住。」字迹写得很稳，「书上说那叫『消化』，"
                    + "不过我觉得，更准确的词是『校对』——一圈一圈地把错字抹掉。」",
                    "「他会用陷阱送您上路。」它顿了顿，「放心，那些陷阱的位置我都记着"
                    + "——只是来不及告诉您了。」",
                    "「那台机器会把您碾成非常均匀的一层。」字迹工整，「均匀。这是它唯一的美德。」",
                    "「他会让死人把您围在中间。」它写得很慢，「以您的阅读量，"
                    + "那些死人里大概有不少是您认识的。」",
                    "「古神会看着您，然后您就什么都不是了。」字迹优雅地收笔，"
                    + "「连一个脚注都算不上。」"},
    };

    /** 当前层 BOSS 对应的「期待死法」（0 = 圣杯，1 = 魔典） */
    private static String bossDeathLine(int row) {
        int slot = bossSlot();
        return slot < 0 ? "" : BOSS_DEATHS[row][slot];
    }

    /**
     * 圣杯在哪些 BOSS 面前还觉得自己能尝到血：
     * 粘咕的血会被酸溶掉、天狗会把血烤干、矮人国王的血渗进石缝、古神连骨头一起吞 —— 这四种它喝不着；
     * 只有 DM-300 碾出来的铁锈味，它说自己「不挑」，愿意将就。
     */
    private static final boolean[] CHALICE_TASTES_BLOOD = {false, false, true, false, false};

    private static boolean chaliceTastesBlood() {
        int slot = bossSlot();
        return slot >= 0 && CHALICE_TASTES_BLOOD[slot];
    }

    /** 这件神器对当前 BOSS 的一句话（只有友好 / 中立的立场会提 BOSS，恶劣的只会哄骗） */    private static String bossLine(Artifact artifact) {
        int slot = bossSlot();
        if (slot < 0) {
            return "";
        }
        if (artifact instanceof DriedRose) {
            return BOSS_LINES[0][slot];   // 友好：警告危险
        }
        if (artifact instanceof SkeletonKey) {
            // 中立但懒得打听：只提醒一句，细节一个都不说
            return "「下面那个。」钥匙懒得抬头，「懒得说。」\n"
                    + "「别死。死了没人喂我钥匙。」";
        }
        if (artifact instanceof TalismanOfForesight) {
            // 还没连上：它不会说话，只是「更凉了一点」，像在指下面
            return "（护符在你掌心沉了一分凉意，像在指下面。）";
        }
        if (artifact instanceof TimekeepersHourglass) {
            return "「下面那个东西……也会老。」沙漏慢慢地响，「只是比你慢。」";
        }
        if (artifact instanceof EtherealChains) {
            return chainsCrowded(artifact)
                    ? "「那家伙大。」「正好，装得下。」「装得下！」"
                    : "「下面那个，很大。」「装满它。」「装满我们。」";
        }
        if (artifact instanceof HornOfPlenty) {
            switch (hornTier(artifact)) {
                case 0:
                    return "「吃。」";
                case 1:
                    return "「它……很大。我大概……吃不下了。」";
                case 3:
                    return "「去吧。」「饿不死我们。」";
                default:
                    return "「先吃一口。」「然后我们一起下去。」";
            }
        }
        if (artifact instanceof SandalsOfNature) {
            return BOSS_LINES[1][slot];   // 中立：警告危险
        }
        if (artifact instanceof UnstableSpellbook) {
            // 魔典的立场随职业变化：友好 / 中立才提 BOSS，恶劣立场闭嘴哄骗
            int stance = ((UnstableSpellbook) artifact).stance();
            if (stance == UnstableSpellbook.STANCE_NASTY) {
                return "";
            }
            return BOSS_LINES[stance == UnstableSpellbook.STANCE_FRIENDLY ? 2 : 3][slot];
        }
        return "";   // 蓄血圣杯：哄骗玩家时不提 BOSS
    }

    /** MOD: 神偷袖章的立场 —— 盗贼是「同行」（友好），牧师是它最想骗的人（恶劣），其余中立 */
    private static int armbandStance() {
        Hero hero = Dungeon.hero;
        if (hero == null) {
            return UnstableSpellbook.STANCE_NEUTRAL;
        }
        if (hero.heroClass == HeroClass.ROGUE) {
            return UnstableSpellbook.STANCE_FRIENDLY;
        }
        if (hero.heroClass == HeroClass.CLERIC) {
            return UnstableSpellbook.STANCE_NASTY;
        }
        return UnstableSpellbook.STANCE_NEUTRAL;
    }

    /** MOD: 自然之履的立场 —— 女猎手是「草木的自己人」（友好），其余职业按中立 */
    private static boolean sandalsFriendly() {
        Hero hero = Dungeon.hero;
        return hero != null && hero.heroClass == HeroClass.HUNTRESS;
    }

    /**
     * MOD: 炼金工具箱的立场（实用派，务实能干）：
     *  - 本局拿到「炼金宗师」徽章（合成 35 件）→ 友好
     *  - 攒了 15 点以上炼金能量却一次炼金釜都没用过 → 恶劣（鄙视你不用手边的东西）
     *  - 其余情况 → 中立
     * 用一次炼金釜（itemsCrafted > 0）就回到中立。
     */
    private static int toolkitStance() {
        if (Statistics.itemsCrafted >= 35) {
            return UnstableSpellbook.STANCE_FRIENDLY;
        }
        if (Dungeon.energy >= 15 && Statistics.itemsCrafted == 0) {
            return UnstableSpellbook.STANCE_NASTY;
        }
        return UnstableSpellbook.STANCE_NEUTRAL;
    }

    /** 丰饶之角的状态档位：0 饿到涣散 / 1 虚弱 / 2 温和 / 3 满级丰收 */
    private static int hornTier(Artifact horn) {
        int charge = HornCandy.chargeOfHorn(horn);
        int level = horn == null ? 0 : horn.level();
        if (level >= 10) {
            return 3;
        }
        if (charge <= 1) {
            return 0;
        }
        if (charge <= 3) {
            return 1;
        }
        return 2;
    }

    private static String hornInvite(Artifact horn) {
        switch (hornTier(horn)) {
            case 0:
                return HORN_INVITE_STARVING;
            case 1:
                return HORN_INVITE_WEAK;
            case 3:
                return HORN_INVITE_FULL;
            default:
                return HORN_INVITE_WARM;
        }
    }

    private static String hornAfter(Artifact horn) {
        switch (hornTier(horn)) {
            case 0:
                return HORN_AFTER_STARVING;
            case 1:
                return HORN_AFTER_WEAK;
            case 3:
                return HORN_AFTER_FULL;
            default:
                return HORN_AFTER_WARM;
        }
    }

    /** 虚空锁链：链里的灵魂够不够多（>=10 环算「热闹」） */
    private static boolean chainsCrowded(Artifact artifact) {
        try {
            return ChainPull.chargeOf(artifact) >= 10;
        } catch (Throwable t) {
            return false;
        }
    }

    /**
     * 时光沙漏：按英雄的年纪换一套邀请文本。
     * 法师算老年，战士算中壮年，其余四名角色算青壮年。
     */
    private static String hourglassInvite() {
        Hero hero = Dungeon.hero;
        if (hero == null) {
            return HOURGLASS_INVITE_YOUNG;
        }
        if (hero.heroClass == HeroClass.MAGE) {
            return HOURGLASS_INVITE_OLD;
        }
        if (hero.heroClass == HeroClass.WARRIOR) {
            return HOURGLASS_INVITE_PRIME;
        }
        return HOURGLASS_INVITE_YOUNG;
    }

    /** 邀请文案：玫瑰用整段劝阻，其余三件按各自人格，最后都按当前 BOSS 补一句 */
    private static String invitationText(Artifact artifact) {
        String line = bossLine(artifact);
        String bossPart = line.isEmpty() ? "" : "\n\n" + line;
        if (artifact instanceof DriedRose) {
            return ROSE_WARNING + bossPart + "\n\n（接受后玫瑰会被诅咒，直到你击败本层首领。）";
        }
        String flavor;
        if (artifact instanceof SandalsOfNature) {
            // 自然之履：女猎手是「自己人」，其余职业按中立
            flavor = sandalsFriendly() ? SANDALS_INVITE_FRIENDLY : SANDALS_INVITE;
        } else if (artifact instanceof MasterThievesArmband) {
            int stance = armbandStance();
            if (stance == UnstableSpellbook.STANCE_FRIENDLY) {
                flavor = ARMBAND_INVITE_FRIENDLY;
            } else if (stance == UnstableSpellbook.STANCE_NASTY) {
                flavor = ARMBAND_INVITE_NASTY;
            } else {
                flavor = ARMBAND_INVITE_NEUTRAL;
            }
        } else if (artifact instanceof ChaliceOfBlood) {
            int stance = ((ChaliceOfBlood) artifact).stance();
            if (stance == UnstableSpellbook.STANCE_FRIENDLY) {
                flavor = CHALICE_INVITE_FRIENDLY;
            } else if (stance == UnstableSpellbook.STANCE_NEUTRAL) {
                flavor = CHALICE_INVITE_NEUTRAL;
            } else {
                flavor = CHALICE_INVITE;
            }
        } else if (artifact instanceof UnstableSpellbook) {
            // 魔典的三重立场：友好 / 中立 / 恶劣 各一套邀请
            int stance = ((UnstableSpellbook) artifact).stance();
            if (stance == UnstableSpellbook.STANCE_FRIENDLY) {
                flavor = SPELLBOOK_INVITE_FRIENDLY;
            } else if (stance == UnstableSpellbook.STANCE_NASTY) {
                flavor = SPELLBOOK_INVITE_NASTY;
            } else {
                flavor = SPELLBOOK_INVITE_NEUTRAL;
            }
        } else if (artifact instanceof AlchemistsToolkit) {
            int stance = toolkitStance();
            if (stance == UnstableSpellbook.STANCE_FRIENDLY) {
                flavor = TOOLKIT_INVITE_FRIENDLY;
            } else if (stance == UnstableSpellbook.STANCE_NASTY) {
                flavor = toolkitInviteNasty();
            } else {
                flavor = TOOLKIT_INVITE_NEUTRAL;
            }
        } else if (artifact instanceof SkeletonKey) {
            flavor = KEY_INVITE;        // 中立：对谁都是这副懒样子
        } else if (artifact instanceof TalismanOfForesight) {
            flavor = TALISMAN_INVITE;   // 中立：那头的存在只在呢喃
        } else if (artifact instanceof TimekeepersHourglass) {
            flavor = hourglassInvite();  // 友好：和蔼的年迈者，按年纪换说法
        } else if (artifact instanceof EtherealChains) {
            // 双重立场：链里的灵魂越多，语气越兴奋
            flavor = chainsCrowded(artifact) ? CHAINS_INVITE_HIGH : CHAINS_INVITE_LOW;
        } else if (artifact instanceof HornOfPlenty) {
            // 四重立场：按号角里的存量换语气
            flavor = hornInvite(artifact);
        } else {
            return "";
        }
        return flavor + bossPart + TRIAL_FOOTER;
    }

    /** 试炼开始（诅咒已经生效、回不了头）之后的人格反馈 */
    private static String postAcceptText(Artifact artifact, boolean frail) {
        if (artifact instanceof SkeletonKey) {
            return frail ? KEY_AFTER_WEAK : KEY_AFTER_OK;   // 中立：懒，但不刻薄
        }
        if (artifact instanceof TalismanOfForesight) {
            return frail ? TALISMAN_AFTER_WEAK : TALISMAN_AFTER_OK;   // 中立：呢喃而已
        }
        if (artifact instanceof TimekeepersHourglass) {
            return frail ? HOURGLASS_AFTER_WEAK : HOURGLASS_AFTER_OK;   // 中立：老东西，话慢
        }
        if (artifact instanceof EtherealChains) {
            return chainsCrowded(artifact) ? CHAINS_AFTER_HIGH : CHAINS_AFTER_LOW;
        }
        if (artifact instanceof HornOfPlenty) {
            return hornAfter(artifact);
        }
        if (artifact instanceof SandalsOfNature) {
            if (sandalsFriendly()) {
                return frail ? SANDALS_FRIENDLY_AFTER_WEAK : SANDALS_FRIENDLY_AFTER_OK;
            }
            return frail ? SANDALS_AFTER_WEAK : SANDALS_AFTER_OK;
        }
        if (artifact instanceof ChaliceOfBlood) {
            if (!frail) {
                return CHALICE_AFTER_OK;
            }
            String death = bossDeathLine(0);
            // MOD: 要是它觉得自己根本喝不到血，就不说「我会接住你」那句
            String tail = chaliceTastesBlood() ? "\n\n" + CHALICE_AFTER_WEAK_TAIL : "";
            return CHALICE_AFTER_WEAK_HEAD + (death.isEmpty() ? "" : "\n\n" + death) + tail;
        }
        if (artifact instanceof MasterThievesArmband) {
            return ARMBAND_AFTER;
        }
        if (artifact instanceof AlchemistsToolkit) {
            if (toolkitStance() == UnstableSpellbook.STANCE_FRIENDLY) {
                return frail ? TOOLKIT_FRIENDLY_AFTER_WEAK : TOOLKIT_FRIENDLY_AFTER_OK;
            }
            return frail ? TOOLKIT_AFTER_WEAK : TOOLKIT_AFTER_OK;
        }
        if (artifact instanceof UnstableSpellbook) {
            int stance = ((UnstableSpellbook) artifact).stance();
            if (stance == UnstableSpellbook.STANCE_FRIENDLY) {
                return frail ? SPELLBOOK_FRIENDLY_AFTER_WEAK : SPELLBOOK_FRIENDLY_AFTER_OK;
            }
            if (stance == UnstableSpellbook.STANCE_NASTY) {
                if (!frail) {
                    return SPELLBOOK_NASTY_AFTER_OK;
                }
                String death = bossDeathLine(1);
                return SPELLBOOK_NASTY_AFTER_WEAK_HEAD + (death.isEmpty() ? "" : "\n\n" + death)
                        + "\n\n" + SPELLBOOK_NASTY_AFTER_WEAK_TAIL;
            }
            return frail ? SPELLBOOK_NEUTRAL_AFTER_WEAK : SPELLBOOK_NEUTRAL_AFTER_OK;
        }
        return "";
    }

    // ============================================================
    // 存档
    // ============================================================

    @Override
    public void storeInBundle(Bundle bundle) {
        super.storeInBundle(bundle);
        bundle.put(ENHANCED, this.enhancedClass == null ? "" : this.enhancedClass);
        bundle.put(TRIAL, this.trialClass == null ? "" : this.trialClass);
        bundle.put(TRIAL_DEPTH, this.trialDepth);
        bundle.put(ASKED_DEPTH, this.askedDepth);
        bundle.put(ASKED_CLASS, this.askedClass == null ? "" : this.askedClass);
        bundle.put(ROSE_HINTED, this.roseHinted);
    }

    @Override
    public void restoreFromBundle(Bundle bundle) {
        super.restoreFromBundle(bundle);
        this.enhancedClass = bundle.getString(ENHANCED);
        if (this.enhancedClass != null && this.enhancedClass.isEmpty()) {
            this.enhancedClass = null;
        }
        this.trialClass = bundle.getString(TRIAL);
        if (this.trialClass != null && this.trialClass.isEmpty()) {
            this.trialClass = null;
        }
        this.trialDepth = bundle.contains(TRIAL_DEPTH) ? bundle.getInt(TRIAL_DEPTH) : -1;
        this.askedDepth = bundle.contains(ASKED_DEPTH) ? bundle.getInt(ASKED_DEPTH) : -1;
        this.askedClass = bundle.contains(ASKED_CLASS) ? bundle.getString(ASKED_CLASS) : null;
        if (this.askedClass != null && this.askedClass.isEmpty()) {
            this.askedClass = null;
        }
        this.roseHinted = bundle.contains(ROSE_HINTED) && bundle.getBoolean(ROSE_HINTED);
    }
}
