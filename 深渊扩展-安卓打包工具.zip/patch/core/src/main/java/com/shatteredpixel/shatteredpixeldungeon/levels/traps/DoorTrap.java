package com.shatteredpixel.shatteredpixeldungeon.levels.traps;

import com.shatteredpixel.shatteredpixeldungeon.Dungeon;
import com.shatteredpixel.shatteredpixeldungeon.items.artifacts.SkeletonKey;
import com.shatteredpixel.shatteredpixeldungeon.levels.Terrain;
import com.shatteredpixel.shatteredpixeldungeon.items.scrolls.ScrollOfTeleportation;
import com.shatteredpixel.shatteredpixeldungeon.utils.GLog;
import com.watabou.utils.Bundle;

/**
 * MOD: 骷髅钥匙开出来的「门」。
 *
 * 用陷阱做载体，因为陷阱是游戏里唯一能「在地图上画一个标记并且存进关卡」的轻量对象：
 *  - 主门：绿色大圆点，踩上去什么都不发生
 *  - 副门：紫色大圆点，踩上去直接传送回主门
 * activate() 是空的，所以它永远不会被当作陷阱触发（不会掉血、不会中毒）。
 */
public class DoorTrap extends Trap {

    /** true = 主门；false = 副门 */
    public boolean mainDoor = true;
    /** 副门记住的主门坐标 */
    public int targetPos = -1;

    private static final String MAIN = "main_door";
    private static final String TARGET = "target_pos";

    public DoorTrap() {
        this.shape = LARGE_DOT;
        this.color = GREEN;       // 主门默认绿色；副门创建时改成 VIOLET
        this.visible = true;      // 必须显式置真，否则不会绘制
        this.active = true;
        this.reclaimed = false;
        this.canBeHidden = false;
        this.canBeSearched = false;
        this.avoidsClosedSpaces = false;
    }

    @Override
    public void activate() {
        // 门不是陷阱：踩上去不触发任何效果
    }

    @Override
    public void trigger() {
        SkeletonKey.doorStepTeleport();   // 双向传送统一交给钥匙判断
    }

    @Override
    public void storeInBundle(Bundle bundle) {
        super.storeInBundle(bundle);
        bundle.put(MAIN, this.mainDoor);
        bundle.put(TARGET, this.targetPos);
    }

    @Override
    public void restoreFromBundle(Bundle bundle) {
        super.restoreFromBundle(bundle);
        this.mainDoor = !bundle.contains(MAIN) || bundle.getBoolean(MAIN);
        this.targetPos = bundle.contains(TARGET) ? bundle.getInt(TARGET) : -1;
        // 颜色不会随存档保存（原版里它是各类陷阱构造器里写死的），这里按门的类型重设
        this.color = this.mainDoor ? GREEN : VIOLET;
        this.visible = true;
        this.active = true;
    }
}
