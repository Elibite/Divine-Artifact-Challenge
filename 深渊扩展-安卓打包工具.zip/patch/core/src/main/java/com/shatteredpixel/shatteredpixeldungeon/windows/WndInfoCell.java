package com.shatteredpixel.shatteredpixeldungeon.windows;

import com.shatteredpixel.shatteredpixeldungeon.Dungeon;
import com.shatteredpixel.shatteredpixeldungeon.actors.blobs.Blob;
import com.shatteredpixel.shatteredpixeldungeon.messages.Messages;
import com.shatteredpixel.shatteredpixeldungeon.scenes.PixelScene;
import com.shatteredpixel.shatteredpixeldungeon.tiles.CustomTilemap;
import com.shatteredpixel.shatteredpixeldungeon.tiles.DungeonTerrainTilemap;
import com.shatteredpixel.shatteredpixeldungeon.ui.RenderedTextBlock;
import com.shatteredpixel.shatteredpixeldungeon.ui.Window;
import com.watabou.noosa.Image;

/**
 * MOD: 原版 WndInfoCell 的整类覆盖。
 * 与 4.0.2 的唯一差别：被时光沙漏凝成沙柱的高草丛，检视时用专门的名称与描述。
 */
public class WndInfoCell extends Window {

    private static final float GAP = 2.0f;
    private static final int WIDTH = 120;

    private static final String PILLAR_NAME = "被沙粒凝滞的高草";
    private static final String PILLAR_DESC =
            "沙粒把草丛压成了一根硬邦邦的柱子。\n\n"
                    + "走不过去，视线也穿不透；水漫不上来，火也点不着。";

    public static Image cellImage(int cell) {
        int tile = Dungeon.level.map[cell];
        if (Dungeon.level.water[cell]) {
            tile = 29;
        } else if (Dungeon.level.pit[cell]) {
            tile = 0;
        }
        Image customImage = null;
        int x = cell % Dungeon.level.width();
        int y = cell / Dungeon.level.width();
        for (CustomTilemap i : Dungeon.level.customTiles) {
            if (x < i.tileX || x >= i.tileX + i.tileW || y < i.tileY || y >= i.tileY + i.tileH
                    || i.image(x - i.tileX, y - i.tileY) == null) {
                continue;
            }
            customImage = i.image(x - i.tileX, y - i.tileY);
        }
        if (customImage == null) {
            for (CustomTilemap i : Dungeon.level.customTerrain) {
                if (x < i.tileX || x >= i.tileX + i.tileW || y < i.tileY || y >= i.tileY + i.tileH
                        || i.image(x - i.tileX, y - i.tileY) == null) {
                    continue;
                }
                customImage = i.image(x - i.tileX, y - i.tileY);
            }
        }
        if (customImage != null) {
            return customImage;
        }
        if (tile == 29) {
            Image water = new Image(Dungeon.level.waterTex());
            water.frame(0, 0, 16, 16);
            return water;
        }
        return DungeonTerrainTilemap.tile(cell, tile);
    }

    public static String cellName(int cell) {
        if (isPillar(cell)) {
            return PILLAR_NAME;
        }
        CustomTilemap customTile = null;
        int x = cell % Dungeon.level.width();
        int y = cell / Dungeon.level.width();
        for (CustomTilemap i : Dungeon.level.customTiles) {
            if (x < i.tileX || x >= i.tileX + i.tileW || y < i.tileY || y >= i.tileY + i.tileH
                    || i.image(x - i.tileX, y - i.tileY) == null) {
                continue;
            }
            customTile = i;
        }
        if (customTile == null) {
            for (CustomTilemap i : Dungeon.level.customTerrain) {
                if (x < i.tileX || x >= i.tileX + i.tileW || y < i.tileY || y >= i.tileY + i.tileH
                        || i.image(x - i.tileX, y - i.tileY) == null) {
                    continue;
                }
                customTile = i;
            }
        }
        if (customTile != null) {
            x -= customTile.tileX;
            y -= customTile.tileY;
        }
        if (customTile != null && customTile.name(x, y) != null) {
            return customTile.name(x, y);
        }
        return Dungeon.level.tileName(Dungeon.level.map[cell]);
    }

    private static boolean isPillar(int cell) {
        try {
            return com.shatteredpixel.shatteredpixeldungeon.items.artifacts.HourglassSand.isPillar(cell);
        } catch (Throwable t) {
            return false;
        }
    }

    public WndInfoCell(int cell) {
        String desc = "";

        // MOD: 沙柱有自己的名称和描述
        if (isPillar(cell)) {
            IconTitle pillarBar = new IconTitle();
            pillarBar.icon(cellImage(cell));
            pillarBar.label(PILLAR_NAME);
            pillarBar.setRect(0.0f, 0.0f, WIDTH, 0.0f);
            this.add(pillarBar);
            RenderedTextBlock pillarInfo = PixelScene.renderTextBlock(6);
            pillarInfo.text(PILLAR_DESC);
            pillarInfo.maxWidth(WIDTH);
            pillarInfo.setPos(pillarBar.left(), pillarBar.bottom() + 4.0f);
            this.add(pillarInfo);
            this.resize(WIDTH, (int) pillarInfo.bottom() + 2);
            return;
        }

        CustomTilemap customTile = null;
        int x = cell % Dungeon.level.width();
        int y = cell / Dungeon.level.width();
        for (CustomTilemap i : Dungeon.level.customTiles) {
            if (x < i.tileX || x >= i.tileX + i.tileW || y < i.tileY || y >= i.tileY + i.tileH
                    || i.image(x - i.tileX, y - i.tileY) == null) {
                continue;
            }
            customTile = i;
        }
        if (customTile == null) {
            for (CustomTilemap i : Dungeon.level.customTerrain) {
                if (x < i.tileX || x >= i.tileX + i.tileW || y < i.tileY || y >= i.tileY + i.tileH
                        || i.image(x - i.tileX, y - i.tileY) == null) {
                    continue;
                }
                customTile = i;
            }
        }
        if (customTile != null) {
            x -= customTile.tileX;
            y -= customTile.tileY;
        }

        IconTitle titlebar = new IconTitle();
        titlebar.icon(cellImage(cell));
        titlebar.label(cellName(cell));
        desc = customTile != null && customTile.desc(x, y) != null
                ? desc + customTile.desc(x, y)
                : desc + Dungeon.level.tileDesc(Dungeon.level.map[cell]);
        titlebar.setRect(0.0f, 0.0f, WIDTH, 0.0f);
        this.add(titlebar);

        RenderedTextBlock info = PixelScene.renderTextBlock(6);
        this.add(info);
        for (Blob blob : Dungeon.level.blobs.values()) {
            if (!Dungeon.level.heroFOV[cell] && !blob.alwaysVisible || blob.volume <= 0
                    || blob.cur[cell] <= 0 || blob.tileDesc() == null) {
                continue;
            }
            if (desc.length() > 0) {
                desc = desc + "\n\n";
            }
            desc = desc + blob.tileDesc();
        }
        info.text(desc.length() == 0 ? Messages.get(this, "nothing", new Object[0]) : desc);
        info.maxWidth(WIDTH);
        info.setPos(titlebar.left(), titlebar.bottom() + 4.0f);
        this.resize(WIDTH, (int) info.bottom() + 2);
    }
}
