/*
 * MOD: 自然之履「暗影融合」区域 —— 标记 buff。
 * 记录进入区域前的视野距离，离开时用于恢复。
 */
package com.shatteredpixel.shatteredpixeldungeon.actors.buffs;

import com.watabou.utils.Bundle;

public class ShadowZoneMark extends Buff {

    private static final String SAVED_VIEW = "saved_view";

    public int savedView = -1;

    {
        type = buffType.NEUTRAL;
        announced = false;
    }

    @Override
    public boolean act() {
        spend(TICK);
        return true;
    }

    @Override
    public void storeInBundle(Bundle bundle) {
        super.storeInBundle(bundle);
        bundle.put(SAVED_VIEW, this.savedView);
    }

    @Override
    public void restoreFromBundle(Bundle bundle) {
        super.restoreFromBundle(bundle);
        this.savedView = bundle.getInt(SAVED_VIEW);
    }

    @Override
    public String name() {
        return "暗影融合";
    }

    @Override
    public String desc() {
        return "你正站在自然之履造出的暗影之中，视野因此受限。";
    }
}
