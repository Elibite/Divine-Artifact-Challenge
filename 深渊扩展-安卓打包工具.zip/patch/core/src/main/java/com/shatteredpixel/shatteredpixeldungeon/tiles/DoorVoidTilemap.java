package com.shatteredpixel.shatteredpixeldungeon.tiles;

import com.shatteredpixel.shatteredpixeldungeon.levels.Level;
import com.watabou.noosa.Image;
import com.watabou.noosa.Tilemap;
import com.watabou.utils.Bundle;

/**
 * MOD: 门后那片「未知的黑暗」。
 *
 * 世界上什么都不画（那片空地本来就被迷雾永久盖住），这个贴图只负责一件事：
 * 让检视窗口在那格显示「未知的黑暗」和对应说明——{@code WndInfoCell} 只认
 * {@code image()} 非空的自定义贴图，所以图标必须给出一个。
 */
public class DoorVoidTilemap extends CustomTilemap {

    private static final String CELL = "cell";
    private static final String ICON = "environment/custom_tiles/dark_unknown.png";

    /** 那格的地图坐标 */
    public int cell = -1;

    public DoorVoidTilemap() {
    }

    public DoorVoidTilemap(int cell, Level level) {
        this.cell = cell;
        setRect(cell % level.width(), cell / level.width(), 1, 1);
        this.texture = ICON;
    }

    @Override
    public Tilemap create() {
        // 读档时构造函数不会跑（走的是 restoreFromBundle），贴图路径必须在这儿补上；
        // 少了这一句 texture 就是 null，TextureFilm 直接 NPE —— 那是会崩游戏的。
        this.texture = ICON;
        Tilemap v = super.create();
        v.map(new int[1], 1);
        return v;
    }

    @Override
    protected void updateAll(int[] data) {
        data[0] = -1;      // 世界层不画东西
    }

    @Override
    public Image image(int tileX, int tileY) {
        return new Image(ICON, 0, 0, 16, 16);
    }

    /** 从场景里摘掉（拆门 / 换位置时用） */
    public void dispose() {
        if (this.vis != null) {
            this.vis.killAndErase();
            this.vis = null;
        }
    }

    @Override
    public String name(int tileX, int tileY) {
        return "未知的黑暗";
    }

    @Override
    public String desc(int tileX, int tileY) {
        return "一片未知的黑暗。\n\n门后传来呼啸的风声。";
    }

    @Override
    public void restoreFromBundle(Bundle bundle) {
        super.restoreFromBundle(bundle);
        this.cell = bundle.getInt(CELL);
    }

    @Override
    public void storeInBundle(Bundle bundle) {
        super.storeInBundle(bundle);
        bundle.put(CELL, this.cell);
    }
}
