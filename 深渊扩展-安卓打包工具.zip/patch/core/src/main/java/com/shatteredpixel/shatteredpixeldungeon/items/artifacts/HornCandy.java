package com.shatteredpixel.shatteredpixeldungeon.items.artifacts;

import com.shatteredpixel.shatteredpixeldungeon.Dungeon;
import com.shatteredpixel.shatteredpixeldungeon.Statistics;
import com.shatteredpixel.shatteredpixeldungeon.actors.Char;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.ArtifactRecharge;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.Buff;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.Haste;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.MagicImmune;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.Recharging;
import com.shatteredpixel.shatteredpixeldungeon.actors.hero.Hero;
import com.shatteredpixel.shatteredpixeldungeon.actors.hero.HeroClass;
import com.shatteredpixel.shatteredpixeldungeon.actors.mobs.Mob;
import com.shatteredpixel.shatteredpixeldungeon.effects.FloatingText;
import com.shatteredpixel.shatteredpixeldungeon.effects.SpellSprite;
import com.shatteredpixel.shatteredpixeldungeon.items.Item;
import com.shatteredpixel.shatteredpixeldungeon.items.food.WhistleCandy;
import com.shatteredpixel.shatteredpixeldungeon.items.scrolls.ScrollOfRecharging;
import com.shatteredpixel.shatteredpixeldungeon.items.weapon.melee.MeleeWeapon;
import com.shatteredpixel.shatteredpixeldungeon.utils.GLog;
import com.watabou.utils.Random;
import com.watabou.utils.Reflection;

import java.lang.reflect.Field;
import java.util.ArrayList;

/**
 * MOD: 丰饶之角的强化（通过试炼 + 装在神器位）：
 *
 * <ul>
 *   <li><b>吹糖</b>：花 1 点充能，吹出 3 颗「口哨糖」（不吃回合、不顶饿、招来敌人）。</li>
 *   <li><b>借来的吃相</b>：进食时有概率触发**别的职业**的二层进食天赋（二级）；
 *       若抽到战士则用它的一层进食天赋（饱餐）。概率 = 号角等级 × 10%（满级 100%）。</li>
 * </ul>
 */
public class HornCandy {

    /** 强化过、真的装在神器位上、且没被诅咒 */
    public static boolean active() {
        Hero hero = Dungeon.hero;
        if (hero == null || hero.belongings == null || Dungeon.level == null) {
            return false;
        }
        Artifact equipped = hero.belongings.artifact();
        if (!(equipped instanceof HornOfPlenty)) {
            return false;
        }
        if (equipped.cursed || hero.buff(MagicImmune.class) != null) {
            return false;
        }
        return ArtifactTrial.isEnhancedClass(HornOfPlenty.class);
    }

    private static HornOfPlenty horn() {
        Hero hero = Dungeon.hero;
        if (hero == null || hero.belongings == null) {
            return null;
        }
        return hero.belongings.getItem(HornOfPlenty.class);
    }

    // ============================================================
    // 吹糖
    // ============================================================

    public static boolean canCraft() {
        HornOfPlenty h = horn();
        return active() && h != null && chargeOf(h) >= 1;
    }

    /** 供试炼文案使用：读某件号角当前的「存量」（等于充能） */
    public static int chargeOfHorn(Artifact a) {
        return a == null ? 0 : readInt(a, "charge", 0);
    }

    /** 花 1 点充能吹 3 颗口哨糖 */
    public static void craft(Hero hero) {
        HornOfPlenty h = horn();
        if (h == null || !active()) {
            return;
        }
        int charge = chargeOf(h);
        if (charge < 1) {
            GLog.w("号角里没有多余的充能了。");
            return;
        }
        writeInt(h, "charge", charge - 1);
        Item candy = Reflection.newInstance(WhistleCandy.class);
        candy.quantity(3);
        candy.collect(hero.belongings.backpack);
        GLog.p("号角低低地响了一声——三颗口哨糖落在你手里。");
        Item.updateQuickslot();
    }

    // ============================================================
    // 口哨：招来附近的敌人（已废弃，保留空实现以便旧存档兼容）
    // ============================================================

    public static void callNearbyEnemies(Hero hero) {
        // 口哨糖不再自带效果
    }

    // ============================================================
    // 借来的吃相（进食时的随机天赋）
    // ============================================================

    /**
     * 掷一次「借来的吃相」：概率 = 号角等级 × 10%（满级 100%）。
     * 普通进食由 {@link #watchEaten()} 触发；口哨糖直接调这里。
     *
     * @return 是否真的触发了别人的进食天赋
     */
    public static boolean rollBorrowTalent() {
        HornOfPlenty h = horn();
        if (!active() || h == null || Dungeon.hero == null) {
            return false;
        }
        float chance = Math.min(1.0f, h.level() * 0.1f);
        if (Random.Float() >= chance) {
            return false;
        }
        borrowTalent(Dungeon.hero);
        return true;
    }

    /** 上一次看到的「吃过多少口饭」 */
    private static int lastFoodEaten = -1;

    /** 每回合调用：检测有没有吃东西，然后按号角等级掷概率 */
    public static void watchEaten() {
        int eaten = Statistics.foodEaten;
        if (!active()) {
            lastFoodEaten = eaten;
            return;
        }
        if (lastFoodEaten < 0) {
            lastFoodEaten = eaten;
            return;
        }
        if (eaten <= lastFoodEaten) {
            lastFoodEaten = eaten;
            return;
        }
        int meals = eaten - lastFoodEaten;
        lastFoodEaten = eaten;
        for (int i = 0; i < meals; i++) {
            if (rollBorrowTalent()) {
                break;
            }
        }
    }

    /** 随机借一位别人的吃相 */
    private static void borrowTalent(Hero hero) {
        if (hero == null) {
            return;
        }
        ArrayList<HeroClass> pool = new ArrayList<>();
        for (HeroClass c : HeroClass.values()) {
            if (c != hero.heroClass) {
                pool.add(c);
            }
        }
        if (pool.isEmpty()) {
            return;
        }
        HeroClass pick = pool.get(Random.Int(pool.size()));
        String label;
        switch (pick) {
            case WARRIOR:
                // 战士的二层（铁胃）不如一层（饱餐）实在，这里用它的一层
                label = "一顿饱饭";
                heartyMeal(hero);
                break;
            case MAGE:
                label = "充能的一餐";
                wandCharge(hero, 8);
                break;
            case ROGUE:
                label = "秘法的一餐";
                artifactCharge(hero, 5);
                break;
            case HUNTRESS:
                label = "轻快的一餐";
                Buff.prolong(hero, Haste.class, 2.67f);
                break;
            case DUELIST:
                label = "凝神的一餐";
                Buff.affect(hero, MeleeWeapon.Charger.class).gainCharge(1.0f);
                ScrollOfRecharging.charge(hero);
                break;
            default:
                label = "开智的一餐";
                wandCharge(hero, 3);
                artifactCharge(hero, 3);
                break;
        }
        GLog.p("号角哼起了别人的调子——你尝到了「" + label + "」。");
    }

    /** 战士一层：饱餐（二级）——残血时吃一口回点血 */
    private static void heartyMeal(Hero hero) {
        if (hero.HT > 0 && hero.HP / (float) hero.HT < 0.334f) {
            int heal = 2 + 2 * 2;
            hero.HP = Math.min(hero.HP + heal, hero.HT);
            hero.sprite.showStatusWithIcon(65280, Integer.toString(heal), FloatingText.HEALING);
        }
    }

    /** 法师二层：充能的一餐（二级）——法杖多充 8 回合的量 */
    private static void wandCharge(Hero hero, int turns) {
        Buff.prolong(hero, Recharging.class, turns);
        ScrollOfRecharging.charge(hero);
        SpellSprite.show(hero, 2);
    }

    /** 盗贼二层：秘法的一餐（二级）——神器多充 5 回合的量 */
    private static void artifactCharge(Hero hero, int turns) {
        ArtifactRecharge buff = Buff.affect(hero, ArtifactRecharge.class);
        if (buff.left() < turns) {
            buff.set(turns);
        }
        ScrollOfRecharging.charge(hero);
        SpellSprite.show(hero, 2, 0.0f, 1.0f, 1.0f);
    }

    // ============================================================
    // 反射读写沙漏/号角的 protected 字段
    // ============================================================

    private static int chargeOf(Artifact a) {
        return readInt(a, "charge", 0);
    }

    private static int readInt(Artifact a, String field, int def) {
        try {
            Field f = Artifact.class.getDeclaredField(field);
            f.setAccessible(true);
            return f.getInt(a);
        } catch (Throwable t) {
            return def;
        }
    }

    private static void writeInt(Artifact a, String field, int v) {
        try {
            Field f = Artifact.class.getDeclaredField(field);
            f.setAccessible(true);
            f.setInt(a, v);
        } catch (Throwable ignored) {
        }
    }
}
