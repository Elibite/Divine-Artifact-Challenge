/*
 * Decompiled with CFR 0.152.
 */
package com.shatteredpixel.shatteredpixeldungeon.actors.mobs.npcs;

import com.shatteredpixel.shatteredpixeldungeon.Challenges;
import com.shatteredpixel.shatteredpixeldungeon.Dungeon;
import com.shatteredpixel.shatteredpixeldungeon.ShatteredPixelDungeon;
import com.shatteredpixel.shatteredpixeldungeon.Statistics;
import com.shatteredpixel.shatteredpixeldungeon.actors.Actor;
import com.shatteredpixel.shatteredpixeldungeon.actors.Char;
import com.shatteredpixel.shatteredpixeldungeon.actors.blobs.Blob;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.AscensionChallenge;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.BlobImmunity;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.Buff;
import com.shatteredpixel.shatteredpixeldungeon.actors.mobs.npcs.NPC;
import com.shatteredpixel.shatteredpixeldungeon.effects.CellEmitter;
import com.shatteredpixel.shatteredpixeldungeon.effects.Speck;
import com.shatteredpixel.shatteredpixeldungeon.effects.particles.ElmoParticle;
import com.shatteredpixel.shatteredpixeldungeon.items.Heap;
import com.shatteredpixel.shatteredpixeldungeon.items.Ankh;
import com.shatteredpixel.shatteredpixeldungeon.items.Item;
import com.shatteredpixel.shatteredpixeldungeon.items.bags.MagicalHolster;
import com.shatteredpixel.shatteredpixeldungeon.items.bags.PotionBandolier;
import com.shatteredpixel.shatteredpixeldungeon.items.bags.ScrollHolder;
import com.shatteredpixel.shatteredpixeldungeon.items.bombs.Bomb;
import com.shatteredpixel.shatteredpixeldungeon.items.artifacts.Artifact;
import com.shatteredpixel.shatteredpixeldungeon.items.armor.Armor;
import com.shatteredpixel.shatteredpixeldungeon.items.food.SmallRation;
import com.shatteredpixel.shatteredpixeldungeon.items.rings.Ring;
import com.shatteredpixel.shatteredpixeldungeon.items.potions.Potion;
import com.shatteredpixel.shatteredpixeldungeon.items.potions.PotionOfStrength;
import com.shatteredpixel.shatteredpixeldungeon.items.scrolls.Scroll;
import com.shatteredpixel.shatteredpixeldungeon.items.scrolls.ScrollOfUpgrade;
import com.shatteredpixel.shatteredpixeldungeon.items.stones.StoneOfAugmentation;
import com.shatteredpixel.shatteredpixeldungeon.items.spells.Alchemize;
import com.shatteredpixel.shatteredpixeldungeon.items.wands.Wand;
import com.shatteredpixel.shatteredpixeldungeon.items.weapon.melee.MeleeWeapon;
import com.shatteredpixel.shatteredpixeldungeon.items.weapon.missiles.MissileWeapon;
import com.shatteredpixel.shatteredpixeldungeon.journal.Notes;
import com.shatteredpixel.shatteredpixeldungeon.messages.Messages;
import com.shatteredpixel.shatteredpixeldungeon.scenes.GameScene;
import com.shatteredpixel.shatteredpixeldungeon.scenes.PixelScene;
import com.shatteredpixel.shatteredpixeldungeon.sprites.ItemSprite;
import com.shatteredpixel.shatteredpixeldungeon.sprites.ShopkeeperSprite;
import com.shatteredpixel.shatteredpixeldungeon.ui.CurrencyIndicator;
import com.shatteredpixel.shatteredpixeldungeon.utils.GLog;
import com.shatteredpixel.shatteredpixeldungeon.windows.WndBag;
import com.shatteredpixel.shatteredpixeldungeon.windows.WndOptions;
import com.shatteredpixel.shatteredpixeldungeon.windows.WndTitledMessage;
import com.shatteredpixel.shatteredpixeldungeon.windows.WndSpawner;
import com.shatteredpixel.shatteredpixeldungeon.windows.WndTradeItem;
import com.watabou.noosa.Game;
import com.watabou.noosa.Image;
import com.watabou.utils.BArray;
import com.watabou.utils.Bundlable;
import com.watabou.utils.Bundle;
import com.watabou.utils.Callback;
import com.watabou.utils.PathFinder;
import java.util.ArrayList;

public class Shopkeeper
extends NPC {
    public static int MAX_BUYBACK_HISTORY = 3;
    public ArrayList<Item> buybackItems;
    private int turnsSinceHarmed;

    // ===================== MOD: 看人下菜 —— 抵押换购 =====================
    /** 被抵押的物品（力量药水 / 升级卷轴） */
    private Item pawnedItem;
    /** 赎回所需金币 = floor(免费带走商品的价值 * 1.5) */
    private int pawnDebt;
    public static String PAWNED_ITEM = "pawned_item";
    public static String PAWN_DEBT = "pawn_debt";
    private static WndBag.ItemSelector itemSelector = new WndBag.ItemSelector(){

        @Override
        public String textPrompt() {
            return Messages.get(Shopkeeper.class, "sell", new Object[0]);
        }

        @Override
        public boolean itemSelectable(Item item) {
            return Shopkeeper.canSell(item);
        }

        @Override
        public void onSelect(Item item) {
            if (item != null && Dungeon.hero != null && Dungeon.hero.isAlive()) {
                WndBag parentWnd = Shopkeeper.sell();
                GameScene.show(new WndTradeItem(item, parentWnd));
            }
        }
    };
    public static String BUYBACK_ITEMS = "buyback_items";
    public static String TURNS_SINCE_HARMED = "turns_since_harmed";

    public Shopkeeper() {
        this.spriteClass = ShopkeeperSprite.class;
        this.properties.add(Char.Property.IMMOVABLE);
        this.buybackItems = new ArrayList();
        this.turnsSinceHarmed = -1;
    }

    @Override
    public Notes.Landmark landmark() {
        return Notes.Landmark.SHOP;
    }

    @Override
    protected boolean act() {
        if (this.turnsSinceHarmed >= 0) {
            ++this.turnsSinceHarmed;
        }
        this.sprite.turnTo(this.pos, Dungeon.hero.pos);
        this.spend(1.0f);
        return super.act();
    }

    @Override
    public void damage(int dmg, Object src) {
        this.processHarm();
    }

    @Override
    public boolean add(Buff buff) {
        if (buff.type == Buff.buffType.NEGATIVE) {
            this.processHarm();
        }
        return false;
    }

    public void processHarm() {
        if (!Dungeon.level.heroFOV[this.pos]) {
            return;
        }
        if (this.turnsSinceHarmed == -1) {
            this.turnsSinceHarmed = 0;
            this.yell(Messages.get(this, "warn", new Object[0]));
            Actor.add(new Actor(){
                {
                    this.actPriority = 100;
                }

                @Override
                protected boolean act() {
                    ArrayList<Blob> blobs = new ArrayList<Blob>();
                    for (Class c : new BlobImmunity().immunities()) {
                        Blob b = Dungeon.level.blobs.get(c);
                        if (b == null || b.volume <= 0) continue;
                        blobs.add(b);
                    }
                    PathFinder.buildDistanceMap(Shopkeeper.this.pos, BArray.not(Dungeon.level.solid, null), 4);
                    for (int i = 0; i < Dungeon.level.length(); ++i) {
                        if (PathFinder.distance[i] >= Integer.MAX_VALUE) continue;
                        boolean affected = false;
                        for (Blob blob : blobs) {
                            if (blob.cur[i] <= 0) continue;
                            blob.clear(i);
                            affected = true;
                        }
                        if (!affected || !Dungeon.level.heroFOV[i]) continue;
                        CellEmitter.get(i).burst(Speck.factory(101), 2);
                    }
                    Actor.remove(this);
                    return true;
                }
            });
        } else if (this.turnsSinceHarmed >= 1) {
            this.flee();
        }
    }

    public void flee() {
        this.destroy();
        Notes.remove(this.landmark());
        GLog.newLine();
        GLog.n(Messages.get(this, "flee", new Object[0]), new Object[0]);
        if (this.sprite != null) {
            this.sprite.killAndErase();
            CellEmitter.get(this.pos).burst(ElmoParticle.FACTORY, 6);
        }
    }

    @Override
    public void destroy() {
        super.destroy();
        for (Heap heap : Dungeon.level.heaps.valueList()) {
            if (heap.type != Heap.Type.FOR_SALE) continue;
            if (ShatteredPixelDungeon.scene() instanceof GameScene) {
                CellEmitter.get(heap.pos).burst(ElmoParticle.FACTORY, 4);
            }
            if (heap.size() == 1) {
                heap.destroy();
                continue;
            }
            heap.items.remove(heap.size() - 1);
            heap.type = Heap.Type.HEAP;
        }
    }

    @Override
    public boolean reset() {
        return true;
    }

    public static int sellPrice(Item item) {
        int base = item.value() * 5 * (Dungeon.depth / 5 + 1);
        return pricedUp(base);
    }

    /** MOD: 「看人下菜」—— 金币越多，售价越高（每超出 300 金币加价 5%，结果向下取整）。 */
    public static int pricedUp(int base) {
        if (!com.shatteredpixel.shatteredpixeldungeon.ModContent.enabled()
                || !Dungeon.isChallenged(Challenges.PRICE_GOUGING)) {
            return base;
        }
        int gold = Dungeon.gold;
        if (gold <= 1000) {
            return base;
        }
        int steps = (gold - 1000) / 300;      // 每超出 300 金币算一档
        // 用整数运算避免浮点误差（base*1.15 在 double 下可能略小于整数，floor 会少 1）
        return base + base * steps * 5 / 100;
    }

    public static WndBag sell() {
        return GameScene.selectItem(itemSelector);
    }

    public static boolean canSell(Item item) {
        if (item.value() <= 0) {
            return false;
        }
        if (item.unique && !item.stackable) {
            return false;
        }
        if (item instanceof Armor && ((Armor)item).checkSeal() != null) {
            return false;
        }
        return !item.isEquipped(Dungeon.hero) || !item.cursed;
    }

    @Override
    public boolean interact(Char c) {
        if (c != Dungeon.hero) {
            return true;
        }
        Game.runOnRenderThread(new Callback(){

            @Override
            public void call() {
                String[] options = new String[2 + Shopkeeper.this.buybackItems.size() + 2];
                int maxLen = PixelScene.landscape() ? 30 : 25;
                int i = 0;
                options[i++] = Messages.get(Shopkeeper.this, "sell", new Object[0]);
                options[i++] = Messages.get(Shopkeeper.this, "talk", new Object[0]);
                for (Item item : Shopkeeper.this.buybackItems) {
                    options[i] = Messages.get(Heap.class, "for_sale", item.value(), Messages.titleCase(item.title()));
                    if (options[i].length() > maxLen) {
                        options[i] = options[i].substring(0, maxLen - 3) + "...";
                    }
                    ++i;
                }
                final int idxPledge = 2 + Shopkeeper.this.buybackItems.size();
                final int idxRedeem = idxPledge + 1;
                options[idxPledge] = "抵押换购";
                options[idxRedeem] = Shopkeeper.this.pawnedItem == null
                        ? "赎回抵押品（暂无）"
                        : ("赎回抵押品（" + Shopkeeper.this.pawnDebt + " 金币）");
                CurrencyIndicator.showGold = true;
                GameScene.show(new WndOptions(Shopkeeper.this.sprite(), Messages.titleCase(Shopkeeper.this.name()), Shopkeeper.this.description(), options){

                    @Override
                    protected void onSelect(int index) {
                        super.onSelect(index);
                        if (index == 0) {
                            Shopkeeper.sell();
                        } else if (index == 1) {
                            GameScene.show(new WndTitledMessage(Shopkeeper.this.sprite(), Messages.titleCase(Shopkeeper.this.name()), Shopkeeper.this.chatText()));
                        } else if (index >= 2 && index < idxPledge) {
                            GLog.i(Messages.get(Shopkeeper.this, "buyback", new Object[0]), new Object[0]);
                            Item returned = Shopkeeper.this.buybackItems.remove(index - 2);
                            Dungeon.gold -= returned.value();
                            Statistics.goldCollected -= returned.value();
                            if (returned instanceof MissileWeapon && returned.isUpgradable()) {
                                Buff.affect((Char)Dungeon.hero, MissileWeapon.UpgradedSetTracker.class).levelThresholds.put(((MissileWeapon)returned).setID, returned.level());
                            }
                            if (!returned.doPickUp(Dungeon.hero)) {
                                Dungeon.level.drop(returned, Dungeon.hero.pos);
                            }
                        } else if (index == idxPledge) {
                            Shopkeeper.this.startPledge();
                        } else if (index == idxRedeem) {
                            Shopkeeper.this.redeem();
                        }
                    }

                    @Override
                    protected boolean enabled(int index) {
                        if (index >= 2 && index < idxPledge) {
                            return Dungeon.gold >= Shopkeeper.this.buybackItems.get(index - 2).value();
                        }
                        if (index == idxPledge) {
                            return Shopkeeper.this.canPledge();
                        }
                        if (index == idxRedeem) {
                            return Shopkeeper.this.pawnedItem != null
                                    && Dungeon.gold >= Shopkeeper.this.pawnDebt;
                        }
                        return super.enabled(index);
                    }

                    @Override
                    protected boolean hasIcon(int index) {
                        return index >= 2 && index < idxPledge;
                    }

                    @Override
                    protected Image getIcon(int index) {
                        if (index >= 2 && index < idxPledge) {
                            return new ItemSprite(Shopkeeper.this.buybackItems.get(index - 2));
                        }
                        return null;
                    }

                    @Override
                    public void hide() {
                        super.hide();
                        CurrencyIndicator.showGold = false;
                    }
                });
            }
        });
        return true;
    }

    public String chatText() {
        if (Dungeon.hero.buff(AscensionChallenge.class) != null) {
            return Messages.get(this, "talk_ascent", new Object[0]);
        }
        switch (Dungeon.depth) {
            default: {
                return Messages.get(this, "talk_prison_intro", new Object[0]) + "\n\n" + Messages.get(this, "talk_prison_" + Dungeon.hero.heroClass.name(), new Object[0]);
            }
            case 11: {
                return Messages.get(this, "talk_caves", new Object[0]);
            }
            case 16: {
                return Messages.get(this, "talk_city", new Object[0]);
            }
            case 20: 
        }
        return Messages.get(this, "talk_halls", new Object[0]);
    }

    // ===================== MOD: 看人下菜 —— 抵押 / 赎回 =====================

    /** 现在能否抵押：挑战开启中、身上没有已抵押物、背包里有已鉴定的力量药水或升级卷轴。 */
    public boolean canPledge() {
        if (!com.shatteredpixel.shatteredpixeldungeon.ModContent.enabled()
                || !Dungeon.isChallenged(Challenges.PRICE_GOUGING)) {
            return false;
        }
        if (this.pawnedItem != null) {
            return false;
        }
        if (Dungeon.hero == null || Dungeon.hero.belongings == null) {
            return false;
        }
        for (Item it : Dungeon.hero.belongings.backpack.items) {
            if (isPledgeable(it)) {
                return true;
            }
        }
        return false;
    }

    private static boolean isPledgeable(Item item) {
        if (item == null || item.quantity() <= 0 || !item.isIdentified()) {
            return false;
        }
        return item instanceof PotionOfStrength || item instanceof ScrollOfUpgrade;
    }

    /** 第一步：选抵押物 */
    public void startPledge() {
        GameScene.selectItem(new WndBag.ItemSelector() {
            @Override
            public String textPrompt() {
                return "选择抵押物（已鉴定的力量药水 / 升级卷轴）";
            }

            @Override
            public boolean itemSelectable(Item item) {
                return isPledgeable(item);
            }

            @Override
            public void onSelect(Item item) {
                if (item == null) {
                    return;
                }
                Shopkeeper.this.choosePledgeGift(item);
            }
        });
    }

    /**
     * 可抵押获得的商品分类：**直接复用刷物品面板的分类体系**（WndSpawner.CAT_NAMES / categoryOf），
     * 这里只是一份"允许抵押的类别"白名单，两边不会再出现分类不一致。
     */
    private static final int[] GIFT_ALLOWED_CATS = {
            0,   // 近战武器
            1,   // 护甲
            2,   // 投掷武器
            3,   // 法杖
            4,   // 戒指
            5,   // 神器
            8,   // 药剂
            9,   // 卷轴
            11,  // 强化符石
            16,  // 炸弹
            20   // 商店专属（十字架 + 三种扩容袋）
    };
    private static final boolean[] GIFT_ALLOWED = new boolean[WndSpawner.CAT_NAMES.length];

    static {
        for (int c : GIFT_ALLOWED_CATS) {
            GIFT_ALLOWED[c] = true;
        }
    }

    /** 返回商品所属分类下标；不在允许范围内返回 -1。 */
    private static int giftCategory(Item item) {
        if (item == null) {
            return -1;
        }
        // 明确排除：小包口粮、炼金菱晶
        if (item instanceof SmallRation || item instanceof Alchemize) {
            return -1;
        }
        int c = WndSpawner.categoryOf(item.getClass());
        if (c < 0 || c >= GIFT_ALLOWED.length || !GIFT_ALLOWED[c]) {
            return -1;
        }
        return c;
    }

    /** 第二步：先选分类，再选该分类下的一件商品，免费带走。 */
    private void choosePledgeGift(final Item pledgeItem) {
        final ArrayList<Heap>[] byCat = new ArrayList[WndSpawner.CAT_NAMES.length];
        for (Heap h : Dungeon.level.heaps.valueList()) {
            if (h.type != Heap.Type.FOR_SALE || h.isEmpty()) {
                continue;
            }
            int c = giftCategory(h.peek());
            if (c < 0) {
                continue;
            }
            if (byCat[c] == null) {
                byCat[c] = new ArrayList<>();
            }
            byCat[c].add(h);
        }

        final ArrayList<Integer> cats = new ArrayList<>();
        for (int c = 0; c < WndSpawner.CAT_NAMES.length; c++) {
            if (byCat[c] != null && !byCat[c].isEmpty()) {
                cats.add(c);
            }
        }
        if (cats.isEmpty()) {
            GLog.w("商店里没有可以免费带走的商品。");
            return;
        }

        String[] catOpts = new String[cats.size()];
        for (int i = 0; i < cats.size(); i++) {
            int c = cats.get(i);
            catOpts[i] = WndSpawner.CAT_NAMES[c] + "（" + byCat[c].size() + " 件）";
        }

        GameScene.show(new WndOptions("抵押换购 · 选择分类", "先选择要带走的商品分类：", catOpts) {
            @Override
            protected void onSelect(int index) {
                super.onSelect(index);
                chooseGiftInCategory(pledgeItem, byCat[cats.get(index)]);
            }
        });
    }

    private void chooseGiftInCategory(final Item pledgeItem, final ArrayList<Heap> heaps) {
        String[] opts = new String[heaps.size()];
        for (int i = 0; i < heaps.size(); i++) {
            Item it = heaps.get(i).peek();
            opts[i] = it.title() + "（售价 " + Shopkeeper.sellPrice(it) + "）";
        }
        GameScene.show(new WndOptions("抵押换购 · 选择商品", "选择要免费带走的一件商品：", opts) {
            @Override
            protected void onSelect(int index) {
                super.onSelect(index);
                completePledge(pledgeItem, heaps.get(index));
            }
        });
    }

    /** 执行抵押：抵押物入库到商人、商品免费入包、记下赎回价 = floor(价值 * 1.5)。 */
    private void completePledge(final Item pledgeItem, Heap heap) {
        Item taken = heap.pickUp();
        if (taken == null) {
            return;
        }

        Item pawnedOne;
        if (pledgeItem.quantity() > 1) {
            Item split = pledgeItem.split(1);
            if (split == null) {
                pledgeItem.quantity(pledgeItem.quantity() - 1);
                split = pledgeItem;
            }
            pawnedOne = split;
        } else {
            pledgeItem.detachAll(Dungeon.hero.belongings.backpack);
            pawnedOne = pledgeItem;
        }

        this.pawnedItem = pawnedOne;
        // 用商店售价（而不是 Item.value() 这种基础价值）的 150% 作为赎回价
        this.pawnDebt = (int) Math.floor(Shopkeeper.sellPrice(taken) * 1.5);

        if (!taken.doPickUp(Dungeon.hero)) {
            Dungeon.level.drop(taken, Dungeon.hero.pos);
        }
        // 用 pawnedOne（数量 1）而不是原堆叠，避免提示里显示全部数量
        GLog.p("已抵押「" + pawnedOne.title() + "」，赎回需 " + this.pawnDebt + " 金币。");
    }

    /** 用金币赎回抵押物 */
    public void redeem() {
        if (this.pawnedItem == null) {
            return;
        }
        if (Dungeon.gold < this.pawnDebt) {
            GLog.w("金币不足，赎回需要 " + this.pawnDebt + " 金币。");
            return;
        }
        Dungeon.gold -= this.pawnDebt;
        Statistics.goldCollected -= this.pawnDebt;

        Item item = this.pawnedItem;
        this.pawnedItem = null;
        this.pawnDebt = 0;
        if (!item.doPickUp(Dungeon.hero)) {
            Dungeon.level.drop(item, Dungeon.hero.pos);
        }
        GLog.p("已赎回抵押品：" + item.title());
    }

    @Override
    public void storeInBundle(Bundle bundle) {
        super.storeInBundle(bundle);
        bundle.put(BUYBACK_ITEMS, this.buybackItems);
        bundle.put(TURNS_SINCE_HARMED, this.turnsSinceHarmed);
        if (this.pawnedItem != null) {
            bundle.put(PAWNED_ITEM, this.pawnedItem);
        }
        bundle.put(PAWN_DEBT, this.pawnDebt);
    }

    @Override
    public void restoreFromBundle(Bundle bundle) {
        super.restoreFromBundle(bundle);
        this.buybackItems.clear();
        if (bundle.contains(BUYBACK_ITEMS)) {
            for (Bundlable i : bundle.getCollection(BUYBACK_ITEMS)) {
                this.buybackItems.add((Item)i);
            }
        }
        this.turnsSinceHarmed = bundle.contains(TURNS_SINCE_HARMED) ? bundle.getInt(TURNS_SINCE_HARMED) : -1;
        this.pawnedItem = bundle.contains(PAWNED_ITEM) ? (Item) bundle.get(PAWNED_ITEM) : null;
        this.pawnDebt = bundle.contains(PAWN_DEBT) ? bundle.getInt(PAWN_DEBT) : 0;
    }
}
