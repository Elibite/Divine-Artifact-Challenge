package com.shatteredpixel.shatteredpixeldungeon.items.trinkets;

import com.shatteredpixel.shatteredpixeldungeon.messages.Messages;
import com.shatteredpixel.shatteredpixeldungeon.sprites.ItemSpriteSheet;
import com.shatteredpixel.shatteredpixeldungeon.utils.GLog;

import java.util.Calendar;
import java.util.GregorianCalendar;

/**
 * MOD: 原版 {@code DimensionalSundial} 的整类覆盖。
 *
 * <p>与 4.0.2 的差别只有一处：额外等级（4~6）**不再继续抬高夜间生成倍率**
 * （锁在 3 级的 ×2.0），改为在夜间给掉落加成——
 * 「危险兑现」：夜里依旧危险，但你从危险里拿得更多。</p>
 */
public class DimensionalSundial extends Trinket {

    public static boolean sundialWarned = false;

    public DimensionalSundial() {
        this.image = ItemSpriteSheet.SUNDIAL;
    }

    @Override
    protected int upgradeEnergyCost() {
        return 6 + 2 * this.level();
    }

    @Override
    public String statsDesc() {
        if (this.isIdentified()) {
            return Messages.get(this, "stats_desc",
                    (int) (100.0f * (1.0f - enemySpawnMultiplierDaytime(this.buffedLvl()))),
                    (int) (100.0f * (enemySpawnMultiplierNighttime(this.buffedLvl()) - 1.0f)));
        }
        return Messages.get(this, "typical_stats_desc",
                (int) (100.0f * (1.0f - enemySpawnMultiplierDaytime(0))),
                (int) (100.0f * (enemySpawnMultiplierNighttime(0) - 1.0f)));
    }

    public static float spawnMultiplierAtCurrentTime() {
        if (trinketLevel(DimensionalSundial.class) != -1) {
            // MOD: 本层已经校准成白昼
            if (com.shatteredpixel.shatteredpixeldungeon.actors.buffs.SundialCalibration.calibratedNow()) {
                return enemySpawnMultiplierDaytime();
            }
            Calendar cal = GregorianCalendar.getInstance();
            if (cal.get(Calendar.HOUR_OF_DAY) >= 20 || cal.get(Calendar.HOUR_OF_DAY) <= 7) {
                if (!sundialWarned) {
                    GLog.w(Messages.get(DimensionalSundial.class, "warning", new Object[0]), new Object[0]);
                    sundialWarned = true;
                }
                return enemySpawnMultiplierNighttime();
            }
            return enemySpawnMultiplierDaytime();
        }
        return 1.0f;
    }

    public static float enemySpawnMultiplierDaytime() {
        return enemySpawnMultiplierDaytime(trinketLevel(DimensionalSundial.class));
    }

    public static float enemySpawnMultiplierDaytime(int level) {
        if (level == -1) {
            return 1.0f;
        }
        return 0.95f - 0.05f * (float) level;
    }

    public static float enemySpawnMultiplierNighttime() {
        return enemySpawnMultiplierNighttime(trinketLevel(DimensionalSundial.class));
    }

    public static float enemySpawnMultiplierNighttime(int level) {
        if (level == -1) {
            return 1.0f;
        }
        // MOD: 额外等级不再继续加危险，锁在 3 级的 ×2.0
        int tier = Math.min(level, 3);
        return 1.25f + 0.25f * (float) tier;
    }
}
