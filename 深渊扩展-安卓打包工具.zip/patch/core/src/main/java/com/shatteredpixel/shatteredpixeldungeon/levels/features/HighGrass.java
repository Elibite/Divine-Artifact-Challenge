package com.shatteredpixel.shatteredpixeldungeon.levels.features;

import com.shatteredpixel.shatteredpixeldungeon.Dungeon;
import com.shatteredpixel.shatteredpixeldungeon.ShatteredPixelDungeon;
import com.shatteredpixel.shatteredpixeldungeon.actors.Actor;
import com.shatteredpixel.shatteredpixeldungeon.actors.Char;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.Barkskin;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.Buff;
import com.shatteredpixel.shatteredpixeldungeon.actors.hero.Hero;
import com.shatteredpixel.shatteredpixeldungeon.actors.hero.HeroClass;
import com.shatteredpixel.shatteredpixeldungeon.actors.hero.Talent;
import com.shatteredpixel.shatteredpixeldungeon.actors.mobs.npcs.Blacksmith;
import com.shatteredpixel.shatteredpixeldungeon.effects.CellEmitter;
import com.shatteredpixel.shatteredpixeldungeon.effects.particles.LeafParticle;
import com.shatteredpixel.shatteredpixeldungeon.items.Dewdrop;
import com.shatteredpixel.shatteredpixeldungeon.items.Generator;
import com.shatteredpixel.shatteredpixeldungeon.items.Item;
import com.shatteredpixel.shatteredpixeldungeon.items.armor.glyphs.Camouflage;
import com.shatteredpixel.shatteredpixeldungeon.items.artifacts.SandalsOfNature;
import com.shatteredpixel.shatteredpixeldungeon.items.food.Berry;
import com.shatteredpixel.shatteredpixeldungeon.items.trinkets.PetrifiedSeed;
import com.shatteredpixel.shatteredpixeldungeon.items.trinkets.TrinketPerks;
import com.shatteredpixel.shatteredpixeldungeon.levels.Level;
import com.shatteredpixel.shatteredpixeldungeon.levels.MiningLevel;
import com.shatteredpixel.shatteredpixeldungeon.levels.VaultLevel;
import com.shatteredpixel.shatteredpixeldungeon.scenes.GameScene;
import com.watabou.utils.Random;

/**
 * MOD: 原版 {@code HighGrass} 的整类覆盖。
 *
 * 与 4.0.2 的差别只有两处，都服务于「强化石化种子」：
 * <ul>
 *   <li>种子/符石掉率额外 ×1.25（+25%）；</li>
 *   <li>如果种子里封存了指定的符石/种子，接下来三次踩草必掉它（替代原来的随机掉落）。</li>
 * </ul>
 */
public class HighGrass {

    private static boolean freezeTrample = false;

    public static void trample(Level level, int pos) {
        if (freezeTrample) {
            return;
        }
        Char ch = Actor.findChar(pos);
        if (level.map[pos] == 30) {
            if (ch instanceof Hero && ((Hero) ch).heroClass == HeroClass.HUNTRESS) {
                freezeTrample = true;
            } else {
                Level.set(pos, 2);
            }
        } else {
            if (ch instanceof Hero && ((Hero) ch).heroClass == HeroClass.HUNTRESS) {
                if (((Hero) ch).hasTalent(Talent.BARKSKIN)) {
                    Barkskin.conditionallyAppend(ch,
                            ((Hero) ch).lvl * ((Hero) ch).pointsInTalent(Talent.BARKSKIN) / 3, 1);
                }
                Level.set(pos, 30);
                freezeTrample = true;
            } else {
                Level.set(pos, 2);
            }

            // MOD: 苔藓丛簇（强化）—— 踩过未枯萎的高草，脚下生风
            if (ch instanceof Hero) {
                TrinketPerks.onTrampleGrass();
            }

            int naturalismLevel = 0;
            if (ch != null) {
                SandalsOfNature.Naturalism naturalism = ch.buff(SandalsOfNature.Naturalism.class);
                if (naturalism != null) {
                    if (!naturalism.isCursed()) {
                        naturalismLevel = naturalism.itemLevel() + 1;
                        naturalism.charge();
                    } else {
                        naturalismLevel = -1;
                    }
                }
                if (ch instanceof Hero && ((Hero) ch).hasTalent(Talent.NATURES_BOUNTY)) {
                    int berriesAvailable = 2 + 2 * ((Hero) ch).pointsInTalent(Talent.NATURES_BOUNTY);
                    Talent.NatureBerriesDropped dropped
                            = Buff.affect(ch, Talent.NatureBerriesDropped.class);
                    berriesAvailable = (int) (berriesAvailable - dropped.count());
                    if (berriesAvailable > 0) {
                        int targetFloor = 2 + 2 * ((Hero) ch).pointsInTalent(Talent.NATURES_BOUNTY);
                        int n = (targetFloor -= berriesAvailable) >= 5 ? 3 : 2;
                        boolean droppingBerry;
                        if (Dungeon.depth > (targetFloor += n)) {
                            droppingBerry = Random.Int(10) == 0;
                        } else if (Dungeon.depth == targetFloor) {
                            droppingBerry = Random.Int(30) == 0;
                        } else {
                            droppingBerry = Random.Int(90) == 0;
                        }
                        if (droppingBerry) {
                            dropped.countUp(1.0f);
                            level.drop(new Berry(), pos).sprite.drop();
                        }
                    }
                }
            }

            if (Dungeon.level instanceof MiningLevel && Blacksmith.Quest.Type() == 3
                    && Random.Int(3) != 0) {
                naturalismLevel = -1;
            }

            if (naturalismLevel >= 0) {
                float lootChance = 1.0f / (25.0f - naturalismLevel * 4.0f);
                lootChance *= PetrifiedSeed.grassLootMultiplier();
                // MOD: 强化石化种子 —— 掉率 +25%
                lootChance *= TrinketPerks.grassLootBonus();
                if (Dungeon.level instanceof VaultLevel) {
                    lootChance /= 3.0f;
                }

                // MOD: 强化石化种子 —— 封存了什么就先掉什么（替代原来的随机掉落）
                if (TrinketPerks.hasSealedSeed()) {
                    Item sealed = TrinketPerks.takeSealedSeed();
                    if (sealed != null) {
                        level.drop(sealed, pos).sprite.drop();
                    }
                } else if (Random.Float() < lootChance) {
                    if (Random.Float() < PetrifiedSeed.stoneInsteadOfSeedChance()) {
                        level.drop(Generator.randomUsingDefaults(Generator.Category.STONE), pos)
                                .sprite.drop();
                    } else {
                        level.drop(Generator.random(Generator.Category.SEED), pos).sprite.drop();
                    }
                }

                lootChance = 1.0f / (6.0f - naturalismLevel / 2.0f);
                if (Dungeon.level != null && Dungeon.level.feeling == Level.Feeling.GRASS) {
                    lootChance /= 2.0f;
                }
                if (Random.Float() < lootChance) {
                    level.drop(new Dewdrop(), pos).sprite.drop();
                }
            }

            if (ch != null) {
                Camouflage.activate(ch, ch.glyphLevel(Camouflage.class));
            }
        }

        freezeTrample = false;

        if (ShatteredPixelDungeon.scene() instanceof GameScene) {
            GameScene.updateMap(pos);
            CellEmitter.get(pos).burst(LeafParticle.LEVEL_SPECIFIC, 4);
            if (Dungeon.level.heroFOV[pos]) {
                Dungeon.observe();
            }
        }
    }
}
