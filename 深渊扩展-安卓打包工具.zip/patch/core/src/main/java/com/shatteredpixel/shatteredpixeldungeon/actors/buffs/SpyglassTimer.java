package com.shatteredpixel.shatteredpixeldungeon.actors.buffs;

import com.shatteredpixel.shatteredpixeldungeon.Dungeon;
import com.watabou.utils.Bundle;

/**
 * MOD: 幻象裂镜（强化）的计时器——每 150 回合触发一次「探地」效果。
 * 记在英雄身上，所以读档、换层都不会把计时清零。
 */
public class SpyglassTimer extends Buff {

    public int ticks = 0;

    private static final String TICKS = "ticks";

    {
        type = buffType.NEUTRAL;
        announced = false;
    }

    public static SpyglassTimer get() {
        return Dungeon.hero == null ? null : Dungeon.hero.buff(SpyglassTimer.class);
    }

    public static SpyglassTimer ensure() {
        return Dungeon.hero == null ? null : Buff.affect(Dungeon.hero, SpyglassTimer.class);
    }

    @Override
    public void storeInBundle(Bundle bundle) {
        super.storeInBundle(bundle);
        bundle.put(TICKS, ticks);
    }

    @Override
    public void restoreFromBundle(Bundle bundle) {
        super.restoreFromBundle(bundle);
        ticks = bundle.getInt(TICKS);
    }
}
