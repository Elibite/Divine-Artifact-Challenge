/*
 * MOD: 自然之履暗影区域用的暗影融合。
 * 继承原版 Shadows（保留隐形判定），只是不在状态栏显示倒计时数字。
 */
package com.shatteredpixel.shatteredpixeldungeon.actors.buffs;

public class ShadowZoneBuff extends Shadows {

    @Override
    public String iconTextDisplay() {
        return "";
    }

    @Override
    public String name() {
        return "暗影融合";
    }
}
