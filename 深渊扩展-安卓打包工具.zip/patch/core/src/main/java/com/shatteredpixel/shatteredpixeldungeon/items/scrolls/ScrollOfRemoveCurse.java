/*
 * MOD: 整类覆盖（原版 ScrollOfRemoveCurse）—— 只是为了加一条规则：
 * 神器试炼期间（ArtifactTrial.trialClass 命中）的诅咒**不能被祛邪**，只有完成试炼或离开 BOSS 层才会解开；
 * 开启「测试时间」时不作限制。
 *
 * 其余逻辑与原版一致；uncurse() 是全游戏统一的「解咒」入口，所以挡在这里就够了。
 */
package com.shatteredpixel.shatteredpixeldungeon.items.scrolls;

import com.shatteredpixel.shatteredpixeldungeon.Badges;
import com.shatteredpixel.shatteredpixeldungeon.Dungeon;
import com.shatteredpixel.shatteredpixeldungeon.actors.Actor;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.Degrade;
import com.shatteredpixel.shatteredpixeldungeon.actors.hero.Belongings;
import com.shatteredpixel.shatteredpixeldungeon.actors.hero.Hero;
import com.shatteredpixel.shatteredpixeldungeon.actors.mobs.TormentedSpirit;
import com.shatteredpixel.shatteredpixeldungeon.effects.Flare;
import com.shatteredpixel.shatteredpixeldungeon.effects.particles.ShadowParticle;
import com.shatteredpixel.shatteredpixeldungeon.items.EquipableItem;
import com.shatteredpixel.shatteredpixeldungeon.items.Item;
import com.shatteredpixel.shatteredpixeldungeon.items.armor.Armor;
import com.shatteredpixel.shatteredpixeldungeon.items.artifacts.ArtifactTrial;
import com.shatteredpixel.shatteredpixeldungeon.items.scrolls.InventoryScroll;
import com.shatteredpixel.shatteredpixeldungeon.items.wands.Wand;
import com.shatteredpixel.shatteredpixeldungeon.items.weapon.Weapon;
import com.shatteredpixel.shatteredpixeldungeon.messages.Messages;
import com.shatteredpixel.shatteredpixeldungeon.sprites.ItemSpriteSheet;
import com.shatteredpixel.shatteredpixeldungeon.utils.GLog;
import com.watabou.noosa.audio.Sample;
import com.watabou.utils.PathFinder;

public class ScrollOfRemoveCurse
extends InventoryScroll {
    public ScrollOfRemoveCurse() {
        this.icon = ItemSpriteSheet.Icons.SCROLL_REMCURSE;
        this.preferredBag = Belongings.Backpack.class;
    }

    @Override
    public void doRead() {
        TormentedSpirit spirit = null;
        for (int i : PathFinder.NEIGHBOURS8) {
            if (!(Actor.findChar(ScrollOfRemoveCurse.curUser.pos + i) instanceof TormentedSpirit)) continue;
            spirit = (TormentedSpirit)Actor.findChar(ScrollOfRemoveCurse.curUser.pos + i);
        }
        if (spirit != null) {
            this.identify();
            Sample.INSTANCE.play("sounds/read.mp3");
            this.readAnimation();
            new Flare(6, 32.0f).show(ScrollOfRemoveCurse.curUser.sprite, 2.0f);
            if (curUser.buff(Degrade.class) != null) {
                Degrade.detach(curUser, Degrade.class);
            }
            this.detach(ScrollOfRemoveCurse.curUser.belongings.backpack);
            GLog.p(Messages.get(this, "spirit", new Object[0]), new Object[0]);
            spirit.cleanse();
        } else {
            super.doRead();
        }
    }

    @Override
    protected boolean usableOnItem(Item item) {
        return ScrollOfRemoveCurse.uncursable(item);
    }

    public static boolean uncursable(Item item) {
        if (item.isEquipped(Dungeon.hero) && Dungeon.hero.buff(Degrade.class) != null) {
            return true;
        }
        if ((item instanceof EquipableItem || item instanceof Wand) && (!item.isIdentified() && !item.cursedKnown || item.cursed)) {
            return true;
        }
        if (item instanceof Weapon) {
            return ((Weapon)item).hasCurseEnchant();
        }
        if (item instanceof Armor) {
            return ((Armor)item).hasCurseGlyph();
        }
        return false;
    }

    @Override
    protected void onItemSelected(Item item) {
        new Flare(6, 32.0f).show(ScrollOfRemoveCurse.curUser.sprite, 2.0f);
        boolean procced = ScrollOfRemoveCurse.uncurse(curUser, item);
        if (curUser.buff(Degrade.class) != null) {
            Degrade.detach(curUser, Degrade.class);
            procced = true;
        }
        if (procced) {
            GLog.p(Messages.get(this, "cleansed", new Object[0]), new Object[0]);
        } else {
            GLog.i(Messages.get(this, "not_cleansed", new Object[0]), new Object[0]);
        }
    }

    public static boolean uncurse(Hero hero, Item ... items) {
        boolean procced = false;
        for (Item item : items) {
            Armor a;
            Weapon w;
            if (item != null) {
                item.cursedKnown = true;
                if (item.cursed) {
                    // ===== MOD: 神器试炼期间的诅咒祛不掉（「测试时间」下不受此限制） =====
                    if (ArtifactTrial.isTrialing(item)) {
                        GLog.w("诅咒死死缠着「" + item.trueName() + "」——祛邪毫无作用。只有试炼本身能解开它。");
                        continue;
                    }
                    // ===== MOD end =====
                    procced = true;
                    item.cursed = false;
                }
            }
            if (item instanceof Weapon && (w = (Weapon)item).hasCurseEnchant()) {
                w.enchant(null);
                procced = true;
            }
            if (item instanceof Armor && (a = (Armor)item).hasCurseGlyph()) {
                a.inscribe(null);
                procced = true;
            }
            if (!(item instanceof Wand)) continue;
            ((Wand)item).updateLevel();
        }
        if (procced) {
            if (hero != null) {
                hero.sprite.emitter().start(ShadowParticle.UP, 0.05f, 10);
                hero.updateHT(false);
                ScrollOfRemoveCurse.updateQuickslot();
            }
            Badges.validateClericUnlock();
        }
        return procced;
    }

    @Override
    public int value() {
        return this.isKnown() ? 30 * this.quantity : super.value();
    }
}
