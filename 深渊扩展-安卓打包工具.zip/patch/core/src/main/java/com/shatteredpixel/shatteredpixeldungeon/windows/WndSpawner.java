/*
 * MOD: 测试模式刷物品面板
 *
 * 三层导航：装备/消耗品 -> 细分类(带图标,武器/护甲按阶数排序) -> 物品列表
 * 可设定：获取数量、装备等级、附魔(不附魔/随机/指定)；指定时可在「附魔」与「诅咒」之间切换
 *
 * 设计要点
 * - 清单来源：扫描游戏 jar 里 items/ 与 plants/ 下所有非抽象 Item 子类（298 件）
 * - 分类按 Class 判定，不依赖实例化
 * - 显示名用 Item.trueName()，未鉴定的药水/卷轴也能显示真实中文名
 * - 分类按钮左侧图标 = 该分类中第一个物品的 ItemSprite
 * - 武器/护甲/投掷物按 tier 升序，再按名称排序
 */
package com.shatteredpixel.shatteredpixeldungeon.windows;

import com.shatteredpixel.shatteredpixeldungeon.Dungeon;
import com.shatteredpixel.shatteredpixeldungeon.actors.Actor;
import com.shatteredpixel.shatteredpixeldungeon.actors.Char;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.Buff;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.ChampionEnemy;
import com.shatteredpixel.shatteredpixeldungeon.actors.hero.Hero;
import com.shatteredpixel.shatteredpixeldungeon.actors.mobs.Mob;
import com.shatteredpixel.shatteredpixeldungeon.items.ArcaneResin;
import com.shatteredpixel.shatteredpixeldungeon.items.EquipableItem;
import com.shatteredpixel.shatteredpixeldungeon.items.Item;
import com.shatteredpixel.shatteredpixeldungeon.items.KindOfWeapon;
import com.shatteredpixel.shatteredpixeldungeon.items.KindofMisc;
import com.shatteredpixel.shatteredpixeldungeon.items.armor.Armor;
import com.shatteredpixel.shatteredpixeldungeon.items.artifacts.Artifact;
import com.shatteredpixel.shatteredpixeldungeon.items.bombs.Bomb;
import com.shatteredpixel.shatteredpixeldungeon.items.food.Food;
import com.shatteredpixel.shatteredpixeldungeon.items.potions.Potion;
import com.shatteredpixel.shatteredpixeldungeon.items.potions.brews.Brew;
import com.shatteredpixel.shatteredpixeldungeon.items.potions.elixirs.Elixir;
import com.shatteredpixel.shatteredpixeldungeon.items.potions.exotic.ExoticPotion;
import com.shatteredpixel.shatteredpixeldungeon.items.rings.Ring;
import com.shatteredpixel.shatteredpixeldungeon.items.scrolls.Scroll;
import com.shatteredpixel.shatteredpixeldungeon.items.scrolls.exotic.ExoticScroll;
import com.shatteredpixel.shatteredpixeldungeon.items.spells.Spell;
import com.shatteredpixel.shatteredpixeldungeon.items.stones.Runestone;
import com.shatteredpixel.shatteredpixeldungeon.items.trinkets.Trinket;
import com.shatteredpixel.shatteredpixeldungeon.items.wands.Wand;
import com.shatteredpixel.shatteredpixeldungeon.items.weapon.Weapon;
import com.shatteredpixel.shatteredpixeldungeon.items.weapon.melee.MeleeWeapon;
import com.shatteredpixel.shatteredpixeldungeon.items.weapon.missiles.MissileWeapon;
import com.shatteredpixel.shatteredpixeldungeon.items.weapon.missiles.darts.Dart;
import com.shatteredpixel.shatteredpixeldungeon.messages.Messages;
import com.shatteredpixel.shatteredpixeldungeon.plants.Plant;
import com.shatteredpixel.shatteredpixeldungeon.scenes.GameScene;
import com.shatteredpixel.shatteredpixeldungeon.scenes.PixelScene;
import com.shatteredpixel.shatteredpixeldungeon.sprites.ItemSprite;
import com.shatteredpixel.shatteredpixeldungeon.ui.IconButton;
import com.shatteredpixel.shatteredpixeldungeon.ui.Icons;
import com.shatteredpixel.shatteredpixeldungeon.ui.RedButton;
import com.shatteredpixel.shatteredpixeldungeon.ui.RenderedTextBlock;
import com.shatteredpixel.shatteredpixeldungeon.ui.ScrollPane;
import com.shatteredpixel.shatteredpixeldungeon.ui.Window;
import com.shatteredpixel.shatteredpixeldungeon.utils.GLog;
import com.watabou.noosa.ColorBlock;
import com.watabou.input.PointerEvent;
import com.watabou.input.ScrollEvent;
import com.watabou.noosa.ui.Component;
import com.watabou.utils.PointF;
import com.watabou.noosa.Image;
import com.watabou.noosa.ScrollArea;
import com.watabou.noosa.Visual;

import java.io.File;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

public class WndSpawner extends Window {

    // ---------------- 分类 ----------------
    public static final String[] GROUP_NAMES = {"装备", "消耗品"};

    // 装备（含「商店专属」）
    private static final int CAT_MELEE = 0;
    private static final int CAT_ARMOR = 1;
    private static final int CAT_MISSILE = 2;
    private static final int CAT_WAND = 3;
    private static final int CAT_RING = 4;
    private static final int CAT_ARTIFACT = 5;
    private static final int CAT_TRINKET = 6;
    private static final int CAT_MISC_EQUIP = 7;
    private static final int CAT_SHOP = 8;
    // 消耗品
    private static final int CAT_POTION = 9;
    private static final int CAT_SCROLL = 10;
    private static final int CAT_SEED = 11;
    private static final int CAT_AUG_STONE = 12;
    private static final int CAT_RUNESTONE = 13;
    private static final int CAT_FOOD = 14;
    private static final int CAT_BREW = 15;
    private static final int CAT_EXOTIC_SCROLL = 16;
    private static final int CAT_BOMB = 17;
    private static final int CAT_DART = 18;
    private static final int CAT_EXOTIC_POTION = 19;
    private static final int CAT_SPELL = 20;
    private static final int CAT_RELIC = 21;
    private static final int CAT_KEY = 22;
    private static final int CAT_QUEST = 23;
    private static final int CAT_MISC_CONSUMABLE = 24;

    public static final String[] CAT_NAMES = {
            // 0-8 装备（「商店专属」在装备大类里）
            "近战武器", "护甲", "投掷武器", "法杖", "戒指", "神器", "饰品", "杂项装备", "商店专属",
            // 9-24 消耗品
            "药剂", "卷轴", "种子", "强化符石", "符石", "食物", "合剂", "秘卷",
            "炸弹", "涂药飞镖", "魔药与秘药", "法术结晶",
            "英雄遗物", "钥匙", "任务道具", "杂项消耗品"
    };
    private static final int CAT_COUNT = CAT_NAMES.length;
    private static final int FIRST_CONSUMABLE = CAT_POTION;

    // ---------------- 选项（静态，跨窗口保留） ----------------
    public static int spawnQty = 1;
    public static int spawnLevel = 0;
    /** 0 = 不附魔, 1 = 随机, 2 = 指定 */
    public static int enchantMode = 0;
    public static Class<?> enchantPick = null;

    private static final int WIDTH_P = 120;
    private static final int WIDTH_L = 144;
    private static final int BTN_HEIGHT = 18;
    private static final int PER_PAGE = 8;
    /** 附魔选择页每页行数：该页头部有 3 行按钮，留给列表的行数要更少 */
    private static final int PICK_PER_PAGE = 8;

    private static final int MODE_ROOT = 0;
    private static final int MODE_CATS = 1;
    private static final int MODE_LIST = 2;
    private static final int MODE_MOB_GROUPS = 3;
    private static final int MODE_MOB_LIST = 4;
    private static final int MODE_MOB_CHAMP = 5;

    private static final Map<Class<?>, String> NAMES = new HashMap<>();
    private static final Map<Class<?>, Integer> TIERS = new HashMap<>();

    private final int mode;
    private final int group;
    private final int cat;
    private final int page;

    public WndSpawner() {
        this(MODE_ROOT, 0, 0, 0);
    }

    private WndSpawner(int mode, int group, int cat, int page) {
        super();
        ensureCatalog();
        this.mode = mode;
        this.group = group;
        this.cat = cat;
        this.page = page;

        if (mode == MODE_ROOT) {
            buildRoot();
        } else if (mode == MODE_MOB_GROUPS) {
            buildMobGroups();
        } else if (mode == MODE_MOB_LIST) {
            buildMobList();
        } else if (mode == MODE_MOB_CHAMP) {
            buildChampPick();
        } else if (mode == MODE_CATS) {
            buildCats();
        } else {
            buildList();
        }
    }

    // ==================================================================
    // 根界面
    // ==================================================================

    private void buildRoot() {
        int width = width();
        float pos = title("测试模式 · 任取物品", width);

        RenderedTextBlock hint = PixelScene.renderTextBlock(6);
        hint.text("共 " + allClasses.size() + " 件物品，分类参照日志。", width);
        hint.setPos(0, pos);
        add(hint);
        pos = hint.bottom() + 4f;

        for (int g = 0; g < GROUP_NAMES.length; g++) {
            final int gg = g;
            int from = g == 0 ? 0 : FIRST_CONSUMABLE;
            int to = g == 0 ? FIRST_CONSUMABLE : CAT_COUNT;
            int total = 0;
            for (int c = from; c < to; c++) {
                total += counts[c];
            }
            RedButton btn = new RedButton(GROUP_NAMES[g] + "（" + total + "）") {
                @Override
                protected void onClick() {
                    hide();
                    GameScene.show(new WndSpawner(MODE_CATS, gg, 0, 0));
                }
            };
            Image icon = iconForCategory(from);
            if (icon != null) {
                btn.icon(icon);
            }
            btn.setRect(0, pos, width, BTN_HEIGHT);
            add(btn);
            pos += BTN_HEIGHT + 2f;
        }

        // MOD: 生物生成
        ensureMobCatalog();
        int mobTotal = mobsByAlign.get(0).size() + mobsByAlign.get(1).size() + mobsByAlign.get(2).size();
        RedButton mobs = new RedButton("生物生成（" + mobTotal + "）") {
            @Override
            protected void onClick() {
                hide();
                GameScene.show(new WndSpawner(MODE_MOB_GROUPS, 0, 0, 0));
            }
        };
        mobs.setRect(0, pos, width, BTN_HEIGHT);
        add(mobs);
        pos += BTN_HEIGHT + 2f;

        addClose(pos, width);
    }

    // ==================================================================
    // 细分类列表
    // ==================================================================

    private void buildCats() {
        int width = width();
        int from = group == 0 ? 0 : FIRST_CONSUMABLE;
        int to = group == 0 ? FIRST_CONSUMABLE : CAT_COUNT;
        int total = to - from;
        final int rows = PER_PAGE;
        int pages = Math.max(1, (total + rows - 1) / rows);
        final int cur = Math.min(Math.max(page, 0), pages - 1);
        float pos = title(GROUP_NAMES[group], width);

        RenderedTextBlock sub = PixelScene.renderTextBlock(6);
        sub.text("共 " + total + " 个分类\n第 " + (cur + 1) + "/" + pages + " 页", width);
        sub.setPos(0, pos);
        add(sub);
        pos = sub.bottom() + 3f;

        int cFrom = from + cur * rows;
        int cTo = Math.min(to, cFrom + rows);
        int shown = 0;
        for (int c = cFrom; c < cTo; c++) {
            final int cc = c;
            RedButton btn = new RedButton(CAT_NAMES[c] + "（" + counts[c] + "）") {
                @Override
                protected void onClick() {
                    hide();
                    GameScene.show(new WndSpawner(MODE_LIST, group, cc, 0));
                }
            };
            Image icon = iconForCategory(c);
            if (icon != null) {
                btn.icon(icon);
            }
            btn.setRect(0, pos, width, BTN_HEIGHT);
            btn.enable(counts[c] > 0);
            add(btn);
            pos += BTN_HEIGHT + 2f;
            shown++;
        }
        pos = reserveRows(pos, shown, rows);

        float half = (width - 2f) / 2f;
        RedButton prev = new RedButton("上一页") {
            @Override
            protected void onClick() {
                hide();
                GameScene.show(new WndSpawner(MODE_CATS, group, 0, Math.max(0, cur - 1)));
            }
        };
        prev.setRect(0, pos, half, BTN_HEIGHT);
        prev.enable(cur > 0);
        add(prev);

        RedButton next = new RedButton("下一页") {
            @Override
            protected void onClick() {
                hide();
                GameScene.show(new WndSpawner(MODE_CATS, group, 0, Math.min(pages - 1, cur + 1)));
            }
        };
        next.setRect(half + 2f, pos, half, BTN_HEIGHT);
        next.enable(cur < pages - 1);
        add(next);
        pos += BTN_HEIGHT + 2f;

        RedButton back = new RedButton("返回") {
            @Override
            protected void onClick() {
                hide();
                GameScene.show(new WndSpawner());
            }
        };
        back.setRect(0, pos, width, BTN_HEIGHT);
        add(back);
        pos += BTN_HEIGHT + 2f;

        RedButton close = new RedButton("关闭") {
            @Override
            protected void onClick() {
                hide();
            }
        };
        close.setRect(0, pos, width, BTN_HEIGHT);
        add(close);
        pos += BTN_HEIGHT + 4f;
        resize(width, (int) pos);
    }

    // ==================================================================
    // 物品列表
    // ==================================================================

    private void buildList() {
        int width = width();
        List<Class<? extends Item>> all = classesIn(cat);
        List<Integer> tiers = tiersOf(all);
        boolean byTier = !tiers.isEmpty();

        final int pages = byTier
                ? tiers.size()
                : Math.max(1, (all.size() + PER_PAGE - 1) / PER_PAGE);
        final int cur = Math.min(Math.max(page, 0), pages - 1);

        List<Class<? extends Item>> shown = new ArrayList<>();
        String heading;
        if (byTier) {
            int t = tiers.get(cur);
            for (Class<? extends Item> k : all) {
                if (tierOf(k) == t) {
                    shown.add(k);
                }
            }
            heading = CAT_NAMES[cat] + " · " + tierLabel(t);
        } else {
            shown.addAll(all);
            heading = CAT_NAMES[cat];
        }

        float pos = title(heading, width);

        String qtyText = cat < FIRST_CONSUMABLE ? "×1（装备固定）" : ("×" + spawnQty);
        String summary = qtyText + "  +" + spawnLevel + "  " + enchantSummary();
        RenderedTextBlock sub = PixelScene.renderTextBlock(6);
        sub.text("第 " + (cur + 1) + "/" + pages + " 页 · " + shown.size() + " 件\n" + summary, width - 20);
        sub.setPos(0, pos);
        add(sub);

        RedButton opts = new RedButton("设置") {
            @Override
            protected void onClick() {
                hide();
                GameScene.show(new Opt(group, cat, cur));
            }
        };
        opts.setRect(width - 19, pos, 19, 16);
        add(opts);
        pos = Math.max(sub.bottom(), opts.bottom()) + 3f;

        int from = byTier ? 0 : cur * PER_PAGE;
        int to = byTier ? shown.size() : Math.min(shown.size(), from + PER_PAGE);
        for (int i = from; i < to; i++) {
            final Class<? extends Item> cls = shown.get(i);
            final String label = nameOf(cls);
            RedButton btn = new RedButton(label) {
                @Override
                protected void onClick() {
                    onItemClicked(cls, label);
                }
            };
            Image icon = iconForClass(cls);
            if (icon != null) {
                btn.icon(icon);
            }
            btn.setRect(0, pos, width, BTN_HEIGHT);
            add(btn);
            pos += BTN_HEIGHT + 2f;
        }
        pos = reserveRows(pos, to - from, PER_PAGE);

        float half = (width - 2f) / 2f;
        RedButton prev = new RedButton("上一页") {
            @Override
            protected void onClick() {
                if (pages <= 1) {
                    return;
                }
                hide();
                GameScene.show(new WndSpawner(MODE_LIST, group, cat, Math.max(0, cur - 1)));
            }
        };
        prev.setRect(0, pos, half, BTN_HEIGHT);
        prev.enable(cur > 0);
        add(prev);

        RedButton next = new RedButton("下一页") {
            @Override
            protected void onClick() {
                if (pages <= 1) {
                    return;
                }
                hide();
                GameScene.show(new WndSpawner(MODE_LIST, group, cat, Math.min(pages - 1, cur + 1)));
            }
        };
        next.setRect(half + 2f, pos, half, BTN_HEIGHT);
        next.enable(cur < pages - 1);
        add(next);
        pos += BTN_HEIGHT + 2f;

        RedButton back = new RedButton("返回分类") {
            @Override
            protected void onClick() {
                hide();
                GameScene.show(new WndSpawner(MODE_CATS, group, 0, 0));
            }
        };
        back.setRect(0, pos, width, BTN_HEIGHT);
        add(back);
        pos += BTN_HEIGHT + 2f;

        addClose(pos, width);
    }

    // ==================================================================
    // MOD: 生物生成
    // ==================================================================

    public static final String[] MOB_GROUP_NAMES = {"盟友", "中立", "敌人"};

    /** 精英效果：0 无 / 1 随机 / 2 指定 */
    public static int champMode = 0;
    public static Class<? extends ChampionEnemy> champPick = null;

    private static final List<Class<? extends ChampionEnemy>> CHAMPIONS = Arrays.asList(
            ChampionEnemy.Blazing.class, ChampionEnemy.Projecting.class,
            ChampionEnemy.AntiMagic.class, ChampionEnemy.Giant.class,
            ChampionEnemy.Blessed.class, ChampionEnemy.Growing.class);

    private static List<List<Class<? extends Mob>>> mobsByAlign = null;
    private static final Map<Class<?>, String> MOB_NAMES = new HashMap<>();

    private static void ensureMobCatalog() {
        if (mobsByAlign != null) {
            return;
        }
        List<List<Class<? extends Mob>>> byAlign = new ArrayList<>();
        for (int i = 0; i < 3; i++) {
            byAlign.add(new ArrayList<>());
        }
        LinkedHashSet<Class<? extends Mob>> set = new LinkedHashSet<>();
        // 注意：Mob 在本 mod 里是被覆盖过的类，它的 code source 指向 spdmod.jar，
        // 只扫它就只能扫到 mod 自己那几只怪。这里把「原版核心 jar」和「mod jar」都扫一遍。
        LinkedHashSet<File> roots = new LinkedHashSet<>();
        for (Class<?> anchor : new Class<?>[]{Dungeon.class, WndSpawner.class, Mob.class}) {
            try {
                File loc = new File(anchor.getProtectionDomain().getCodeSource()
                        .getLocation().toURI());
                if (roots.add(loc)) {
                    // 记下来，后面按文件/目录分别扫描
                }
            } catch (Throwable ignored) {
            }
        }
        for (File loc : roots) {
            if (loc.isDirectory()) {
                scanMobDir(loc, set);
            } else {
                scanMobJar(loc, set);
            }
        }
        for (Class<? extends Mob> k : set) {
            try {
                Mob m = k.getDeclaredConstructor().newInstance();
                String name = m.name();
                if (name == null || name.contains("NO TEXT FOUND")) {
                    continue;
                }
                int g = m.alignment == Char.Alignment.ALLY ? 0
                        : (m.alignment == Char.Alignment.NEUTRAL ? 1 : 2);
                MOB_NAMES.put(k, name);
                byAlign.get(g).add(k);
            } catch (Throwable ignored) {
            }
        }
        for (List<Class<? extends Mob>> l : byAlign) {
            l.sort((a, b) -> mobName(a).compareTo(mobName(b)));
        }
        mobsByAlign = byAlign;
    }

    private static String mobName(Class<? extends Mob> k) {
        String n = MOB_NAMES.get(k);
        return n == null ? k.getSimpleName() : n;
    }

    private static String champName(Class<? extends ChampionEnemy> c) {
        try {
            return Messages.titleCase(c.getDeclaredConstructor().newInstance().name());
        } catch (Throwable t) {
            return c.getSimpleName();
        }
    }

    private static String champSummary() {
        if (champMode == 1) {
            return "随机";
        }
        if (champMode == 2 && champPick != null) {
            return champName(champPick);
        }
        return "无";
    }

    private void buildMobGroups() {
        ensureMobCatalog();
        int width = width();
        float pos = title("生物生成", width);

        RenderedTextBlock hint = PixelScene.renderTextBlock(6);
        hint.text("按阵营挑选，生成在身边。\n当前精英效果：" + champSummary(), width);
        hint.setPos(0, pos);
        add(hint);
        pos = hint.bottom() + 4f;

        for (int g = 0; g < 3; g++) {
            final int gg = g;
            RedButton btn = new RedButton(MOB_GROUP_NAMES[g] + "（" + mobsByAlign.get(g).size() + "）") {
                @Override
                protected void onClick() {
                    hide();
                    GameScene.show(new WndSpawner(MODE_MOB_LIST, gg, 0, 0));
                }
            };
            btn.setRect(0, pos, width, BTN_HEIGHT);
            add(btn);
            pos += BTN_HEIGHT + 2f;
        }

        RedButton champ = new RedButton("精英效果：" + champSummary()) {
            @Override
            protected void onClick() {
                hide();
                GameScene.show(new WndSpawner(MODE_MOB_CHAMP, group, 0, 0));
            }
        };
        champ.setRect(0, pos, width, BTN_HEIGHT);
        add(champ);
        pos += BTN_HEIGHT + 2f;

        RedButton back = new RedButton("返回") {
            @Override
            protected void onClick() {
                hide();
                GameScene.show(new WndSpawner(MODE_ROOT, 0, 0, 0));
            }
        };
        back.setRect(0, pos, width, BTN_HEIGHT);
        add(back);
        pos += BTN_HEIGHT + 2f;

        addClose(pos, width);
    }

    private void buildMobList() {
        ensureMobCatalog();
        int width = width();
        final int g = Math.min(2, Math.max(0, group));
        List<Class<? extends Mob>> all = mobsByAlign.get(g);
        int pages = Math.max(1, (all.size() + PER_PAGE - 1) / PER_PAGE);
        final int cur = Math.min(Math.max(page, 0), pages - 1);

        float pos = title(MOB_GROUP_NAMES[g], width);

        RenderedTextBlock sub = PixelScene.renderTextBlock(6);
        sub.text("第 " + (cur + 1) + "/" + pages + " 页 · " + all.size() + " 种\n"
                + "精英效果：" + champSummary(), width);
        sub.setPos(0, pos);
        add(sub);
        pos = sub.bottom() + 3f;

        int from = cur * PER_PAGE;
        int to = Math.min(all.size(), from + PER_PAGE);
        for (int i = from; i < to; i++) {
            final Class<? extends Mob> cls = all.get(i);
            final String label = mobName(cls);
            RedButton btn = new RedButton(label) {
                @Override
                protected void onClick() {
                    spawnMob(cls, label);
                    hide();
                }
            };
            btn.setRect(0, pos, width, BTN_HEIGHT);
            add(btn);
            pos += BTN_HEIGHT + 2f;
        }
        pos = reserveRows(pos, to - from, PER_PAGE);

        float half = (width - 2f) / 2f;
        RedButton prev = new RedButton("上一页") {
            @Override
            protected void onClick() {
                if (pages <= 1) {
                    return;
                }
                hide();
                GameScene.show(new WndSpawner(MODE_MOB_LIST, g, 0, Math.max(0, cur - 1)));
            }
        };
        prev.setRect(0, pos, half, BTN_HEIGHT);
        prev.enable(cur > 0);
        add(prev);

        RedButton next = new RedButton("下一页") {
            @Override
            protected void onClick() {
                if (pages <= 1) {
                    return;
                }
                hide();
                GameScene.show(new WndSpawner(MODE_MOB_LIST, g, 0, Math.min(pages - 1, cur + 1)));
            }
        };
        next.setRect(half + 2f, pos, half, BTN_HEIGHT);
        next.enable(cur < pages - 1);
        add(next);
        pos += BTN_HEIGHT + 2f;

        RedButton champ = new RedButton("精英效果：" + champSummary()) {
            @Override
            protected void onClick() {
                hide();
                GameScene.show(new WndSpawner(MODE_MOB_CHAMP, g, 0, 0));
            }
        };
        champ.setRect(0, pos, width, BTN_HEIGHT);
        add(champ);
        pos += BTN_HEIGHT + 2f;

        RedButton back = new RedButton("返回") {
            @Override
            protected void onClick() {
                hide();
                GameScene.show(new WndSpawner(MODE_MOB_GROUPS, 0, 0, 0));
            }
        };
        back.setRect(0, pos, width, BTN_HEIGHT);
        add(back);
        pos += BTN_HEIGHT + 2f;

        addClose(pos, width);
    }

    private void buildChampPick() {
        int width = width();
        float pos = title("精英效果", width);

        RenderedTextBlock hint = PixelScene.renderTextBlock(6);
        hint.text("生成生物时附加的精英（Champion）效果。", width);
        hint.setPos(0, pos);
        add(hint);
        pos = hint.bottom() + 4f;

        RedButton none = new RedButton(champMode == 0 ? "✓ 无" : "无") {
            @Override
            protected void onClick() {
                champMode = 0;
                champPick = null;
                reopen();
            }
        };
        none.setRect(0, pos, width, BTN_HEIGHT);
        add(none);
        pos += BTN_HEIGHT + 2f;

        RedButton random = new RedButton(champMode == 1 ? "✓ 随机" : "随机") {
            @Override
            protected void onClick() {
                champMode = 1;
                champPick = null;
                reopen();
            }
        };
        random.setRect(0, pos, width, BTN_HEIGHT);
        add(random);
        pos += BTN_HEIGHT + 2f;

        for (final Class<? extends ChampionEnemy> c : CHAMPIONS) {
            boolean picked = champMode == 2 && c.equals(champPick);
            RedButton btn = new RedButton((picked ? "✓ " : "") + champName(c)) {
                @Override
                protected void onClick() {
                    champMode = 2;
                    champPick = c;
                    reopen();
                }
            };
            btn.setRect(0, pos, width, BTN_HEIGHT);
            add(btn);
            pos += BTN_HEIGHT + 2f;
        }

        RedButton back = new RedButton("返回") {
            @Override
            protected void onClick() {
                hide();
                GameScene.show(new WndSpawner(MODE_MOB_GROUPS, 0, 0, 0));
            }
        };
        back.setRect(0, pos, width, BTN_HEIGHT);
        add(back);
        pos += BTN_HEIGHT + 2f;

        addClose(pos, width);
    }

    private void reopen() {
        hide();
        GameScene.show(new WndSpawner(MODE_MOB_LIST, Math.min(2, Math.max(0, group)), 0, 0));
    }

    /** 在玩家身边生成一只生物，并按设置附加精英效果 */
    private void spawnMob(Class<? extends Mob> cls, String label) {
        Hero hero = Dungeon.hero;
        if (hero == null || Dungeon.level == null) {
            return;
        }
        int cell = -1;
        for (int i : com.watabou.utils.PathFinder.NEIGHBOURS8) {
            int c = hero.pos + i;
            if (c < 0 || c >= Dungeon.level.length()) {
                continue;
            }
            if (Dungeon.level.passable[c] && Actor.findChar(c) == null) {
                cell = c;
                break;
            }
        }
        if (cell == -1) {
            GLog.w("身边没有空地可以生成。");
            return;
        }
        try {
            Mob m = cls.getDeclaredConstructor().newInstance();
            m.pos = cell;
            GameScene.add(m);
            if (champMode == 1) {
                ChampionEnemy.rollForChampion(m);
            } else if (champMode == 2 && champPick != null) {
                Buff.affect(m, champPick);
            }
            GLog.p("生成了「" + label + "」" + (champMode == 0 ? "" : "（精英）"));
        } catch (Throwable t) {
            GLog.w("生成失败：" + t);
        }
    }

    private void onItemClicked(Class<? extends Item> cls, String label) {
        // 武器/护甲：总是先进附魔选择界面（可在里面选 不附魔 / 随机附魔 / 具体附魔）
        boolean equippable = Weapon.class.isAssignableFrom(cls) || Armor.class.isAssignableFrom(cls);
        if (equippable) {
            hide();
            GameScene.show(new Pick(Pick.KIND_COMMON, 0, group, cat, page, cls));
            return;
        }
        spawn(cls, label, false, null);
    }

    // ==================================================================
    // 设置窗
    // ==================================================================

    public static class Opt extends Window {
        private final int group, cat, page;

        public Opt(int group, int cat, int page) {
            super();
            this.group = group;
            this.cat = cat;
            this.page = page;

            int width = PixelScene.landscape() ? WIDTH_L : WIDTH_P;
            float pos = 2f;

            RenderedTextBlock t = PixelScene.renderTextBlock("生成设置", 9);
            t.hardlight(TITLE_COLOR);
            t.maxWidth(width - 4);
            t.setPos(2f, pos);
            add(t);
            pos = t.bottom() + 4f;

            pos = row("数量(消耗品)", width, pos,
                    new String[]{"×1", "×2", "×5", "×10", "×99"},
                    new Runnable[]{() -> spawnQty = 1, () -> spawnQty = 2, () -> spawnQty = 5,
                            () -> spawnQty = 10, () -> spawnQty = 99});

            pos = row("等级", width, pos,
                    new String[]{"+0", "+1", "+3", "+5", "+10"},
                    new Runnable[]{() -> spawnLevel = 0, () -> spawnLevel = 1, () -> spawnLevel = 3,
                            () -> spawnLevel = 5, () -> spawnLevel = 10});

            RenderedTextBlock hint = PixelScene.renderTextBlock(6);
            hint.text("附魔不在设置里选：点装备时会弹出附魔选择界面，\n"
                    + "可在那选择「不附魔」「随机附魔」或具体附魔。", width);
            hint.setPos(0, pos);
            add(hint);
            pos = hint.bottom() + 3f;

            RedButton back = new RedButton("返回列表") {
                @Override
                protected void onClick() {
                    hide();
                    GameScene.show(new WndSpawner(MODE_LIST, group, cat, page));
                }
            };
            back.setRect(0, pos, width, BTN_HEIGHT);
            add(back);
            pos += BTN_HEIGHT + 4f;

            resize(width, (int) pos);
        }

        private void rebuild() {
            hide();
            GameScene.show(new Opt(group, cat, page));
        }

        private float row(String label, int width, float pos, String[] texts, Runnable[] actions) {
            RenderedTextBlock lb = PixelScene.renderTextBlock(label, 6);
            lb.setPos(0, pos);
            add(lb);

            float w = (width - 2f * (texts.length - 1)) / texts.length;
            float x = 0;
            for (int i = 0; i < texts.length; i++) {
                final Runnable act = actions[i];
                RedButton b = new RedButton(texts[i]) {
                    @Override
                    protected void onClick() {
                        act.run();
                        rebuild();
                    }
                };
                b.setRect(x, pos + 8f, w, 14f);
                add(b);
                x += w + 2f;
            }
            return pos + 8f + 14f + 3f;
        }
    }

    // ==================================================================
    // 附魔 / 诅咒 选择窗
    // ==================================================================

    public static class Pick extends Window {
        /** 页签按稀有度分组：0 普通(50%) 1 少见(40%) 2 稀有(10%) 3 诅咒 */
        static final int KIND_COMMON = 0;
        static final int KIND_UNCOMMON = 1;
        static final int KIND_RARE = 2;
        static final int KIND_CURSE = 3;
        static final String[] KIND_NAMES = {"普通", "少见", "稀有", "诅咒"};

        private final int kind;
        private final int page;
        private final int group, cat, listPage;
        private final Class<? extends Item> itemCls;

        Pick(int kind, int page, int group, int cat, int listPage, Class<? extends Item> itemCls) {
            super();
            this.kind = kind;
            this.page = page;
            this.group = group;
            this.cat = cat;
            this.listPage = listPage;
            this.itemCls = itemCls;

            int width = PixelScene.landscape() ? WIDTH_L : WIDTH_P;
            float pos = 2f;

            // 不再显示 "附魔选择 · 武器名" 标题，省出垂直空间，保证整页在屏幕内

            // 不附魔 / 随机附魔（从设置页并入这里）
            float half0 = (width - 2f) / 2f;
            RedButton plain = new RedButton("不附魔") {
                @Override
                protected void onClick() {
                    hide();
                    enchantPick = null;
                    spawn(itemCls, nameOf(itemCls), false, null);
                }
            };
            plain.setRect(0, pos, half0, BTN_HEIGHT);
            add(plain);

            RedButton random = new RedButton("随机附魔") {
                @Override
                protected void onClick() {
                    hide();
                    enchantPick = null;
                    spawn(itemCls, nameOf(itemCls), true, null);
                }
            };
            random.setRect(half0 + 2f, pos, half0, BTN_HEIGHT);
            add(random);
            pos += BTN_HEIGHT + 3f;

            // 四个页签（普通 / 少见 / 稀有 / 诅咒）
            float tw = (width - 3f * 2f) / 4f;
            for (int k = 0; k < KIND_NAMES.length; k++) {
                final int kk = k;
                RedButton tab = new RedButton(KIND_NAMES[k]) {
                    @Override
                    protected void onClick() {
                        hide();
                        GameScene.show(new Pick(kk, 0, group, cat, listPage, itemCls));
                    }
                };
                tab.setRect(k * (tw + 2f), pos, tw, BTN_HEIGHT);
                tab.enable(kind != k);
                add(tab);
            }
            pos += BTN_HEIGHT + 3f;

            List<Class<?>> opts = listFor(itemCls, kind);
            int pages = Math.max(1, (opts.size() + PICK_PER_PAGE - 1) / PICK_PER_PAGE);
            final int cur = Math.min(Math.max(page, 0), pages - 1);

            RenderedTextBlock pg = PixelScene.renderTextBlock(6);
            pg.text(nameOf(itemCls) + " · " + shortWeight(kind) + " · " + opts.size()
                    + " 种 · " + (cur + 1) + "/" + pages, width);
            pg.setPos(0, pos);
            add(pg);
            pos = pg.bottom() + 3f;

            int from = cur * PICK_PER_PAGE;
            int to = Math.min(opts.size(), from + PICK_PER_PAGE);
            for (int i = from; i < to; i++) {
                final Class<?> e = opts.get(i);
                float btnW = width - 18f;
                RedButton btn = new RedButton(enchantName(e)) {
                    @Override
                    protected void onClick() {
                        hide();
                        enchantPick = e;
                        enchantMode = 2;
                        spawn(itemCls, nameOf(itemCls), false, e);
                    }
                };
                btn.setRect(0, pos, btnW, BTN_HEIGHT);
                add(btn);

                // 右侧简介：效果 + 计算公式
                IconButton info = new IconButton(Icons.get(Icons.INFO)) {
                    @Override
                    protected void onClick() {
                        super.onClick();
                        GameScene.show(new Info(enchantName(e), EnchantInfo.describe(e)));
                    }
                };
                info.setRect(width - 16f, pos + 1f, 16f, 16f);
                add(info);

                pos += BTN_HEIGHT + 2f;
            }
            for (int i = to - from; i < PICK_PER_PAGE; i++) {
                pos += BTN_HEIGHT + 2f;
            }

            // 翻页按钮固定占位
            float half = (width - 2f) / 2f;
            RedButton prev = new RedButton("上一页") {
                @Override
                protected void onClick() {
                    hide();
                    GameScene.show(new Pick(kind, Math.max(0, cur - 1), group, cat, listPage, itemCls));
                }
            };
            prev.setRect(0, pos, half, BTN_HEIGHT);
            prev.enable(cur > 0);
            add(prev);

            RedButton next = new RedButton("下一页") {
                @Override
                protected void onClick() {
                    hide();
                    GameScene.show(new Pick(kind, Math.min(pages - 1, cur + 1), group, cat, listPage, itemCls));
                }
            };
            next.setRect(half + 2f, pos, half, BTN_HEIGHT);
            next.enable(cur < pages - 1);
            add(next);
            pos += BTN_HEIGHT + 2f;

            RedButton back = new RedButton("返回") {
                @Override
                protected void onClick() {
                    hide();
                    GameScene.show(new WndSpawner(MODE_LIST, group, cat, listPage));
                }
            };
            back.setRect(0, pos, width, BTN_HEIGHT);
            add(back);
            pos += BTN_HEIGHT + 2f;

            RedButton close = new RedButton("关闭") {
                @Override
                protected void onClick() {
                    hide();
                }
            };
            close.setRect(0, pos, width, BTN_HEIGHT);
            add(close);
            pos += BTN_HEIGHT + 4f;

            resize(width, (int) pos);
        }

        /** 紧凑版页签说明，塞进一行信息里，不额外占高度。 */
        private static String shortWeight(int kind) {
            switch (kind) {
                case KIND_COMMON:
                    return "普通 50%";
                case KIND_UNCOMMON:
                    return "少见 40%";
                case KIND_RARE:
                    return "稀有 10%";
                default:
                    return "诅咒";
            }
        }

        private static String weightText(int kind) {
            switch (kind) {
                case KIND_COMMON:
                    return "普通附魔（50% 权重）";
                case KIND_UNCOMMON:
                    return "少见附魔（40% 权重）";
                case KIND_RARE:
                    return "稀有附魔（10% 权重）";
                default:
                    return "诅咒附魔";
            }
        }
    }

    // ==================================================================
    // 说明窗    // ==================================================================
    // 说明窗（长文本按段落分页）
    // ==================================================================

    public static class Info extends Window {
        /** 超过这个行数才分页；普通附魔仍是一页看完 */
        private static final int PAGED_THRESHOLD = 20;
        private static final int LINES_PER_PAGE = 13;

        Info(String heading, String content) {
            this(heading, content, 0);
        }

        Info(String heading, String content, int page) {
            super();
            int width = PixelScene.landscape() ? WIDTH_L : WIDTH_P;

            List<String> pages = split(content);
            final int pagesN = pages.size();
            final int cur = Math.min(Math.max(page, 0), pagesN - 1);

            float pos = 2f;
            RenderedTextBlock t = PixelScene.renderTextBlock(heading, 9);
            t.hardlight(TITLE_COLOR);
            t.maxWidth(width - 4);
            t.setPos(2f, pos);
            add(t);
            pos = t.bottom() + 4f;

            RenderedTextBlock body = PixelScene.renderTextBlock(pages.get(cur), 6);
            body.maxWidth(width - 8);
            body.setPos(2f, pos);
            add(body);
            pos = body.bottom() + 4f;

            if (pagesN > 1) {
                RenderedTextBlock pg = PixelScene.renderTextBlock(6);
                pg.text("第 " + (cur + 1) + "/" + pagesN + " 页", width);
                pg.setPos(0, pos);
                add(pg);
                pos = pg.bottom() + 2f;

                float half = (width - 2f) / 2f;
                RedButton prev = new RedButton("上一页") {
                    @Override
                    protected void onClick() {
                        hide();
                        GameScene.show(new Info(heading, content, cur - 1));
                    }
                };
                prev.setRect(0, pos, half, BTN_HEIGHT);
                prev.enable(cur > 0);
                add(prev);

                RedButton next = new RedButton("下一页") {
                    @Override
                    protected void onClick() {
                        hide();
                        GameScene.show(new Info(heading, content, cur + 1));
                    }
                };
                next.setRect(half + 2f, pos, half, BTN_HEIGHT);
                next.enable(cur < pagesN - 1);
                add(next);
                pos += BTN_HEIGHT + 2f;
            }

            RedButton close = new RedButton("关闭") {
                @Override
                protected void onClick() {
                    hide();
                }
            };
            close.setRect(0, pos, width, BTN_HEIGHT);
            add(close);
            pos += BTN_HEIGHT + 4f;

            resize(width, (int) pos);
        }

        /** 短文本不分页；长文本按固定行数切页。 */
        private static List<String> split(String content) {
            List<String> pages = new ArrayList<>();
            String[] lines = content.split("\n");
            if (lines.length <= PAGED_THRESHOLD) {
                pages.add(content);
                return pages;
            }
            for (int i = 0; i < lines.length; i += LINES_PER_PAGE) {
                StringBuilder sb = new StringBuilder();
                for (int k = i; k < Math.min(lines.length, i + LINES_PER_PAGE); k++) {
                    if (k > i) {
                        sb.append('\n');
                    }
                    sb.append(lines[k]);
                }
                pages.add(sb.toString());
            }
            return pages;
        }
    }




    // ==================================================================
    // 附魔清单
    // ==================================================================

    /** kind: 0 普通(50%) / 1 少见(40%) / 2 稀有(10%) / 3 诅咒 */
    static List<Class<?>> listFor(Class<?> itemCls, int kind) {
        List<Class<?>> out = new ArrayList<>();
        try {
            Class<?>[][] tiers;
            if (Armor.class.isAssignableFrom(itemCls)) {
                tiers = new Class<?>[][]{
                        Armor.Glyph.common, Armor.Glyph.uncommon, Armor.Glyph.rare, Armor.Glyph.curses};
            } else if (Weapon.class.isAssignableFrom(itemCls)) {
                tiers = new Class<?>[][]{
                        Weapon.Enchantment.common, Weapon.Enchantment.uncommon,
                        Weapon.Enchantment.rare, Weapon.Enchantment.curses};
            } else {
                return out;
            }
            if (kind >= 0 && kind < tiers.length) {
                out.addAll(Arrays.asList(tiers[kind]));
            }
        } catch (Throwable ignored) {
        }
        return out;
    }

    static boolean isCurse(Class<?> e) {
        if (e == null) {
            return false;
        }
        return Arrays.asList(Armor.Glyph.curses).contains(e)
                || Arrays.asList(Weapon.Enchantment.curses).contains(e);
    }

    static String enchantName(Class<?> e) {
        try {
            Object inst = e.getDeclaredConstructor().newInstance();
            // name("") 会去掉 "烈焰附魔" 里的"附魔"后缀，列表里只显示 "烈焰"
            if (inst instanceof Armor.Glyph) {
                return Messages.titleCase(((Armor.Glyph) inst).name(""));
            }
            if (inst instanceof Weapon.Enchantment) {
                return Messages.titleCase(((Weapon.Enchantment) inst).name(""));
            }
        } catch (Throwable ignored) {
        }
        return e.getSimpleName();
    }

    /** 附魔/诅咒的说明文本（直接用游戏自带的 desc，含具体数值与公式）。 */
    static String enchantDesc(Class<?> e) {
        try {
            Object inst = e.getDeclaredConstructor().newInstance();
            if (inst instanceof Armor.Glyph) {
                return ((Armor.Glyph) inst).desc();
            }
            if (inst instanceof Weapon.Enchantment) {
                return ((Weapon.Enchantment) inst).desc();
            }
        } catch (Throwable ignored) {
        }
        return "（暂无说明）";
    }

    static String enchantSummary() {
        return "附魔:点装备时选";
    }

    // ==================================================================
    // 生成
    // ==================================================================

    static void spawn(Class<? extends Item> cls, String label, boolean randomEnchant, Class<?> picked) {
        if (Dungeon.hero == null || Dungeon.hero.belongings == null) {
            return;
        }
        // 装备固定只生成 1 件；数量设置只对消耗品生效
        // 用分类判断（而不是 isEquipment）：飞镖是 MissileWeapon，但属于消耗品，数量要生效
        int count = categoryOf(cls) < FIRST_CONSUMABLE ? 1 : Math.max(1, spawnQty);
        int made = 0;
        for (int i = 0; i < count; i++) {
            try {
                Item item = cls.getDeclaredConstructor().newInstance();
                applyFallbackSprite(item);

                if (spawnLevel > 0 && item.isUpgradable()) {
                    item.upgrade(spawnLevel);
                }
                applyEnchant(item, randomEnchant, picked);

                item.identify(true);
                item.collect(Dungeon.hero.belongings.backpack);
                made++;
            } catch (Throwable t) {
                break;
            }
        }
        if (made > 0) {
            GLog.p("获得: " + label + " ×" + made + (spawnLevel > 0 ? " +" + spawnLevel : "")
                    + (picked != null && isCurse(picked) ? "（诅咒）" : ""));
        } else {
            GLog.w("生成失败: " + label);
        }
    }

    private static void applyEnchant(Item item, boolean random, Class<?> picked) {
        if (random) {
            try {
                if (item instanceof Armor) {
                    ((Armor) item).inscribe();
                } else if (item instanceof Weapon) {
                    ((Weapon) item).enchant();
                }
            } catch (Throwable ignored) {
            }
            return;
        }
        if (picked == null) {
            return;
        }
        try {
            if (item instanceof Armor && Armor.Glyph.class.isAssignableFrom(picked)) {
                Armor.Glyph g = (Armor.Glyph) picked.getDeclaredConstructor().newInstance();
                ((Armor) item).inscribe(g);
            } else if (item instanceof Weapon && Weapon.Enchantment.class.isAssignableFrom(picked)) {
                Weapon.Enchantment e = (Weapon.Enchantment) picked.getDeclaredConstructor().newInstance();
                ((Weapon) item).enchant(e);
            }
            // 选的是诅咒：同时把物品标成被诅咒
            if (isCurse(picked)) {
                item.cursed = true;
                item.cursedKnown = true;
            }
        } catch (Throwable ignored) {
        }
    }

    // ==================================================================
    // 图标
    // ==================================================================

    /**
     * 分类图标可指定"偏好物品"，键是 CAT_NAMES 的下标，值是物品的完整类名。
     * 没配的分类默认取该分类里排序后的第一个物品。
     */
    private static final java.util.HashMap<Integer, String> ICON_PREF = new java.util.HashMap<>();

    static {
        // 种子：用「阳春草之种」做预览图标
        ICON_PREF.put(CAT_SEED, "com.shatteredpixel.shatteredpixeldungeon.plants.Sungrass$Seed");
    }

    private static Image iconForCategory(int cat) {
        List<Class<? extends Item>> list = classesIn(cat);
        if (list.isEmpty()) {
            return null;
        }
        String pref = ICON_PREF.get(cat);
        if (pref != null) {
            for (Class<? extends Item> k : list) {
                if (k.getName().equals(pref)) {
                    return iconForClass(k);
                }
            }
        }
        return iconForClass(list.get(0));
    }

    /**
     * 个别物品在原版里没有设置贴图（image = 0，游戏里会显示成「？」），
     * 这里按全限定名给它一个替代图标，至少能看清是什么东西。
     */
    private static final java.util.HashMap<String, Integer> IMAGE_FALLBACK = new java.util.HashMap<>();

    static {
        // 无味果之种：原版没给贴图，借无味果的图标
        IMAGE_FALLBACK.put("com.shatteredpixel.shatteredpixeldungeon.plants.BlandfruitBush$Seed",
                com.shatteredpixel.shatteredpixeldungeon.sprites.ItemSpriteSheet.BLANDFRUIT);
    }

    private static void applyFallbackSprite(Item it) {
        if (it == null || it.image > 0) {
            return;
        }
        Integer alt = IMAGE_FALLBACK.get(it.getClass().getName());
        if (alt != null) {
            it.image = alt;
        }
    }

    private static Image iconForClass(Class<? extends Item> cls) {
        try {
            Item it = cls.getDeclaredConstructor().newInstance();
            applyFallbackSprite(it);
            return new ItemSprite(it);
        } catch (Throwable t) {
            return null;
        }
    }

    // ==================================================================
    // 通用 UI
    // ==================================================================

    public static int width() {
        return PixelScene.landscape() ? WIDTH_L : WIDTH_P;
    }

    /** 可视高度（虚拟像素）。窗口超过它时游戏会把窗口上移，导致顶部被裁掉。 */
    static int visibleHeight() {
        float h;
        try {
            h = com.watabou.noosa.Camera.main.height;
        } catch (Throwable t) {
            h = 320f;
        }
        if (h <= 0) {
            h = 320f;
        }
        return (int) (h * 0.92f);
    }

    /** 在给定头部高度下，这一页最多能放多少行（含翻页/返回/关闭三行按钮的占位）。 */
    private static int rowsThatFit(float headerHeight, int cap) {
        int nav = 3 * (BTN_HEIGHT + 2) + 10;
        int avail = visibleHeight() - (int) headerHeight - nav;
        return Math.max(3, Math.min(cap, avail / (BTN_HEIGHT + 2)));
    }

    /** 把已占用的行数补足到 target 行，让下方的翻页/返回/关闭按钮位置固定。 */
    private float reserveRows(float pos, int rows, int target) {
        for (int i = rows; i < target; i++) {
            pos += BTN_HEIGHT + 2f;
        }
        return pos;
    }

    private float title(String text, int width) {
        RenderedTextBlock t = PixelScene.renderTextBlock(text, 9);
        t.hardlight(TITLE_COLOR);
        t.maxWidth(width - 4);
        t.setPos(2f, 2f);
        add(t);
        return t.bottom() + 4f;
    }

    private void addClose(float pos, int width) {
        RedButton close = new RedButton("关闭") {
            @Override
            protected void onClick() {
                hide();
            }
        };
        close.setRect(0, pos, width, BTN_HEIGHT);
        add(close);
        pos += BTN_HEIGHT + 4f;
        resize(width, (int) pos);
    }

    private static List<Class<? extends Item>> classesIn(int cat) {
        List<Class<? extends Item>> out = new ArrayList<>();
        for (Class<? extends Item> k : allClasses) {
            if (categoryOf(k) == cat) {
                out.add(k);
            }
        }
        // 武器/护甲/投掷物按阶数升序，再按名称；其它按名称
        out.sort((a, b) -> {
            int ta = tierOf(a);
            int tb = tierOf(b);
            if (ta != tb) {
                return Integer.compare(ta, tb);
            }
            return nameOf(a).compareTo(nameOf(b));
        });
        return out;
    }

    /** 阶数：近战/投掷武器与护甲读 tier 字段，其余为 0。 */
    static int tierOf(Class<? extends Item> cls) {        Integer cached = TIERS.get(cls);
        if (cached != null) {
            return cached;
        }
        int tier = 0;
        try {
            Item it = cls.getDeclaredConstructor().newInstance();
            if (it instanceof MeleeWeapon) {
                tier = ((MeleeWeapon) it).tier;
            } else if (it instanceof MissileWeapon) {
                tier = ((MissileWeapon) it).tier;
            } else if (it instanceof Armor) {
                tier = ((Armor) it).tier;
            }
        } catch (Throwable ignored) {
        }
        TIERS.put(cls, tier);
        return tier;
    }

    /** 分类里出现的阶数（升序）；完全无阶数概念的分类返回空列表。 */
    static List<Integer> tiersOf(List<Class<? extends Item>> list) {
        java.util.TreeSet<Integer> set = new java.util.TreeSet<>();
        for (Class<? extends Item> k : list) {
            set.add(tierOf(k));
        }
        if (set.size() == 1 && set.first() == 0) {
            return new ArrayList<>();
        }
        return new ArrayList<>(set);
    }

    static String tierLabel(int tier) {
        return tier <= 0 ? "无阶" : tier + " 阶";
    }

    static String nameOf(Class<? extends Item> cls) {
        String cached = NAMES.get(cls);
        if (cached != null) {
            return cached;
        }
        String name;
        try {
            Item it = cls.getDeclaredConstructor().newInstance();
            name = Messages.titleCase(it.trueName());
        } catch (Throwable t) {
            try {
                name = Messages.titleCase(Messages.get(cls, "name"));
            } catch (Throwable t2) {
                name = cls.getSimpleName();
            }
        }
        NAMES.put(cls, name);
        return name;
    }

    // ==================================================================
    // 分类判定
    // ==================================================================

    private static boolean isEquipment(Class<?> k) {
        return EquipableItem.class.isAssignableFrom(k)
                || KindOfWeapon.class.isAssignableFrom(k)
                || KindofMisc.class.isAssignableFrom(k)
                || Armor.class.isAssignableFrom(k)
                || Trinket.class.isAssignableFrom(k)
                || MissileWeapon.class.isAssignableFrom(k)
                || MeleeWeapon.class.isAssignableFrom(k);
    }

    /** 「英雄遗物」：英雄遗骸类道具（含纹章残蜡 SealShard） */
    private static final java.util.HashSet<String> HERO_RELICS = new java.util.HashSet<>(Arrays.asList(
            "BrokenHilt", "BrokenStaff", "BowFragment", "BrokenSeal", "TornPage", "CloakScrap",
            "SealShard"));

    /** 「钥匙」 */
    private static final java.util.HashSet<String> KEYS = new java.util.HashSet<>(Arrays.asList(
            "CrystalKey", "GoldenKey", "IronKey", "WornKey"));

    /** 「任务道具」：剧情/收集类 */
    private static final java.util.HashSet<String> QUEST_ITEMS = new java.util.HashSet<>(Arrays.asList(
            "Amulet", "KingsCrown", "TengusMask", "CeremonialCandle", "CorpseDust",
            "DwarfToken", "GooBlob", "ImpStatue", "Guidebook"));

    public static int categoryOf(Class<?> k) {
        String n = k.getSimpleName();

        // ---------- 装备 ----------
        if (MeleeWeapon.class.isAssignableFrom(k)) return CAT_MELEE;
        if (Armor.class.isAssignableFrom(k)) return CAT_ARMOR;
        if (Dart.class.isAssignableFrom(k)) return CAT_DART;
        if (Bomb.class.isAssignableFrom(k)) return CAT_BOMB;
        if (MissileWeapon.class.isAssignableFrom(k)) return CAT_MISSILE;
        if (Wand.class.isAssignableFrom(k)) return CAT_WAND;
        if (Ring.class.isAssignableFrom(k)) return CAT_RING;
        if (Artifact.class.isAssignableFrom(k)) return CAT_ARTIFACT;
        if (Trinket.class.isAssignableFrom(k)) return CAT_TRINKET;
        if (KindofMisc.class.isAssignableFrom(k)) return CAT_MISC_EQUIP;

        // ---------- 消耗品 ----------
        if (Brew.class.isAssignableFrom(k)) return CAT_BREW;
        if (ExoticPotion.class.isAssignableFrom(k)) return CAT_EXOTIC_POTION;
        if (Elixir.class.isAssignableFrom(k)) return CAT_EXOTIC_POTION;
        if (Potion.class.isAssignableFrom(k)) return CAT_POTION;
        if (ExoticScroll.class.isAssignableFrom(k)) return CAT_EXOTIC_SCROLL;
        if (Scroll.class.isAssignableFrom(k)) return CAT_SCROLL;
        if (Plant.Seed.class.isAssignableFrom(k)) return CAT_SEED;
        if ("StoneOfAugmentation".equals(n)) return CAT_AUG_STONE;   // 强化符石（要先于符石）
        if (Runestone.class.isAssignableFrom(k)) return CAT_RUNESTONE;
        if (Food.class.isAssignableFrom(k)) return CAT_FOOD;
        if (Spell.class.isAssignableFrom(k)) return CAT_SPELL;

        // 商店专属（现在归在「装备」大类）：十字架 + 三种扩容袋
        if ("Ankh".equals(n) || "PotionBandolier".equals(n)
                || "ScrollHolder".equals(n) || "MagicalHolster".equals(n)) {
            return CAT_SHOP;
        }
        if (HERO_RELICS.contains(n)) return CAT_RELIC;
        if (KEYS.contains(n)) return CAT_KEY;
        if (QUEST_ITEMS.contains(n)) return CAT_QUEST;

        return isEquipment(k) ? CAT_MISC_EQUIP : CAT_MISC_CONSUMABLE;
    }

    // ==================================================================
    // 清单构建
    // ==================================================================

    private static List<Class<? extends Item>> allClasses = null;
    private static int[] counts = null;

    private static final java.util.HashSet<String> EXCLUDE = new java.util.HashSet<>(Arrays.asList(
            "Item", "Bag", "Heap", "Generator", "Recipe", "ItemStatusHandler",
            "EquipableItem", "KindOfWeapon", "KindofMisc",
            "AlchemyPage", "GuidePage", "PlaceHolder", "LostBackpack",
            "TestBox"
    ));

    /** 只做基类用、不该被生成的类：按全限定名排除（同名内部类如植物种子不受影响）。 */
    private static final java.util.HashSet<String> EXCLUDE_FQN = new java.util.HashSet<>(Arrays.asList(
            "com.shatteredpixel.shatteredpixeldungeon.items.weapon.Weapon",
            "com.shatteredpixel.shatteredpixeldungeon.items.weapon.melee.MeleeWeapon",
            "com.shatteredpixel.shatteredpixeldungeon.items.weapon.missiles.MissileWeapon",
            "com.shatteredpixel.shatteredpixeldungeon.items.weapon.missiles.darts.Dart",
            "com.shatteredpixel.shatteredpixeldungeon.items.armor.Armor",
            "com.shatteredpixel.shatteredpixeldungeon.items.wands.Wand",
            "com.shatteredpixel.shatteredpixeldungeon.items.rings.Ring",
            "com.shatteredpixel.shatteredpixeldungeon.items.artifacts.Artifact",
            "com.shatteredpixel.shatteredpixeldungeon.items.trinkets.Trinket",
            "com.shatteredpixel.shatteredpixeldungeon.items.potions.Potion",
            "com.shatteredpixel.shatteredpixeldungeon.items.potions.brews.Brew",
            "com.shatteredpixel.shatteredpixeldungeon.items.potions.elixirs.Elixir",
            "com.shatteredpixel.shatteredpixeldungeon.items.potions.exotic.ExoticPotion",
            "com.shatteredpixel.shatteredpixeldungeon.items.scrolls.Scroll",
            "com.shatteredpixel.shatteredpixeldungeon.items.scrolls.exotic.ExoticScroll",
            "com.shatteredpixel.shatteredpixeldungeon.items.spells.Spell",
            "com.shatteredpixel.shatteredpixeldungeon.items.spells.InventorySpell",
            "com.shatteredpixel.shatteredpixeldungeon.items.spells.TargetedSpell",
            "com.shatteredpixel.shatteredpixeldungeon.items.stones.Runestone",
            "com.shatteredpixel.shatteredpixeldungeon.items.food.Food",
            "com.shatteredpixel.shatteredpixeldungeon.plants.Plant"
    ));

    static void ensureCatalog() {
        if (allClasses != null) {
            return;
        }
        LinkedHashSet<Class<? extends Item>> set = new LinkedHashSet<>();

        try {
            File src = new File(Item.class.getProtectionDomain()
                    .getCodeSource().getLocation().toURI());
            if (src.isFile()) {
                scanJar(src, set);
            }
        } catch (Throwable ignored) {
        }

        // MOD: 安卓上代码不在 jar 里，扫描失败——用构建时生成的类清单兜底
        try {
            for (String cn : com.shatteredpixel.shatteredpixeldungeon.items.ItemCatalog.ITEM_CLASSES) {
                try {
                    Class<?> k = Class.forName(cn, false, WndSpawner.class.getClassLoader());
                    if (k == null || k.isInterface() || Modifier.isAbstract(k.getModifiers())) {
                        continue;
                    }
                    if (!Item.class.isAssignableFrom(k)) {
                        continue;
                    }
                    if (EXCLUDE_FQN.contains(k.getName())) {
                        continue;
                    }
                    Item probe;
                    try {
                        probe = (Item) k.getDeclaredConstructor().newInstance();
                    } catch (Throwable noCtor) {
                        continue;
                    }
                    if (probe instanceof com.shatteredpixel.shatteredpixeldungeon.items.TestBox) {
                        continue;
                    }
                    set.add(k.asSubclass(Item.class));
                } catch (Throwable ignored) {
                }
            }
        } catch (Throwable ignored) {
        }

        if (set.isEmpty()) {
            try {
                for (com.shatteredpixel.shatteredpixeldungeon.items.Generator.Category c
                        : com.shatteredpixel.shatteredpixeldungeon.items.Generator.Category.values()) {
                    Class<?>[] arr = c.classes;
                    if (arr == null) continue;
                    for (Class<?> k : arr) {
                        if (k != null && Item.class.isAssignableFrom(k)
                                && !Modifier.isAbstract(k.getModifiers())) {
                            set.add(k.asSubclass(Item.class));
                        }
                    }
                }
            } catch (Throwable ignored) {
            }
        }

        List<Class<? extends Item>> list = new ArrayList<>(set);
        list.sort((a, b) -> a.getSimpleName().compareTo(b.getSimpleName()));

        // 剔除「取不到名字」的类：这些是只做基类/占位用的，生成了只会显示 !!!NO TEXT FOUND!!!
        // 先查语言表（便宜）；语言表里没有的，再实例化确认一次——
        // 有些物品的名字是硬编码在 name() 里的，不能被误删
        List<Class<? extends Item>> usable = new ArrayList<>(list.size());
        for (Class<? extends Item> k : list) {
            if (!noNameInMessages(k)) {
                usable.add(k);
                continue;
            }
            try {
                Item probe = k.getDeclaredConstructor().newInstance();
                String nm = probe.name();
                if (nm != null && !nm.contains("NO TEXT FOUND")) {
                    usable.add(k);
                }
            } catch (Throwable ignored) {
                // 实例化不了（抽象/需要参数）——本来也生成不出来
            }
        }
        list = usable;

        // 「商店专属」里把重生十字架和魔法箭袋换个位置（默认是按类名字母序）
        int ankh = indexOfSimpleName(list, "Ankh");
        int holster = indexOfSimpleName(list, "MagicalHolster");
        if (ankh >= 0 && holster >= 0) {
            java.util.Collections.swap(list, ankh, holster);
        }

        allClasses = list;

        counts = new int[CAT_COUNT];
        for (Class<? extends Item> k : allClasses) {
            counts[categoryOf(k)]++;
        }
    }

    /** 语言表里取不到名字（会显示 !!!NO TEXT FOUND!!!） */
    private static boolean noNameInMessages(Class<?> k) {
        try {
            return Messages.get(k, "name").contains("NO TEXT FOUND");
        } catch (Throwable t) {
            return false;
        }
    }

    /** 按简单类名找下标（找不到返回 -1），用于给个别分类微调顺序 */
    private static int indexOfSimpleName(List<Class<? extends Item>> list, String simpleName) {
        for (int i = 0; i < list.size(); i++) {
            if (simpleName.equals(list.get(i).getSimpleName())) {
                return i;
            }
        }
        return -1;
    }

    private static void scanMobJar(File jar, LinkedHashSet<Class<? extends Mob>> out) {
        String pkg = "com/shatteredpixel/shatteredpixeldungeon/";
        try (JarFile jf = new JarFile(jar)) {
            Enumeration<JarEntry> en = jf.entries();
            while (en.hasMoreElements()) {
                String n = en.nextElement().getName();
                if (!n.endsWith(".class") || n.contains("$")) continue;
                if (!n.startsWith(pkg + "actors/mobs/")) continue;
                String cn = n.substring(0, n.length() - 6).replace('/', '.');
                try {
                    Class<?> k = Class.forName(cn, false, WndSpawner.class.getClassLoader());
                    if (Mob.class.isAssignableFrom(k) && !Modifier.isAbstract(k.getModifiers())
                            && k != Mob.class && !"ThornDoor".equals(k.getSimpleName())) {
                        out.add(k.asSubclass(Mob.class));
                    }
                } catch (Throwable ignored) {
                }
            }
        } catch (Throwable ignored) {
        }
    }

    private static void scanMobDir(File dir, LinkedHashSet<Class<? extends Mob>> out) {
        String pkg = "com" + File.separator + "shatteredpixel" + File.separator
                + "shatteredpixeldungeon" + File.separator + "actors" + File.separator + "mobs";
        File base = new File(dir, pkg);
        File[] files = base.listFiles();
        if (files == null) return;
        for (File f : files) {
            if (!f.getName().endsWith(".class") || f.getName().contains("$")) continue;
            String cn = "com.shatteredpixel.shatteredpixeldungeon.actors.mobs."
                    + f.getName().substring(0, f.getName().length() - 6);
            try {
                Class<?> k = Class.forName(cn, false, WndSpawner.class.getClassLoader());
                if (Mob.class.isAssignableFrom(k) && !Modifier.isAbstract(k.getModifiers())
                        && k != Mob.class && !"ThornDoor".equals(k.getSimpleName())) {
                    out.add(k.asSubclass(Mob.class));
                }
            } catch (Throwable ignored) {
            }
        }
    }

    private static void scanJar(File jar, LinkedHashSet<Class<? extends Item>> out) {
        String pkg = "com/shatteredpixel/shatteredpixeldungeon/";
        try (JarFile jf = new JarFile(jar)) {
            Enumeration<JarEntry> en = jf.entries();
            while (en.hasMoreElements()) {
                String n = en.nextElement().getName();
                if (!n.endsWith(".class")) continue;
                if (!(n.startsWith(pkg + "items/") || n.startsWith(pkg + "plants/"))) continue;
                boolean inner = n.contains("$");
                if (inner && !n.startsWith(pkg + "plants/")) continue;
                String cn = n.substring(0, n.length() - 6).replace('/', '.');
                try {
                    Class<?> k = Class.forName(cn, false, WndSpawner.class.getClassLoader());
                    if (Item.class.isAssignableFrom(k) && !Modifier.isAbstract(k.getModifiers())) {
                        if (inner && !Plant.Seed.class.isAssignableFrom(k)) continue;
                        if (EXCLUDE.contains(k.getSimpleName())) continue;
                        if (EXCLUDE_FQN.contains(k.getName())) continue;
                        out.add(k.asSubclass(Item.class));
                    }
                } catch (Throwable ignored) {
                }
            }
        } catch (Throwable ignored) {
        }
    }
}
