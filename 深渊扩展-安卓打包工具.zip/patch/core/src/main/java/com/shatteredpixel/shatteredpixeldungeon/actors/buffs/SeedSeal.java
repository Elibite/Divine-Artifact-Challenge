package com.shatteredpixel.shatteredpixeldungeon.actors.buffs;

import com.shatteredpixel.shatteredpixeldungeon.Dungeon;
import com.watabou.utils.Bundle;

/**
 * MOD: 石化种子（强化）的「封存」记账。
 *
 * <p>吞下一枚符石/种子后，接下来 3 次踩踏高草一定掉出它。
 * 记在英雄身上，所以换层、读档都不会丢。</p>
 */
public class SeedSeal extends Buff {

    /** 还剩几次必掉 */
    public int remaining = 0;

    /** 被封存的物品类名（null = 没有封存） */
    public String itemClass = null;

    private static final String REMAINING = "remaining";
    private static final String ITEM = "item";

    {
        type = buffType.NEUTRAL;
        announced = false;
    }

    public static SeedSeal get() {
        return Dungeon.hero == null ? null : Dungeon.hero.buff(SeedSeal.class);
    }

    public static SeedSeal ensure() {
        return Dungeon.hero == null ? null : Buff.affect(Dungeon.hero, SeedSeal.class);
    }

    @Override
    public void storeInBundle(Bundle bundle) {
        super.storeInBundle(bundle);
        bundle.put(REMAINING, remaining);
        if (itemClass != null) {
            bundle.put(ITEM, itemClass);
        }
    }

    @Override
    public void restoreFromBundle(Bundle bundle) {
        super.restoreFromBundle(bundle);
        remaining = bundle.getInt(REMAINING);
        itemClass = bundle.contains(ITEM) ? bundle.getString(ITEM) : null;
    }
}
