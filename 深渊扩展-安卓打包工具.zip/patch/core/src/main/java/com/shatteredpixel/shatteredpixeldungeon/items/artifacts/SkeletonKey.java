/*
 * Decompiled with CFR 0.152.
 */
package com.shatteredpixel.shatteredpixeldungeon.items.artifacts;

import com.shatteredpixel.shatteredpixeldungeon.items.scrolls.ScrollOfTeleportation;
import com.shatteredpixel.shatteredpixeldungeon.levels.Terrain;
import com.shatteredpixel.shatteredpixeldungeon.scenes.GameScene;
import com.shatteredpixel.shatteredpixeldungeon.Dungeon;
import com.shatteredpixel.shatteredpixeldungeon.actors.Actor;
import com.shatteredpixel.shatteredpixeldungeon.actors.Char;
import com.shatteredpixel.shatteredpixeldungeon.actors.blobs.Blob;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.Buff;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.Weakness;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.MagicImmune;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.Regeneration;
import com.shatteredpixel.shatteredpixeldungeon.actors.hero.Hero;
import com.shatteredpixel.shatteredpixeldungeon.actors.hero.Talent;
import com.shatteredpixel.shatteredpixeldungeon.effects.BlobEmitter;
import com.shatteredpixel.shatteredpixeldungeon.effects.CellEmitter;
import com.shatteredpixel.shatteredpixeldungeon.effects.Speck;
import com.shatteredpixel.shatteredpixeldungeon.effects.particles.SpectralWallParticle;
import com.shatteredpixel.shatteredpixeldungeon.items.Heap;
import com.shatteredpixel.shatteredpixeldungeon.items.Item;
import com.shatteredpixel.shatteredpixeldungeon.items.artifacts.Artifact;
import com.shatteredpixel.shatteredpixeldungeon.items.keys.CrystalKey;
import com.shatteredpixel.shatteredpixeldungeon.items.keys.GoldenKey;
import com.shatteredpixel.shatteredpixeldungeon.items.keys.IronKey;
import com.shatteredpixel.shatteredpixeldungeon.items.rings.RingOfEnergy;
import com.shatteredpixel.shatteredpixeldungeon.items.wands.WandOfBlastWave;
import com.shatteredpixel.shatteredpixeldungeon.journal.Catalog;
import com.shatteredpixel.shatteredpixeldungeon.journal.Notes;
import com.shatteredpixel.shatteredpixeldungeon.levels.Level;
import com.shatteredpixel.shatteredpixeldungeon.mechanics.Ballistica;
import com.shatteredpixel.shatteredpixeldungeon.messages.Messages;
import com.shatteredpixel.shatteredpixeldungeon.scenes.CellSelector;
import com.shatteredpixel.shatteredpixeldungeon.scenes.GameScene;
import com.shatteredpixel.shatteredpixeldungeon.sprites.ItemSprite;
import com.shatteredpixel.shatteredpixeldungeon.sprites.ItemSpriteSheet;
import com.shatteredpixel.shatteredpixeldungeon.tiles.CustomTilemap;
import com.shatteredpixel.shatteredpixeldungeon.tiles.DoorTilemap;
import com.shatteredpixel.shatteredpixeldungeon.tiles.DoorVoidTilemap;
import com.shatteredpixel.shatteredpixeldungeon.tiles.DungeonWallsTilemap;
import com.shatteredpixel.shatteredpixeldungeon.utils.GLog;
import com.shatteredpixel.shatteredpixeldungeon.windows.WndOptions;
import com.watabou.noosa.Game;
import com.watabou.noosa.audio.Sample;
import com.watabou.utils.Bundle;
import com.watabou.utils.Callback;
import com.watabou.utils.PathFinder;
import com.watabou.utils.Random;
import java.util.ArrayList;
import java.util.Arrays;

public class SkeletonKey
extends Artifact {

    // ===== MOD: 主门 / 副门 =====
    public static final String AC_MAIN_DOOR = "MAIN_DOOR";
    public static final String AC_SIDE_DOOR = "SIDE_DOOR";
    /** MOD: 5 充能 → 3 点数 */
    public static final String AC_TRADE = "TRADE_POINTS";
    private int mainPos = -1;
    private int mainDepth = -1;
    private int sidePos = -1;
    private int sideDepth = -1;
    /** MOD: 上一次「对齐本层门坐标」时所在的层数（不存档，换层/读档后重新对齐） */
    private int claimedDepth = -1;

    /** MOD: 强化钥匙的「点数」——专门用来创建主门（铁钥匙 +1 / 金钥匙 +2） */
    public int count = 0;

    private static final String COUNT = "door_count";

    /** MOD: 强化过、并且真的装在神器位上（所有「强化专属」效果都得同时满足这两条） */
    public boolean enhancedAndEquipped() {
        return Dungeon.hero != null && Dungeon.hero.belongings != null
                && Dungeon.hero.belongings.artifact instanceof SkeletonKey
                && ArtifactTrial.isEnhancedClass(SkeletonKey.class);
    }
    public static final String AC_INSERT = "INSERT";
    public CellSelector.Listener targeter;

    public SkeletonKey() {
        this.image = ItemSpriteSheet.ARTIFACT_KEY;
        this.levelCap = 10;
        this.charge = 3 + this.level() / 2;
        this.partialCharge = 0.0f;
        this.chargeCap = 3 + this.level() / 2;
        this.defaultAction = AC_INSERT;
        this.targeter = new CellSelector.Listener(){

            @Override
            public void onSelect(final Integer target) {
                if (target != null && (Dungeon.level.visited[target] || Dungeon.level.mapped[target])) {
                    if (target == curUser.pos) {
                        GLog.w(Messages.get(SkeletonKey.class, "invalid_target", new Object[0]), new Object[0]);
                        return;
                    }
                    if (Dungeon.level.adjacent(target, curUser.pos)) {
                        if (Dungeon.level.map[target] == 21) {
                            GLog.w(Messages.get(SkeletonKey.class, "wont_open", new Object[0]), new Object[0]);
                            return;
                        }
                        if (Dungeon.level.map[target] == 10) {
                            if (Dungeon.level.locked || Dungeon.branch != 0) {
                                GLog.w(Messages.get(SkeletonKey.class, "wont_open", new Object[0]), new Object[0]);
                                return;
                            }
                            // MOD: 强化且装在神器位时，开普通锁不再花充能（经验照拿）
                            final boolean freeLock = SkeletonKey.this.enhancedAndEquipped();
                            if (!freeLock && SkeletonKey.this.charge < 1) {
                                GLog.i(Messages.get(SkeletonKey.class, "iron_charges", new Object[0]), new Object[0]);
                                return;
                            }
                            Sample.INSTANCE.play("sounds/unlock.mp3");
                            curUser.sprite.operate(target, new Callback(){

                                @Override
                                public void call() {
                                    Buff.affect(curUser, KeyReplacementTracker.class).processIronLockOpened();
                                    Level.set(target, 5);
                                    GameScene.updateMap(target);
                                    if (!freeLock) {
                                        --SkeletonKey.this.charge;
                                    }
                                    SkeletonKey.this.gainExp(3);
                                    Talent.onArtifactUsed(Dungeon.hero);
                                    curUser.spendAndNext(1.0f);
                                    curUser.sprite.idle();
                                }
                            });
                            curUser.busy();
                            return;
                        }
                        if (Dungeon.level.map[target] == 38) {
                            Sample.INSTANCE.play("sounds/unlock.mp3");
                            curUser.sprite.operate(target, new Callback(){

                                @Override
                                public void call() {
                                    Level.set(target, 5);
                                    GameScene.updateMap(target);
                                    curUser.spendAndNext(1.0f);
                                    curUser.sprite.idle();
                                }
                            });
                            curUser.busy();
                            return;
                        }
                        if (Dungeon.level.map[target] == 31) {
                            if (SkeletonKey.this.charge < 5) {
                                GLog.i(Messages.get(SkeletonKey.class, "crystal_charges", new Object[0]), new Object[0]);
                                return;
                            }
                            Sample.INSTANCE.play("sounds/unlock.mp3");
                            curUser.sprite.operate(target, new Callback(){

                                @Override
                                public void call() {
                                    Buff.affect(curUser, KeyReplacementTracker.class).processCrystalLockOpened();
                                    Level.set(target, 1);
                                    GameScene.updateMap(target);
                                    SkeletonKey.this.charge -= 5;
                                    SkeletonKey.this.gainExp(7);
                                    Talent.onArtifactUsed(Dungeon.hero);
                                    Sample.INSTANCE.play("sounds/teleport.mp3");
                                    CellEmitter.get(target).start(Speck.factory(101), 0.025f, 20);
                                    curUser.spendAndNext(1.0f);
                                    curUser.sprite.idle();
                                    Notes.remove(Notes.Landmark.DISTANT_WELL, Dungeon.depth - 1);
                                }
                            });
                            curUser.busy();
                            return;
                        }
                        if (Dungeon.level.map[target] == 5 || Dungeon.level.map[target] == 6) {
                            if (SkeletonKey.this.charge < 2) {
                                GLog.i(Messages.get(SkeletonKey.class, "lock_charges", new Object[0]), new Object[0]);
                                return;
                            }
                            if (Actor.findChar(target) != null) {
                                Char toMove = Actor.findChar(target);
                                int pushCell = -1;
                                int oppositeCell = target + (target - curUser.pos);
                                if (!(Dungeon.level.solid[oppositeCell] || Actor.findChar(oppositeCell) != null || !Dungeon.level.openSpace[oppositeCell] && Char.hasProp(toMove, Char.Property.LARGE))) {
                                    pushCell = oppositeCell;
                                } else {
                                    for (int i : PathFinder.NEIGHBOURS8) {
                                        if (Dungeon.level.solid[target + i] || Actor.findChar(target + i) != null || !Dungeon.level.openSpace[target + i] && Char.hasProp(toMove, Char.Property.LARGE) || pushCell != -1 && !(Dungeon.level.trueDistance(curUser.pos, pushCell) < Dungeon.level.trueDistance(curUser.pos, target + i))) continue;
                                        pushCell = target + i;
                                    }
                                }
                                if (pushCell != -1 && !Char.hasProp(toMove, Char.Property.IMMOVABLE)) {
                                    Ballistica push = new Ballistica(target, pushCell, 7);
                                    WandOfBlastWave.throwChar(toMove, push, 1, false, false, this);
                                    Artifact.artifactProc(toMove, SkeletonKey.this.visiblyUpgraded(), 2);
                                } else {
                                    GLog.w(Messages.get(SkeletonKey.class, "lock_no_space", new Object[0]), new Object[0]);
                                    return;
                                }
                            }
                            Sample.INSTANCE.play("sounds/unlock.mp3");
                            curUser.sprite.operate(target, new Callback(){

                                @Override
                                public void call() {
                                    Level.set(target, 38);
                                    GameScene.updateMap(target);
                                    SkeletonKey.this.charge -= 2;
                                    SkeletonKey.this.gainExp(2);
                                    Talent.onArtifactUsed(Dungeon.hero);
                                    curUser.spendAndNext(1.0f);
                                    curUser.sprite.idle();
                                    if (Dungeon.level.heaps.get(target) != null) {
                                        ArrayList<Integer> candidates = new ArrayList<Integer>();
                                        for (int n : PathFinder.NEIGHBOURS8) {
                                            if (!Dungeon.level.passable[target + n]) continue;
                                            candidates.add(target + n);
                                        }
                                        if (!candidates.isEmpty()) {
                                            Heap heap = (Heap)Dungeon.level.heaps.get(target);
                                            while (!heap.isEmpty()) {
                                                Dungeon.level.drop((Item)heap.pickUp(), (int)((Integer)Random.element(candidates)).intValue()).sprite.drop(target);
                                            }
                                        }
                                    }
                                }
                            });
                            curUser.busy();
                            return;
                        }
                        if (Dungeon.level.heaps.get(target) != null && ((Heap)Dungeon.level.heaps.get((int)target.intValue())).type == Heap.Type.LOCKED_CHEST) {
                            // MOD: 强化且装在神器位时，开金锁（金箱子）也不再花充能
                            final boolean freeLock = SkeletonKey.this.enhancedAndEquipped();
                            if (!freeLock && SkeletonKey.this.charge < 2) {
                                GLog.i(Messages.get(SkeletonKey.class, "gold_charges", new Object[0]), new Object[0]);
                                return;
                            }
                            Sample.INSTANCE.play("sounds/unlock.mp3");
                            curUser.sprite.operate(target, new Callback(){

                                @Override
                                public void call() {
                                    Buff.affect(curUser, KeyReplacementTracker.class).processGoldLockOpened();
                                    ((Heap)Dungeon.level.heaps.get(target)).open(curUser);
                                    if (!freeLock) {
                                        SkeletonKey.this.charge -= 2;
                                    }
                                    SkeletonKey.this.gainExp(4);
                                    Talent.onArtifactUsed(Dungeon.hero);
                                    curUser.spendAndNext(1.0f);
                                    curUser.sprite.idle();
                                }
                            });
                            curUser.busy();
                            return;
                        }
                        if (Dungeon.level.heaps.get(target) != null && ((Heap)Dungeon.level.heaps.get((int)target.intValue())).type == Heap.Type.CRYSTAL_CHEST) {
                            if (SkeletonKey.this.charge < 5) {
                                GLog.i(Messages.get(SkeletonKey.class, "crystal_charges", new Object[0]), new Object[0]);
                                return;
                            }
                            Sample.INSTANCE.play("sounds/unlock.mp3");
                            curUser.sprite.operate(target, new Callback(){

                                @Override
                                public void call() {
                                    Buff.affect(curUser, KeyReplacementTracker.class).processCrystalLockOpened();
                                    ((Heap)Dungeon.level.heaps.get(target)).open(curUser);
                                    SkeletonKey.this.charge -= 5;
                                    SkeletonKey.this.gainExp(7);
                                    Talent.onArtifactUsed(Dungeon.hero);
                                    curUser.spendAndNext(1.0f);
                                    curUser.sprite.idle();
                                }
                            });
                            curUser.busy();
                            return;
                        }
                    }
                    if (SkeletonKey.this.charge < 2) {
                        GLog.i(Messages.get(SkeletonKey.class, "wall_charges", new Object[0]), new Object[0]);
                        return;
                    }
                    int closest = curUser.pos;
                    int closestIdx = -1;
                    for (int i = 0; i < PathFinder.CIRCLE8.length; ++i) {
                        int ofs = PathFinder.CIRCLE8[i];
                        if (!(Dungeon.level.trueDistance(target, curUser.pos + ofs) < Dungeon.level.trueDistance(target, closest))) continue;
                        closest = curUser.pos + ofs;
                        closestIdx = i;
                    }
                    final int knockBackDir = PathFinder.CIRCLE8[closestIdx];
                    if (Dungeon.level.solid[closest]) {
                        GLog.w(Messages.get(SkeletonKey.class, "invalid_target", new Object[0]), new Object[0]);
                        return;
                    }
                    final int finalClosestIdx = closestIdx;
                    Sample.INSTANCE.play("sounds/unlock.mp3");
                    curUser.sprite.operate(target, new Callback(){

                        @Override
                        public void call() {
                            SkeletonKey.this.placeWall(curUser.pos + PathFinder.CIRCLE8[finalClosestIdx], knockBackDir);
                            SkeletonKey.this.placeWall(curUser.pos + PathFinder.CIRCLE8[(finalClosestIdx + 7) % 8], knockBackDir);
                            SkeletonKey.this.placeWall(curUser.pos + PathFinder.CIRCLE8[(finalClosestIdx + 1) % 8], knockBackDir);
                            if (finalClosestIdx % 2 == 0) {
                                SkeletonKey.this.placeWall(curUser.pos + 2 * PathFinder.CIRCLE8[(finalClosestIdx + 7) % 8], knockBackDir);
                                SkeletonKey.this.placeWall(curUser.pos + 2 * PathFinder.CIRCLE8[(finalClosestIdx + 1) % 8], knockBackDir);
                            }
                            SkeletonKey.this.charge -= 2;
                            SkeletonKey.this.gainExp(2);
                            Dungeon.observe();
                            GameScene.updateFog();
                            Sample.INSTANCE.play("sounds/teleport.mp3");
                            Talent.onArtifactUsed(Dungeon.hero);
                            curUser.spendAndNext(1.0f);
                            curUser.sprite.idle();
                        }
                    });
                    curUser.busy();
                }
            }

            @Override
            public String prompt() {
                return Messages.get(SkeletonKey.class, "prompt", new Object[0]);
            }
        };
    }

    @Override
    public ArrayList<String> actions(Hero hero) {
        ArrayList<String> actions = super.actions(hero);
        if (this.isEquipped(hero) && hero.buff(MagicImmune.class) == null && !this.cursed) {
            actions.add(AC_INSERT);
        }
        // MOD: 主门 / 副门 / 换点数——**只有通过试炼、且装在神器位上**才出现在菜单里；
        // 试炼之前这把钥匙的界面和原版普通神器完全一样（只有原版的「施放」）。
        if (this.enhancedAndEquipped()) {
            actions.add(AC_MAIN_DOOR);
            actions.add(AC_SIDE_DOOR);
            actions.add(AC_TRADE);
        }
        return actions;
    }

    @Override
    public void execute(Hero hero, String action) {
        super.execute(hero, action);
        if (AC_MAIN_DOOR.equals(action)) {
            this.promptDoor(hero, true);
        } else if (AC_SIDE_DOOR.equals(action)) {
            this.promptDoor(hero, false);
        } else if (AC_TRADE.equals(action)) {
            this.tradeChargeForPoints();
        }
        if (hero.buff(MagicImmune.class) != null) {
            return;
        }
        if (action.equals(AC_INSERT)) {
            curUser = hero;
            if (!this.isEquipped(hero)) {
                GLog.i(Messages.get(Artifact.class, "need_to_equip", new Object[0]), new Object[0]);
            } else if (this.cursed) {
                GLog.w(Messages.get(this, "cursed", new Object[0]), new Object[0]);
            } else {
                GameScene.selectCell(this.targeter);
            }
        }
    }

    public void gainExp(int xpGain) {
        if (this.level() == this.levelCap) {
            return;
        }
        this.exp += xpGain;
        if (this.exp > 4 + this.level()) {
            this.exp -= 4 + this.level();
            this.upgrade();
            GLog.p(Messages.get(this, "levelup", new Object[0]), new Object[0]);
            Catalog.countUse(SkeletonKey.class);
            Dungeon.hero.trackUpgrade(this, 1);
        }
    }

    @Override
    protected Artifact.ArtifactBuff passiveBuff() {
        return new keyRecharge();
    }

    @Override
    public void charge(Hero target, float amount) {
        if (this.charge < this.chargeCap && !this.cursed && target.buff(MagicImmune.class) == null) {
            this.partialCharge += 0.133f * amount;
            while (this.partialCharge >= 1.0f) {
                this.partialCharge -= 1.0f;
                ++this.charge;
            }
            if (this.charge >= this.chargeCap) {
                this.partialCharge = 0.0f;
            }
            SkeletonKey.updateQuickslot();
        }
    }

    @Override
    public String desc() {
        String desc = super.desc();
        if (this.isEquipped(Dungeon.hero)) {
            desc = this.cursed ? (String)desc + "\n\n" + Messages.get(this, "desc_cursed", new Object[0]) : (String)desc + "\n\n" + Messages.get(this, "desc_worn", new Object[0]);
        }
        if (this.count > 0) {
            desc = (String)desc + "\n\n点数：" + this.count + "（创造主门需要 3 点）";
        }
        return desc;
    }

    /** MOD: 状态栏同时带上「点数」，例如 {@code 3/5·2} */
    @Override
    public String status() {
        String base = super.status();
        if (this.count <= 0) {
            return base;
        }
        return base == null ? ("·" + this.count) : (base + "·" + this.count);
    }

    @Override
    public Item upgrade() {
        this.chargeCap = 3 + (this.level() + 1) / 2;
        return super.upgrade();
    }

    // ===== MOD: 主门 / 副门 =====

    /** MOD: 每回合：门后那片黑保持未知 → 对齐本层的门 → 踩在门后空地上就传送 */
    public static void onHeroTurn() {
        if (Dungeon.hero == null || Dungeon.level == null) {
            return;
        }
        SkeletonKey key = Dungeon.hero.belongings == null
                ? null : Dungeon.hero.belongings.getItem(SkeletonKey.class);
        if (key != null) {
            key.adoptDoors();
            // 踩到门后那片空地就传送（Level.pressCell 只在 SECRET_TRAP/TRAP 上找陷阱，
            // 门地块上不会触发任何东西，所以每回合比对一次坐标）
            doorStepTeleport();
        }
        // 看穿原版普通门的两个条件：① 钥匙已通过试炼（强化）② 它**真的装在神器位上**
        // （只放在背包里不算）。钥匙自己造的门永远挡着。
        boolean keyEquipped = Dungeon.hero.belongings != null
                && Dungeon.hero.belongings.artifact instanceof SkeletonKey;
        if (syncVanillaDoorSight(keyEquipped && ArtifactTrial.isEnhancedClass(SkeletonKey.class))) {
            GameScene.updateMap();
            Dungeon.observe();
        }
        // 强化钥匙装在神器位时，捡到的钥匙会被它「吃掉」：铁钥匙 +1 点数、金钥匙 +2 点数
        if (key != null && key.enhancedAndEquipped()) {
            key.absorbKeys();
        }
        // 门后那格永远保持「没探索过」——连视野都抹掉，人站在里面也会被黑暗盖住。
        // 放在传送之后：落点那格当回合就黑掉，不会先亮相一帧。
        if (keepDoorsMysterious()) {
            GameScene.updateFog();
            GameScene.updateMap();
        }
    }

    /** MOD: 5 充能换 3 点数（不消耗回合） */
    private void tradeChargeForPoints() {
        if (this.charge < 5) {
            GLog.w("充能不够。要 5 点，你有 " + this.charge + "。");
            return;
        }
        this.charge -= 5;
        this.count += 3;
        GLog.p("充能 -5，点数 +3。");
        Item.updateQuickslot();
    }

    /**
     * MOD: 强化钥匙的「吃钥匙」逻辑（只在强化 + 装在神器位时生效）。
     * 铁钥匙 → 点数 +1；金钥匙 → 点数 +2；水晶钥匙 → 问一句要不要换 5 点点数。
     */
    private void absorbKeys() {
        Hero hero = Dungeon.hero;
        if (hero == null || hero.belongings == null) {
            return;
        }
        // 调试：强化状态只在变化时记一行
        boolean enh = this.enhancedAndEquipped();
        if (loggedEnhanced == null || loggedEnhanced != enh) {
            loggedEnhanced = enh;
            keyLog("[state] enhancedAndEquipped=" + enh
                    + " artifact=" + (hero.belongings.artifact == null ? "null" : hero.belongings.artifact.getClass().getSimpleName())
                    + " challengeArtifact=" + Dungeon.isChallenged(com.shatteredpixel.shatteredpixeldungeon.Challenges.ARTIFACT));
        }
        int gained = 0;       // 吃掉的钥匙把数
        int gainedCount = 0;  // 换到的点数

        // ① 原版钥匙根本不会进背包：Key.doPickUp() 只调用 Notes.add()。
        //    所以用「本层钥匙计数变多」来判断刚捡到了什么。
        int depth = Dungeon.depth;
        int iron = Notes.keyCount(new IronKey(depth));
        int gold = Notes.keyCount(new GoldenKey(depth));
        int crystal = Notes.keyCount(new CrystalKey(depth));
        if (depth != lastKeyDepth) {
            // 换层：先记基线，别把这一层的钥匙当成「刚捡的」
            lastKeyDepth = depth;
            lastIron = iron;
            lastGold = gold;
            lastCrystal = crystal;
        } else {
            int dIron = Math.max(0, iron - lastIron);
            int dGold = Math.max(0, gold - lastGold);
            int dCrystal = Math.max(0, crystal - lastCrystal);
            lastIron = iron;
            lastGold = gold;
            lastCrystal = crystal;

            for (int i = 0; i < dIron; i++) {
                Notes.remove(new IronKey(depth));
            }
            if (dIron > 0) {
                this.count += dIron;
                gained += dIron;
                gainedCount += dIron;
            }
            for (int i = 0; i < dGold; i++) {
                Notes.remove(new GoldenKey(depth));
            }
            if (dGold > 0) {
                this.count += 2 * dGold;
                gained += dGold;
                gainedCount += 2 * dGold;
            }
            if (dIron > 0 || dGold > 0 || dCrystal > 0) {
                keyLog("[delta] depth=" + depth + " iron+" + dIron + " gold+" + dGold + " crystal+" + dCrystal);
            }
            if (dCrystal > 0) {
                promptCrystalKey(depth);
            }
        }

        // ② 测试魔盒之类「直接塞进背包」的钥匙（这类不进 Notes）
        try {
            for (IronKey k : new ArrayList<>(hero.belongings.getAllItems(IronKey.class))) {
                k.detachAll(hero.belongings.backpack);
                this.count += 1;
                gained++;
                gainedCount += 1;
            }
            for (GoldenKey k : new ArrayList<>(hero.belongings.getAllItems(GoldenKey.class))) {
                k.detachAll(hero.belongings.backpack);
                this.count += 2;
                gained++;
                gainedCount += 2;
            }
        } catch (Throwable ignored) {
            // 别让吃钥匙影响后面的视野/黑暗维护
        }

        if (gained > 0) {
            GameScene.updateKeyDisplay();
            GLog.i("钥匙吞了 " + gained + " 把，点数 +" + gainedCount + "。");
            SkeletonKey.updateQuickslot();
        }
    }

    /** 本层上一次看到的三类钥匙数量（用来检测「刚捡到钥匙」） */
    private static int lastKeyDepth = -1;
    private static int lastIron = 0;
    private static int lastGold = 0;
    private static int lastCrystal = 0;

    /** 调试日志：只在状态变化 / 检测到钥匙时写，正常游玩不会刷屏 */
    private static Boolean loggedEnhanced = null;

    private static void keyLog(String line) {
        try {
            com.watabou.utils.FileUtils.getFileHandle("skeleton_key_debug.txt")
                    .writeString(line + "\n", true, "UTF-8");
        } catch (Throwable ignored) {
        }
    }

    /** MOD: 问一句要不要用一把水晶钥匙换 5 点点数（水晶钥匙记在 Notes 里） */
    private void promptCrystalKey(final int depth) {
        final SkeletonKey self = this;
        Game.runOnRenderThread(new Callback() {
            @Override
            public void call() {
                GameScene.show(new WndOptions(new ItemSprite(self), "骷髅钥匙",
                        "用一把水晶钥匙换 5 点点数？", "换", "不换") {
                    @Override
                    protected void onSelect(int index) {
                        if (index != 0) {
                            return;
                        }
                        if (Notes.keyCount(new CrystalKey(depth)) <= 0) {
                            return;
                        }
                        Notes.remove(new CrystalKey(depth));
                        self.count += 5;
                        lastCrystal = Math.max(0, lastCrystal - 1);
                        GameScene.updateKeyDisplay();
                        GLog.p("点数 +5。");
                        SkeletonKey.updateQuickslot();
                    }
                });
            }
        });
    }

    /**
     * MOD: 带着钥匙时，**原版生成的门**不再挡视线。
     * 只动 {@code Terrain.DOOR} / {@code LOCKED_DOOR} 这两种普通门，而且跳过钥匙自己造的门
     * （主门 / 副门后面那片黑暗是给钥匙看的，不该被普通视野提前点亮）。
     * 返回是否真的改动过。
     */
    private static boolean syncVanillaDoorSight(boolean hasKey) {
        DoorTilemap main = findDoor(true);
        DoorTilemap side = findDoor(false);
        int mainCell = main == null ? -1 : main.cell;
        int sideCell = side == null ? -1 : side.cell;
        boolean changed = false;
        for (int cell = 0; cell < Dungeon.level.length(); cell++) {
            int terrain = Dungeon.level.map[cell];
            if (terrain != Terrain.DOOR && terrain != Terrain.LOCKED_DOOR) {
                continue;
            }
            if (cell == mainCell || cell == sideCell) {
                continue;            // 自己造的门：保持挡视线
            }
            boolean blocked = !hasKey;
            if (Dungeon.level.losBlocking[cell] != blocked) {
                Dungeon.level.losBlocking[cell] = blocked;
                changed = true;
            }
        }
        return changed;
    }

    /** 记录刚传送到的格子，避免两扇门之间来回弹（旧版「踩门传送」遗留） */
    private static int arrivedAt = -1;

    /** 主门 ↔ 副门 互相传送（每回合的坐标比对 + 旧的陷阱触发器共用） */
    public static void doorStepTeleport() {
        if (Dungeon.hero == null || Dungeon.level == null || Dungeon.hero.belongings == null) {
            return;
        }
        SkeletonKey key = Dungeon.hero.belongings.getItem(SkeletonKey.class);
        if (key == null) {
            return;
        }
        if (key.mainDepth != Dungeon.depth || key.sideDepth != Dungeon.depth) {
            return;
        }
        if (key.mainPos < 0 || key.sidePos < 0) {
            return;
        }
        int here = Dungeon.hero.pos;
        if (here == arrivedAt) {
            return;   // 刚落地还没走开，别再弹回去
        }
        DoorTilemap mainDoor = findDoor(true);
        DoorTilemap sideDoor = findDoor(false);
        // 触发点是**门后那格空地**（门只是门面），站在门格上不传送
        int mainEntry = entryCell(mainDoor, key.mainPos);
        int sideEntry = entryCell(sideDoor, key.sidePos);
        int dest;
        if (here == sideEntry) {
            dest = key.mainPos;
        } else if (here == mainEntry) {
            dest = key.sidePos;
        } else {
            arrivedAt = -1;
            return;
        }
        // 落到对面门**后面那格空地**（和触发点对称：门只是门面，黑洞才是传送面）。
        // 那格被占 / 不可站就退回门格，再不行退到门旁边。
        DoorTilemap destDoor = findDoor(dest == key.mainPos);
        int landing = entryCell(destDoor, dest);
        boolean entryFree = landing >= 0 && landing < Dungeon.level.length()
                && Dungeon.level.passable[landing] && Actor.findChar(landing) == null;
        if (!entryFree) {
            landing = doorLanding(dest);
        }
        if (landing == -1) {
            GLog.w("另一头被堵住了，门没走成。");
            return;
        }
        // MOD: 自己搬人，不走 ScrollOfTeleportation.teleportToLocation()
        // ——那条路会放白光粒子 + teleport.mp3，作者要静悄悄过去。
        Hero hero = Dungeon.hero;
        hero.sprite.interruptMotion();
        hero.move(landing, false);               // travelling=false：不走「位移」那套，纯粹改坐标
        hero.sprite.interruptMotion();
        hero.sprite.place(landing);
        hero.sprite.idle();
        // 万一落点还是门格（门后那格被占了），就顺手把门打开
        if (Dungeon.level.map[landing] == Terrain.DOOR || Dungeon.level.map[landing] == Terrain.LOCKED_DOOR) {
            Dungeon.level.set(landing, Terrain.OPEN_DOOR);
            GameScene.updateMap(landing);
        }
        // 两扇门里还开着的都关回去（人是被传走的，不会走 Char.move 的 Door.leave）
        for (DoorTilemap d : new DoorTilemap[]{mainDoor, sideDoor}) {
            if (d != null && d.cell >= 0 && d.cell < Dungeon.level.length()
                    && Dungeon.level.map[d.cell] == Terrain.OPEN_DOOR) {
                Level.set(d.cell, Terrain.DOOR);
            }
        }
        GameScene.updateMap();
        arrivedAt = landing;
        hero.interrupt();
        hero.curAction = null;
        // MOD: 传送要花两回合（世界照常走两步）
        Actor.delayChar(hero, 2f);
        // MOD: 传送的代价——虚弱至少 6 回合（本来更多就不削）
        Buff.prolong(hero, Weakness.class, 6f);
        Dungeon.observe();
        GLog.p(pickTeleportLine());
    }

    /** MOD: 传送提示词库——随机挑一句，且不会连着两次重复 */
    private static final String[] TELEPORT_LINES = {
            "你在黑暗中摸索着，找到了另一扇门。",
            "你穿过了无边的黑暗，终点是另一扇门。",
            "就在你以为自己将要迷失时，你发现了另一扇门。",
            "风声在你耳边停下的地方，立着另一扇门。",
            "黑暗的尽头是一扇温暖的木门，从门缝中挤出几缕令人怀念的光",
    };
    private static int lastTeleportLine = -1;

    /** 连续传送（短时间内又传一次）时用的沉默提示 */
    private static int teleportChain = 0;
    private static float lastTeleportAt = -1000f;
    /** 链内连续传送超过这个时间（秒）就重新算一条新链 */
    private static final float CHAIN_GAP = 6f;
    private static boolean lastLineWasCold = false;

    private static String pickTeleportLine() {
        if (Actor.now() - lastTeleportAt > CHAIN_GAP) {
            teleportChain = 1;                       // 隔了一阵子，算新的一条链
        } else {
            teleportChain++;
        }
        lastTeleportAt = Actor.now();

        if (teleportChain == 1) {
            int i = Random.Int(TELEPORT_LINES.length);
            if (TELEPORT_LINES.length > 1) {
                while (i == lastTeleportLine) {
                    i = Random.Int(TELEPORT_LINES.length);
                }
            }
            lastTeleportLine = i;
            return TELEPORT_LINES[i];
        }
        if (teleportChain == 2) {
            return "你转头回到了黑暗中……";
        }
        if (teleportChain == 3) {
            return "……风声呼啸";
        }
        // 再往后基本只是「……」，偶尔冷一下
        if (!lastLineWasCold && Random.Int(5) == 0) {
            lastLineWasCold = true;
            return "你感到有点冷……";
        }
        lastLineWasCold = false;
        return "……";
    }

    @Override
    public String actionName(String action, Hero hero) {
        if (AC_MAIN_DOOR.equals(action)) {
            return "创造主门（3 点数）";
        }
        if (AC_SIDE_DOOR.equals(action)) {
            return "创造副门";
        }
        if (AC_TRADE.equals(action)) {
            return "5 充能换 3 点数";
        }
        return super.actionName(action, hero);
    }

    // ===== MOD: 在墙上开门（打通成能走进去的门洞） =====

    private void promptDoor(final Hero hero, final boolean main) {
        GameScene.selectCell(new CellSelector.Listener() {
            @Override
            public void onSelect(Integer cell) {
                if (cell != null) {
                    createDoor(hero, cell, main);
                }
            }

            @Override
            public String prompt() {
                return main ? "选一堵墙，把主门开在那里" : "选一堵墙，把副门开在那里";
            }
        });
    }

    private static boolean isWall(int cell) {
        if (cell < 0 || cell >= Dungeon.level.length()) {
            return false;
        }
        int t = Dungeon.level.map[cell];
        return t == Terrain.WALL || t == Terrain.WALL_DECO;
    }

    /** MOD: 这堵墙周围一圈有几格是空地（老规矩：正好 3 格才开得出门） */
    private static int openNeighbours(int cell) {
        int open = 0;
        for (int i : PathFinder.NEIGHBOURS8) {
            int c = cell + i;
            if (c >= 0 && c < Dungeon.level.length() && Dungeon.level.passable[c]) {
                open++;
            }
        }
        return open;
    }

    /**
     * MOD: 这格周围八方向里有几格**不是墙**（越界 / 地图外算封死）。
     * 用来判断门后那片「未知的黑暗」是不是一个死膛——只要通着真实地面，
     * 黑暗就会漏出去，那扇门也不该开得出来。
     */
    private static int notWallAround(int cell) {
        int w = Dungeon.level.width();
        int h = Dungeon.level.height();
        int x = cell % w;
        int y = cell / w;
        int open = 0;
        for (int dy = -1; dy <= 1; dy++) {
            for (int dx = -1; dx <= 1; dx++) {
                if (dx == 0 && dy == 0) {
                    continue;
                }
                int nx = x + dx;
                int ny = y + dy;
                if (nx < 0 || ny < 0 || nx >= w || ny >= h) {
                    continue;               // 地图外，当成墙
                }
                if (!isWall(ny * w + nx)) {
                    open++;
                }
            }
        }
        return open;
    }

    /** MOD: 本层某扇门的贴图（main = 主门 / 副门） */
    private static DoorTilemap findDoor(boolean main) {
        if (Dungeon.level == null || Dungeon.level.customTiles == null) {
            return null;
        }
        for (CustomTilemap t : Dungeon.level.customTiles) {
            if (t instanceof DoorTilemap && ((DoorTilemap) t).main == main) {
                return (DoorTilemap) t;
            }
        }
        return null;
    }

    /**
     * MOD: 把门格的地块调成和朝向匹配的那种，老存档顺手修一遍：
     * 门格永远用 {@code Terrain.DOOR}（引擎会按朝向自己画完整的一扇门）。
     */
    private static void carveDoorway(DoorTilemap door) {
        if (door == null || door.cell < 0 || door.cell >= Dungeon.level.length()) {
            return;
        }
        int want = DoorTilemap.terrainFor(door.cell);
        if (Dungeon.level.map[door.cell] != want) {
            Level.set(door.cell, want);            // Level.set 会顺手清掉那格的陷阱
            GameScene.updateMap();                 // 墙面拼接跟着变，整张图重算一次
        }
    }

    /** MOD: 换层 / 读档之后，把坐标对齐到本层真正存在的门 */
    private void adoptDoors() {
        if (this.claimedDepth == Dungeon.depth) {
            return;
        }
        this.claimedDepth = Dungeon.depth;
        DoorTilemap main = findDoor(true);
        DoorTilemap side = findDoor(false);
        carveDoorway(main);
        carveDoorway(side);
        ensureVoid(main);
        ensureVoid(side);
        this.mainPos = main == null ? -1 : main.cell;
        this.mainDepth = main == null ? -1 : Dungeon.depth;
        this.sidePos = side == null ? -1 : side.cell;
        this.sideDepth = side == null ? -1 : Dungeon.depth;
        if (main != null || side != null) {
            GameScene.updateMap();
        }
    }

    /**
     * MOD: 把门开到墙上。
     * 那堵墙变成真正的 {@code Terrain.DOOR}：可通行，引擎按朝向自己画完整的一扇门
     * （横排墙 112+224，竖排墙 227+116+212）。地块之外的东西一律不动，墙面拼接才不会被破坏。
     * 传送不用陷阱：{@code Level.pressCell} 只在 SECRET_TRAP/TRAP 上找陷阱，
     * 所以走进去之后由 {@code onHeroTurn()} 按坐标比对完成传送。
     */
    private DoorTilemap mountDoor(int cell, boolean main) {
        if (Dungeon.level.customTiles == null) {
            Dungeon.level.customTiles = new ArrayList<CustomTilemap>();
        }
        DoorTilemap old = findDoor(main);
        if (old != null) {
            Dungeon.level.customTiles.remove(old);
            old.dispose();
            // 旧门洞砌回去，别在墙上留个窟窿
            if (old.cell >= 0 && old.cell < Dungeon.level.length()
                    && (Dungeon.level.map[old.cell] == Terrain.DOOR
                        || Dungeon.level.map[old.cell] == Terrain.OPEN_DOOR
                        || Dungeon.level.map[old.cell] == Terrain.EMPTY)) {
                Level.set(old.cell, old.cellTerrain >= 0 ? old.cellTerrain : Terrain.WALL);
            }
            // 门另一侧那格也还原（原本是岩就砌回岩）
            if (old.beyond >= 0 && old.beyond < Dungeon.level.length() && old.beyondTerrain >= 0) {
                Level.set(old.beyond, old.beyondTerrain);
            }
            dropVoid(old.beyond);
        }
        // 门格就是真正的门地块：可通行，贴图交给引擎
        int cellTerrain = Dungeon.level.map[cell];
        Level.set(cell, DoorTilemap.terrainFor(cell));

        DoorTilemap door = new DoorTilemap(cell, main, Dungeon.level);
        door.cellTerrain = cellTerrain;
        Dungeon.level.customTiles.add(door);
        GameScene.add(door, false);          // customTiles 层（现在不画东西，留着给检视用）
        GameScene.updateMap();               // 地块变了，整张图重算
        CellEmitter.get(cell).start(Speck.factory(101), 0.04f, 12);
        return door;
    }

    private void createDoor(Hero hero, int cell, boolean main) {
        if (cell < 0 || cell >= Dungeon.level.length()) {
            return;
        }
        if (!Dungeon.level.adjacent(hero.pos, cell)) {
            GLog.w("门只能开在身边的墙上。");
            return;
        }
        if (!isWall(cell)) {
            GLog.w("这不是一堵墙。");
            return;
        }
        int open = openNeighbours(cell);
        if (open != 3) {
            GLog.w("这面墙旁边有 " + open + " 格空地。得正好 3 格。");
            return;
        }
        // MOD: 门后那片「未知的黑暗」必须是死膛——周围八方向全是墙，通不到真实地面
        int beyond = cell + (cell - hero.pos);
        if (beyond < 0 || beyond >= Dungeon.level.length() || beyond == cell) {
            GLog.w("门后是地图边缘，开不出来。");
            return;
        }
        int behindOpen = notWallAround(beyond);
        if (behindOpen != 0) {
            GLog.w("「门后漏光。」钥匙不肯动，得找堵更厚的墙。");
            return;
        }
        if (main) {
            // MOD: 主门不再花充能，改用独立的「点数」
            if (this.count < 3) {
                GLog.w("点数不够。要 3 点，你有 " + this.count + "。");
                return;
            }
            if (findDoor(true) != null) {
                // 本层已经有一扇主门：先问一句，确认了才花点数重建
                final Hero h = hero;
                final int c = cell;
                final SkeletonKey self = this;
                Game.runOnRenderThread(new Callback() {
                    @Override
                    public void call() {
                        GameScene.show(new WndOptions(new ItemSprite(self),
                                "骷髅钥匙", "本层已经有一扇主门了，是否花费 3 点重新创造？",
                                "重新创造", "算了") {
                            @Override
                            protected void onSelect(int index) {
                                if (index == 0 && self.count >= 3) {
                                    self.count -= 3;
                                    self.finishDoor(h, c, true);
                                }
                            }
                        });
                    }
                });
                return;
            }
            this.count -= 3;
            finishDoor(hero, cell, true);
        } else {
            finishDoor(hero, cell, false);
        }
    }

    /** 真正把门立起来（主门 / 副门共用）：记账 → 建门 → 刨门后那格 → 结束回合 */
    private void finishDoor(Hero hero, int cell, boolean main) {
        if (main) {
            this.mainPos = cell;
            this.mainDepth = Dungeon.depth;
        } else {
            this.sidePos = cell;
            this.sideDepth = Dungeon.depth;
        }
        DoorTilemap door = mountDoor(cell, main);
        GLog.p(main
                ? "钥匙开了主门。走进去会到副门。"
                : "钥匙开了副门。走进去会到主门。");
        carveBeyond(hero, cell, door);
        hero.sprite.operate(hero.pos);
        hero.spend(1.0f);
        Item.updateQuickslot();
    }

    /**
     * MOD: 把门**另一侧**那格也刨成空地，形成「玩家 / 门 / 空地」三明治——
     * 否则门背后多半是实心岩，开出来的门看着像通不了。
     */
    private static void carveBeyond(Hero hero, int cell, DoorTilemap door) {
        int beyond = cell + (cell - hero.pos);
        if (beyond < 0 || beyond >= Dungeon.level.length() || beyond == cell) {
            return;
        }
        if (door != null) {
            door.beyond = beyond;
            door.beyondTerrain = Dungeon.level.map[beyond];
        }
        Level.set(beyond, Terrain.EMPTY);        // Level.set 会顺手清掉那格的陷阱
        Dungeon.level.plants.remove(beyond);
        GameScene.updateMap();                   // 墙面拼接跟着变，整张图重算
        // 故意不调 Dungeon.observe()：新挖开的那格不进 visited，就一直黑着——
        // 看起来像门后连着一片未知空间（作者要的效果）
        if (door != null) {
            ensureVoid(door);                    // 检视那格时显示「未知的黑暗」
        }
    }

    /** MOD: 保证门后那格有「未知的黑暗」的检视贴图（老存档 / 刚挖开时可能还没有） */
    private static void ensureVoid(DoorTilemap door) {
        if (door == null || door.beyond < 0 || door.beyond >= Dungeon.level.length()) {
            return;
        }
        if (Dungeon.level.customTiles == null) {
            Dungeon.level.customTiles = new ArrayList<CustomTilemap>();
        }
        for (CustomTilemap t : Dungeon.level.customTiles) {
            if (t instanceof DoorVoidTilemap && ((DoorVoidTilemap) t).cell == door.beyond) {
                return;
            }
        }
        DoorVoidTilemap voidTile = new DoorVoidTilemap(door.beyond, Dungeon.level);
        Dungeon.level.customTiles.add(voidTile);
        GameScene.add(voidTile, false);
    }

    /** MOD: 拆门时把门后那格的检视贴图摘掉 */
    private static void dropVoid(int cell) {
        if (Dungeon.level.customTiles == null) {
            return;
        }
        for (CustomTilemap t : new ArrayList<CustomTilemap>(Dungeon.level.customTiles)) {
            if (t instanceof DoorVoidTilemap && ((DoorVoidTilemap) t).cell == cell) {
                Dungeon.level.customTiles.remove(t);
                ((DoorVoidTilemap) t).dispose();
            }
        }
    }

    /**
     * MOD: 把门后那格的「已探索」和视野都抹掉；返回是否真的改动过。
     * 抹掉 heroFOV 是关键：人站在里面时这格本来算「看得见」，雾会散开；
     * 抹掉之后迷雾重新盖上去，连自己都看不见——就是「看不破的黑暗」。
     * 注意：钥匙的「看穿普通门」不会动到它，那格永远黑着。
     */
    private static boolean keepDoorsMysterious() {
        boolean changed = false;
        for (DoorTilemap door : new DoorTilemap[]{findDoor(true), findDoor(false)}) {
            if (door == null || door.beyond < 0 || door.beyond >= Dungeon.level.length()) {
                continue;
            }
            int beyond = door.beyond;
            if (Dungeon.level.heroFOV[beyond]) {
                Dungeon.level.heroFOV[beyond] = false;   // 站在里面也不点亮
                changed = true;
            }
            // 让它「可检视」：GameScene.examineCell() 要求 visited 或 mapped，
            // 两样都空的话点上去什么都不会发生。
            if (!Dungeon.level.visited[beyond]) {
                Dungeon.level.visited[beyond] = true;
                changed = true;
            }
            // 但 discoverable=false 会让迷雾永远画成最黑那一档——看得见文案，看不见里面
            if (Dungeon.level.discoverable[beyond]) {
                Dungeon.level.discoverable[beyond] = false;
                changed = true;
            }
            if (Dungeon.level.mapped[beyond]) {
                Dungeon.level.mapped[beyond] = false;
                changed = true;
            }
        }
        return changed;
    }

    /** MOD: 这扇门的「入口」= 门后那格空地；老存档没记 beyond 时退回门格本身 */
    private static int entryCell(DoorTilemap door, int fallback) {
        if (door != null && door.beyond >= 0) {
            return door.beyond;
        }
        return fallback;
    }

    /** 落点：优先门格本身（门会为你打开，人在门洞里），门格被占才退到旁边 */
    private static int doorLanding(int door) {
        if (door < 0 || door >= Dungeon.level.length()) {
            return -1;
        }
        if (Dungeon.level.passable[door] && Actor.findChar(door) == null) {
            return door;
        }
        return landingCell(door);
    }

    /** 门旁边那一格空地（先找正前方，再退到斜角） */
    private static int landingCell(int door) {
        for (int pass = 0; pass < 2; pass++) {
            int best = -1;
            float bestDist = Float.MAX_VALUE;
            for (int i : pass == 0 ? PathFinder.NEIGHBOURS4 : PathFinder.NEIGHBOURS8) {
                int c = door + i;
                if (c < 0 || c >= Dungeon.level.length()) continue;
                if (!Dungeon.level.passable[c]) continue;
                if (Actor.findChar(c) != null) continue;
                float d = Dungeon.hero == null ? 0 : Dungeon.level.trueDistance(Dungeon.hero.pos, c);
                if (d < bestDist) {
                    bestDist = d;
                    best = c;
                }
            }
            if (best != -1) {
                return best;
            }
        }
        return -1;
    }

    private void placeWall(int pos, int knockbackDIR) {
        Blob wall = Dungeon.level.blobs.get(KeyWall.class);
        if (!Dungeon.level.solid[pos] || wall != null && wall.cur[pos] > 0) {
            GameScene.add(Blob.seed(pos, 10, KeyWall.class));
            Char ch = Actor.findChar(pos);
            if (ch != null && ch.alignment == Char.Alignment.ENEMY) {
                WandOfBlastWave.throwChar(ch, new Ballistica(pos, pos + knockbackDIR, 7), 1, false, false, this);
                SkeletonKey.artifactProc(ch, this.visiblyUpgraded(), 2);
            }
        }
    }

    public class keyRecharge
    extends Artifact.ArtifactBuff {
        public keyRecharge() {
            super();
        }

        @Override
        public boolean act() {
            if (SkeletonKey.this.charge < SkeletonKey.this.chargeCap && !SkeletonKey.this.cursed && this.target.buff(MagicImmune.class) == null && Regeneration.regenOn()) {
                float chargeGain = 1.0f / (120.0f - (float)(SkeletonKey.this.chargeCap - SkeletonKey.this.charge) * 7.5f);
                SkeletonKey.this.partialCharge += (chargeGain *= RingOfEnergy.artifactChargeMultiplier(this.target));
                while (SkeletonKey.this.partialCharge >= 1.0f) {
                    SkeletonKey.this.partialCharge -= 1.0f;
                    ++SkeletonKey.this.charge;
                    if (SkeletonKey.this.charge != SkeletonKey.this.chargeCap) continue;
                    SkeletonKey.this.partialCharge = 0.0f;
                }
            }
            Item.updateQuickslot();
            this.spend(1.0f);
            return true;
        }
    }

    public static class KeyWall
    extends Blob {
        public KeyWall() {
            this.alwaysVisible = true;
        }

        @Override
        protected void evolve() {
            boolean cellEnded = false;
            Level l = Dungeon.level;
            for (int i = this.area.left; i < this.area.right; ++i) {
                for (int j = this.area.top; j < this.area.bottom; ++j) {
                    int cell = i + j * l.width();
                    int n = this.off[cell] = this.cur[cell] > 0 ? this.cur[cell] - 1 : 0;
                    if (this.cur[cell] > 0 && this.off[cell] == 0) {
                        cellEnded = true;
                    }
                    this.off[cell] = Math.min(this.off[cell], 9);
                    this.volume += this.off[cell];
                    if (this.off[cell] != 0 || this.cur[cell] <= 0) continue;
                    this.cellsToFlagUpdate.add(cell);
                }
            }
            if (cellEnded) {
                Dungeon.observe();
            }
        }

        @Override
        public void seed(Level level, int cell, int amount) {
            super.seed(level, cell, amount);
            level.updateCellFlags(cell);
        }

        @Override
        public void clear(int cell) {
            super.clear(cell);
            if (this.cur == null) {
                return;
            }
            Dungeon.level.updateCellFlags(cell);
        }

        @Override
        public void fullyClear() {
            super.fullyClear();
            Dungeon.level.buildFlagMaps();
        }

        @Override
        public void onBuildFlagMaps(Level l) {
            if (this.volume > 0) {
                for (int i = 0; i < l.length(); ++i) {
                    this.onUpdateCellFlags(l, i);
                }
            }
        }

        @Override
        public void onUpdateCellFlags(Level l, int cell) {
            if (this.volume > 0 && this.cur[cell] > 0) {
                l.losBlocking[cell] = true;
                l.solid[cell] = true;
                l.passable[cell] = false;
                l.avoid[cell] = false;
            }
        }

        @Override
        public void use(BlobEmitter emitter) {
            super.use(emitter);
            emitter.pour(SpectralWallParticle.FACTORY, 0.05f);
        }

        @Override
        public String tileDesc() {
            return Messages.get(this, "desc", new Object[0]);
        }
    }

    @Override
    public void storeInBundle(Bundle bundle) {
        super.storeInBundle(bundle);
        bundle.put(COUNT, this.count);
    }

    @Override
    public void restoreFromBundle(Bundle bundle) {
        super.restoreFromBundle(bundle);
        this.count = bundle.getInt(COUNT);
    }

    public static class KeyReplacementTracker
    extends Buff {
        public int[] ironKeysNeeded;
        public int[] goldenKeysNeeded;
        public int[] crystalKeysNeeded;
        public static String IRON_NEEDED = "iron_needed";
        public static String GOLDEN_NEEDED = "golden_needed";
        public static String CRYSTAL_NEEDED = "crystal_needed";

        public KeyReplacementTracker() {
            this.revivePersists = true;
            this.ironKeysNeeded = new int[26];
            Arrays.fill(this.ironKeysNeeded, -1);
            this.goldenKeysNeeded = new int[26];
            Arrays.fill(this.goldenKeysNeeded, -1);
            this.crystalKeysNeeded = new int[26];
            Arrays.fill(this.crystalKeysNeeded, -1);
        }

        public void setupKeysForDepth() {
            this.ironKeysNeeded[Dungeon.depth] = 0;
            this.goldenKeysNeeded[Dungeon.depth] = 0;
            this.crystalKeysNeeded[Dungeon.depth] = 0;
            for (Heap h : Dungeon.level.heaps.valueList()) {
                if (h.type == Heap.Type.LOCKED_CHEST) {
                    int n = Dungeon.depth;
                    this.goldenKeysNeeded[n] = this.goldenKeysNeeded[n] + 1;
                    continue;
                }
                if (h.type != Heap.Type.CRYSTAL_CHEST) continue;
                int n = Dungeon.depth;
                this.crystalKeysNeeded[n] = this.crystalKeysNeeded[n] + 1;
            }
            for (int i = 0; i < Dungeon.level.length(); ++i) {
                if (Dungeon.level.map[i] == 10) {
                    int n = Dungeon.depth;
                    this.ironKeysNeeded[n] = this.ironKeysNeeded[n] + 1;
                    continue;
                }
                if (Dungeon.level.map[i] != 31) continue;
                int n = Dungeon.depth;
                this.crystalKeysNeeded[n] = this.crystalKeysNeeded[n] + 1;
            }
        }

        public void clearDepth() {
            this.ironKeysNeeded[Dungeon.depth] = -1;
            this.goldenKeysNeeded[Dungeon.depth] = -1;
            this.crystalKeysNeeded[Dungeon.depth] = -1;
        }

        public void processIronLockOpened() {
            if (this.ironKeysNeeded[Dungeon.depth] == -1) {
                this.setupKeysForDepth();
            }
            int n = Dungeon.depth;
            this.ironKeysNeeded[n] = this.ironKeysNeeded[n] - 1;
            this.processExcessKeys();
        }

        public void processGoldLockOpened() {
            if (this.goldenKeysNeeded[Dungeon.depth] == -1) {
                this.setupKeysForDepth();
            }
            int n = Dungeon.depth;
            this.goldenKeysNeeded[n] = this.goldenKeysNeeded[n] - 1;
            this.processExcessKeys();
        }

        public void processCrystalLockOpened() {
            if (this.crystalKeysNeeded[Dungeon.depth] == -1) {
                this.setupKeysForDepth();
            }
            int n = Dungeon.depth;
            this.crystalKeysNeeded[n] = this.crystalKeysNeeded[n] - 1;
            this.processExcessKeys();
        }

        public void processExcessKeys() {
            int keysNeeded = this.ironKeysNeeded[Dungeon.depth];
            boolean removed = false;
            if (keysNeeded >= 0) {
                while (Notes.keyCount(new IronKey(Dungeon.depth)) > keysNeeded) {
                    Notes.remove(new IronKey(Dungeon.depth));
                    removed = true;
                }
            }
            if ((keysNeeded = this.goldenKeysNeeded[Dungeon.depth]) >= 0) {
                while (Notes.keyCount(new GoldenKey(Dungeon.depth)) > keysNeeded) {
                    Notes.remove(new GoldenKey(Dungeon.depth));
                    removed = true;
                }
            }
            if ((keysNeeded = this.crystalKeysNeeded[Dungeon.depth]) >= 0) {
                while (Notes.keyCount(new CrystalKey(Dungeon.depth)) > keysNeeded) {
                    Notes.remove(new CrystalKey(Dungeon.depth));
                    removed = true;
                }
            }
            if (removed) {
                GameScene.updateKeyDisplay();
                GLog.i(Messages.get(SkeletonKey.class, "discard", new Object[0]), new Object[0]);
            }
        }

        @Override
        public void storeInBundle(Bundle bundle) {
            super.storeInBundle(bundle);
            bundle.put(IRON_NEEDED, this.ironKeysNeeded);
            bundle.put(GOLDEN_NEEDED, this.goldenKeysNeeded);
            bundle.put(CRYSTAL_NEEDED, this.crystalKeysNeeded);
        }

        @Override
        public void restoreFromBundle(Bundle bundle) {
            super.restoreFromBundle(bundle);
            this.ironKeysNeeded = bundle.getIntArray(IRON_NEEDED);
            this.goldenKeysNeeded = bundle.getIntArray(GOLDEN_NEEDED);
            this.crystalKeysNeeded = bundle.getIntArray(CRYSTAL_NEEDED);
        }
    }
}
