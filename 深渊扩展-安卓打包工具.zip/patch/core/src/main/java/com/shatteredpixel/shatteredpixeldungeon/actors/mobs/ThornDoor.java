package com.shatteredpixel.shatteredpixeldungeon.actors.mobs;

import com.shatteredpixel.shatteredpixeldungeon.Challenges;
import com.shatteredpixel.shatteredpixeldungeon.Dungeon;
import com.shatteredpixel.shatteredpixeldungeon.actors.Actor;
import com.shatteredpixel.shatteredpixeldungeon.actors.Char;
import com.shatteredpixel.shatteredpixeldungeon.actors.blobs.Blob;
import com.shatteredpixel.shatteredpixeldungeon.actors.blobs.Fire;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.Buff;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.ThornsMark;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.Vertigo;
import com.shatteredpixel.shatteredpixeldungeon.actors.hero.Hero;
import com.shatteredpixel.shatteredpixeldungeon.actors.mobs.npcs.NPC;
import com.shatteredpixel.shatteredpixeldungeon.effects.CellEmitter;
import com.shatteredpixel.shatteredpixeldungeon.effects.Speck;
import com.shatteredpixel.shatteredpixeldungeon.items.Heap;
import com.shatteredpixel.shatteredpixeldungeon.items.Item;
import com.shatteredpixel.shatteredpixeldungeon.items.bombs.Bomb;
import com.shatteredpixel.shatteredpixeldungeon.items.wands.WandOfBlastWave;
import com.shatteredpixel.shatteredpixeldungeon.items.weapon.missiles.MissileWeapon;
import com.shatteredpixel.shatteredpixeldungeon.levels.Level;
import com.shatteredpixel.shatteredpixeldungeon.levels.Terrain;
import com.shatteredpixel.shatteredpixeldungeon.scenes.GameScene;
import com.shatteredpixel.shatteredpixeldungeon.sprites.ThornDoorSprite;
import com.shatteredpixel.shatteredpixeldungeon.utils.GLog;
import com.watabou.utils.Bundle;
import com.watabou.utils.PathFinder;
import com.watabou.utils.Random;

import java.util.ArrayList;

/**
 * MOD: 「荆棘丛生」挑战里的**被荆棘缠绕的木门**。
 *
 * 它不是一个拦路的敌人，而是站在门格上的**友好 NPC**：
 * <ul>
 *   <li>地块仍然是 {@code Terrain.DOOR}，所以引擎的门逻辑（外观、着火、烧成余烬）全都照常</li>
 *   <li>格子上站着东西 → 走不进去，上前「交互」两次就把荆棘扯断，露出一扇普通木门</li>
 *   <li>交互不弹对话框，只有一下挥砍动作 + 粒子，看起来就像在砍它</li>
 *   <li>打不坏：所有伤害一律免疫，防御判定给到极高（攻击只会显示「挡住了」）</li>
 *   <li>不会还手：自己只 spend 回合，从不进入怪物状态机</li>
 * </ul>
 */
public class ThornDoor extends NPC {

    /** 出现概率：普通木门有 1/4 被荆棘缠上 */
    public static final int CHANCE = 4;

    /** 已经「掰」过几次荆棘（随存档保存） */
    private int talks = 0;

    private static final String TALKS = "talks";

    {
        spriteClass = ThornDoorSprite.class;

        HP = HT = 2;
        EXP = 0;
        defenseSkill = 0;
        // MOD: NEUTRAL 而不是 ALLY —— 商人和友好小恶魔都是 NEUTRAL，
        // 敌对怪的 chooseEnemy() 只把 ALLY 和英雄当目标，中立单位不会进仇恨列表。
        // 而 heroShouldInteract() 只排除 ENEMY，所以中立照样是「交互」而不是攻击
        alignment = Char.Alignment.NEUTRAL;
        state = PASSIVE;
        properties.add(Char.Property.IMMOVABLE);   // 不被冲击波推走
        properties.add(Char.Property.INORGANIC);
        properties.add(Char.Property.OBJECT);     // 是「物件」不是生物：不画血条、不弹闪避字
    }

    /** 永远只是「站在门里的一堆荆棘」：不跑 AI、不寻敌、不还手 */
    @Override
    protected boolean act() {
        tidyUp();
        spend(TICK);
        return true;
    }

    /** 荆棘本身不会着火（不长火苗、不挂燃烧状态），但会把门烧掉 */
    @Override
    public boolean isImmune(Class effect) {
        return effect == Fire.class || super.isImmune(effect);
    }

    /**
     * MOD: 冲击类效果（冲击波法杖的击退/眩晕）会把整排荆棘冲散，直接露出木门。
     * 注意：**电击符石的麻痹不算**——那种力道冲不开荆棘。
     */
    @Override
    public boolean add(Buff buff) {
        if (buff instanceof Vertigo) {
            shear();
            return false;
        }
        return super.add(buff);
    }

    /** 荆棘被整条冲散：门还是那扇门，只是没刺了 */
    private void shear() {
        if (pos < 0 || pos >= Dungeon.level.length()) {
            return;
        }
        say("冲击把门上的荆棘整条冲散了，木门露了出来。");
        CellEmitter.get(pos).start(Speck.factory(Speck.LIGHT), 0.08f, 8);
        vanish(false);
    }

    /** 同一条播报不连续重复（避免刷屏） */
    private static String lastLine = "";

    private static void say(String line) {
        if (line.equals(lastLine)) {
            return;
        }
        lastLine = line;
        GLog.i(line);
    }

    /** 把落在门格上的东西弹到相邻空地（优先弹向玩家这一侧），并从门格移除 */
    private void deflect(Heap heap) {
        if (heap.type != Heap.Type.HEAP || heap.items.isEmpty()) {
            return;
        }
        // 选“离玩家最近”的那一格：门另一侧的地面离英雄更远，自然不会被选中。
        // 注意**不排除**已有物品的格子——允许并进现成的物品堆，
        // 否则附近空地都被占满时就无处可弹，东西会留在门格里（看起来像穿门）
        int target = -1;
        float best = Float.MAX_VALUE;
        for (int i : PathFinder.NEIGHBOURS8) {
            int c = pos + i;
            if (c < 0 || c >= Dungeon.level.length()) {
                continue;
            }
            if (!Dungeon.level.passable[c] && !Dungeon.level.avoid[c]) {
                continue;
            }
            if (Actor.findChar(c) != null) {
                continue;              // 别把东西丢到谁脚下
            }
            float d = Dungeon.hero == null ? 0f : Dungeon.level.trueDistance(c, Dungeon.hero.pos);
            if (d < best) {
                best = d;
                target = c;
            }
        }
        if (target == -1 && Dungeon.hero != null) {
            // 八方向全被挡死：最后兜底掉在玩家脚边，总比卡在门格里好
            int c = Dungeon.hero.pos;
            if (c >= 0 && c < Dungeon.level.length()
                    && (Dungeon.level.passable[c] || Dungeon.level.avoid[c])) {
                target = c;
            }
        }
        if (target == -1) {
            return;
        }
        if (heap.sprite != null) {
            heap.sprite.killAndErase();
        }
        for (Item item : new ArrayList<>(heap.items)) {
            Heap landed = Dungeon.level.drop(item, target);
            if (landed != null && landed.sprite != null) {
                // 从门格飞过去：和怪物掉东西/玩家投掷一样的抛物线 + 落地弹跳
                landed.sprite.drop(pos);
            }
        }
        Dungeon.level.heaps.remove(pos);
        GameScene.updateMap(pos);
        // 按扔过来的东西分类播报：投掷武器是「砍不动」，其它杂物是「被弹回去」
        boolean weapon = false;
        for (Item item : heap.items) {
            if (item instanceof MissileWeapon) {
                weapon = true;
                break;
            }
        }
        say(weapon ? "荆棘无动于衷，你需要想想别的办法。"
                : "荆棘门把你扔的东西弹了回去。");
    }

    /**
     * MOD: 世界里的 NPC 只画**藤蔓**这一层（透明背景），门本身仍由引擎按朝向绘制——
     * 这样横板门 / 竖板门都能得到正确的门体，荆棘只负责“爬在上面”。
     */
    public static String textureFor(String tilesTex) {
        return "environment/custom_tiles/thorn_vines.png";
    }

    private static final String[] REGIONS = {"sewers", "prison", "caves", "city", "halls"};

    /**
     * MOD: 检视窗口的图标用**合成图**（木门 + 荆棘），按地区选——
     * 世界里是叠加层，但检视时只有一个图标位，合成一张才看得出“被荆棘缠绕”。
     */
    public static String iconFor(String tilesTex) {
        String region = "sewers";
        if (tilesTex != null) {
            for (String r : REGIONS) {
                if (tilesTex.contains("_" + r)) {
                    region = r;
                    break;
                }
            }
        }
        return "environment/custom_tiles/thorn_door_" + region + ".png";
    }

    // ============================================================
    // 交互：掰两次荆棘
    // ============================================================

    /** 英雄点它/顶它时走这条路（不弹窗） */
    @Override
    public boolean heroShouldInteract() {
        return true;
    }

    @Override
    public boolean interact(Char c) {
        if (!(c instanceof Hero)) {
            return false;
        }
        Hero hero = (Hero) c;
        hero.sprite.turnTo(hero.pos, pos);
        hero.sprite.attack(pos);              // 看起来是在砍它
        CellEmitter.get(pos).start(Speck.factory(Speck.LIGHT), 0.12f, 4);

        talks++;
        if (talks < 2) {
            GLog.i("你抓住门上的荆棘掰了一把，几根刺应声折断。");
            hero.spendAndNext(1.0f);
            return true;
        }
        GLog.i("最后一丛荆棘被扯断，木门露了出来。");
        CellEmitter.get(pos).start(Speck.factory(Speck.LIGHT), 0.08f, 8);
        vanish(false);
        hero.spendAndNext(1.0f);
        return true;
    }

    // ============================================================
    // 打不坏
    // ============================================================

    @Override
    public int defenseSkill(Char enemy) {
        return 1000;          // 攻击基本必空，只会显示「挡住了」
    }

    @Override
    public String defenseVerb() {
        return "挡住了";
    }

    @Override
    public void damage(int dmg, Object src) {
        // 燃烧：火能把它烧成灰烬（和普通木门一样）
        if (src instanceof Fire) {
            burnDown();
            return;
        }
        // 冲击波法杖（直接命中或波及）会把荆棘整条冲散
        if (src instanceof WandOfBlastWave) {
            shear();
            return;
        }
        // 震爆符石（ConjuredBomb 爆炸）同样能冲散荆棘
        if (src instanceof Bomb) {
            shear();
            return;
        }
        // 其余一切都无效：近战、投掷、法术、毒……
    }

    // ============================================================
    // 外观 / 文案
    // ============================================================

    @Override
    public String name() {
        return "被荆棘缠绕的木门";
    }

    @Override
    public String description() {
        return "看起来是扇普通木门，只是上面爬满了带刺的荆棘。";
    }

    // ============================================================
    // 每层布置
    // ============================================================

    /** 诊断：上一次写日志的楼层（同层只记一次，避免每回合刷屏） */
    private static int LOGGED_DEPTH = -1;

    /** 挑战开启时，每进入新的一层掷一次骰：25% 的普通门变成荆棘门 */
    public static void levelTick() {
        if (!com.shatteredpixel.shatteredpixeldungeon.ModContent.enabled()) {
            return;
        }
        if (Dungeon.level == null || Dungeon.hero == null) {
            return;
        }
        if (!Dungeon.isChallenged(Challenges.THORNS)) {
            logOnce("depth=" + Dungeon.depth + " THORNS=OFF mask=" + Dungeon.challenges);
            return;
        }
        ThornsMark mark = ThornsMark.get();
        if (mark == null) {
            mark = ThornsMark.ensure();
        }
        if (mark == null || mark.done(Dungeon.depth)) {
            logOnce("depth=" + Dungeon.depth + " skip (already decorated)");
            return;
        }
        mark.mark(Dungeon.depth);
        decorate();
        // 同一回合里也要收尾：投掷物落地会在 pressCell() 里立刻 Door.enter()，
        // 只在 NPC 自己 act() 里修太晚（它可能整回合都不轮到行动）
        police();
        LOGGED_DEPTH = Dungeon.depth;
    }

    /**
     * MOD: 每回合收尾——把荆棘门「钉死」。
     * 投掷物落到门格上时，引擎的 {@code Level.drop() → pressCell()} 会调用
     * {@code Door.enter()} 把门弹开（这是原版行为），这里在渲染之前把它按回去，
     * 并把落在门上的东西弹到相邻空地。
     */
    public static void police() {
        if (Dungeon.level == null || Dungeon.level.mobs == null) {
            return;
        }
        for (Mob m : Dungeon.level.mobs.toArray(new Mob[0])) {
            if (!(m instanceof ThornDoor)) {
                continue;
            }
            ((ThornDoor) m).tidyUp();
        }
    }

    /** 每回合 / 每帧的状态修复：门没了就消失、有火就烧掉、被弹开就按回去、东西弹走 */
    private void tidyUp() {
        if (pos < 0 || pos >= Dungeon.level.length()) {
            return;
        }
        int terrain = Dungeon.level.map[pos];
        if (terrain != Terrain.DOOR && terrain != Terrain.OPEN_DOOR) {
            // 门已经被烧成余烬（或被别的手段改掉了），荆棘也就没了
            vanish(false);
            return;
        }
        // 火：引擎对生物走的是 Buff(Burning) 那套，对我们无效，所以直接看这格有没有火
        if (Blob.volumeAt(pos, Fire.class) > 0) {
            burnDown();
            return;
        }
        if (terrain == Terrain.OPEN_DOOR) {
            Level.set(pos, Terrain.DOOR);
            GameScene.updateMap(pos);
            debug("closed door @" + pos);
        }
        Heap heap = Dungeon.level.heaps.get(pos);
        if (heap != null) {
            deflect(heap);
        }
    }

    private static void logOnce(String s) {
        if (LOGGED_DEPTH != Dungeon.depth) {
            LOGGED_DEPTH = Dungeon.depth;
            debug(s);
        }
    }

    private static void decorate() {
        Level level = Dungeon.level;
        int doors = 0;
        int placed = 0;
        for (int cell = 0; cell < level.length(); cell++) {
            if (level.map[cell] != Terrain.DOOR) {
                continue;
            }
            doors++;
            if (Actor.findChar(cell) != null) {
                continue;
            }
            if (level.adjacent(cell, Dungeon.hero.pos)) {
                continue;          // 别把门堵在玩家脚边
            }
            if (Random.Int(CHANCE) != 0) {
                continue;          // 1/4 概率
            }
            ThornDoor door = new ThornDoor();
            door.pos = cell;
            try {
                GameScene.add(door);
                placed++;
            } catch (Throwable t) {
                debug("spawn fail @" + cell + ": " + t);
            }
        }
        debug("depth=" + Dungeon.depth + " doors=" + doors + " placed=" + placed);
        if (placed > 0) {
            GameScene.updateMap();
        }
    }

    /** 诊断：把一行文字写进游戏数据目录的 thorns_debug.txt（每层最多一行，开销可忽略） */
    private static void debug(String s) {
        try {
            com.watabou.utils.FileUtils.getFileHandle("thorns_debug.txt")
                    .writeString(s + "\n", true, "UTF-8");
        } catch (Throwable ignored) {
        }
    }

    private void burnDown() {
        if (pos >= 0 && pos < Dungeon.level.length()) {
            CellEmitter.get(pos).start(Speck.factory(Speck.LIGHT), 0.1f, 4);
            Dungeon.level.destroy(pos);       // 木门 → 余烬（和普通门被烧一样）
            GameScene.updateMap(pos);
        }
        vanish(true);
    }

    private void vanish(boolean burnt) {
        debug("vanish pos=" + pos + " burnt=" + burnt + " map=" + (Dungeon.level == null ? -1 : Dungeon.level.map[pos]));
        if (this.sprite != null) {
            this.sprite.killAndErase();
        }
        if (Dungeon.level != null && Dungeon.level.mobs != null) {
            Dungeon.level.mobs.remove(this);
        }
        Actor.remove(this);
        if (burnt) {
            GLog.i("荆棘被烧成了灰。");
        }
    }

    @Override
    public void storeInBundle(Bundle bundle) {
        super.storeInBundle(bundle);
        bundle.put(TALKS, this.talks);
    }

    @Override
    public void restoreFromBundle(Bundle bundle) {
        super.restoreFromBundle(bundle);
        this.talks = bundle.getInt(TALKS);
    }
}
