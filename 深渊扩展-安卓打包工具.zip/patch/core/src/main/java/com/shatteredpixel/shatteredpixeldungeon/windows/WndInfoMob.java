package com.shatteredpixel.shatteredpixeldungeon.windows;

import com.shatteredpixel.shatteredpixeldungeon.actors.Char;
import com.shatteredpixel.shatteredpixeldungeon.actors.mobs.Mob;
import com.shatteredpixel.shatteredpixeldungeon.actors.mobs.ThornDoor;
import com.shatteredpixel.shatteredpixeldungeon.levels.Terrain;
import com.shatteredpixel.shatteredpixeldungeon.messages.Messages;
import com.shatteredpixel.shatteredpixeldungeon.scenes.PixelScene;
import com.shatteredpixel.shatteredpixeldungeon.sprites.CharSprite;
import com.shatteredpixel.shatteredpixeldungeon.tiles.DungeonTerrainTilemap;
import com.shatteredpixel.shatteredpixeldungeon.ui.BuffIndicator;
import com.shatteredpixel.shatteredpixeldungeon.ui.HealthBar;
import com.shatteredpixel.shatteredpixeldungeon.ui.RenderedTextBlock;
import com.watabou.noosa.Image;
import com.watabou.noosa.ui.Component;

/**
 * MOD: 原版 WndInfoMob 的整类覆盖。
 *
 * 与 4.0.2 的唯一差别：**「被荆棘缠绕的木门」不用 MobTitle**。
 * 它是物件不是生物，用「门贴图 + 名字」的普通标题栏即可，
 * 从而避开血条/状态图标那一套（检视它闪退正是出在那儿）。
 */
public class WndInfoMob extends WndTitledMessage {

    public WndInfoMob(Mob mob) {
        super(titleFor(mob), infoFor(mob));
    }

    /** MOD: 被先见护符「借」了视野的怪物，正文里也写明这个状态 */
    private static String infoFor(Mob mob) {
        String info = mob.info();
        if (mob.buff(com.shatteredpixel.shatteredpixeldungeon.actors.buffs.ForesightShared.class) != null) {
            info = info + "\n\n_被窥视_\n先见护符正借它的眼睛看东西。";
        }
        return info;
    }

    private static Component titleFor(Mob mob) {
        if (mob instanceof ThornDoor) {
            // 图标用「木门 + 荆棘」的合成图：世界里是叠加层，检视时一张图才看得出被缠住了
            Image icon = null;
            try {
                icon = new Image(ThornDoor.iconFor(
                        com.shatteredpixel.shatteredpixeldungeon.Dungeon.level == null
                                ? null
                                : com.shatteredpixel.shatteredpixeldungeon.Dungeon.level.tilesTex()),
                        0, 0, 16, 16);
            } catch (Throwable ignored) {
            }
            if (icon == null) {
                try {
                    icon = DungeonTerrainTilemap.tile(mob.pos, Terrain.DOOR);
                } catch (Throwable ignored) {
                }
            }
            if (icon == null) {
                icon = new Image();
            }
            return new IconTitle(icon, Messages.titleCase(mob.name()));
        }
        return new MobTitle(mob);
    }

    private static class MobTitle extends Component {

        private static final int GAP = 2;

        private CharSprite image;
        private RenderedTextBlock name;
        private HealthBar health;
        private BuffIndicator buffs;

        public MobTitle(Mob mob) {
            this.name = PixelScene.renderTextBlock(Messages.titleCase(mob.name()), 9);
            this.name.hardlight(0xFFFF44);
            this.add(this.name);
            this.image = mob.sprite();
            this.add(this.image);
            this.health = new HealthBar();
            this.health.level(mob);
            if (!Char.hasProp(mob, Char.Property.OBJECT)) {
                this.add(this.health);
            }
            this.buffs = new BuffIndicator(mob, false);
            if (!Char.hasProp(mob, Char.Property.OBJECT)) {
                this.add(this.buffs);
            }
        }

        @Override
        protected void layout() {
            this.image.x = 0.0f;
            this.image.y = Math.max(0.0f, this.name.height() + this.health.height() - this.image.height());
            float w = this.width - this.image.width() - 2.0f;
            this.name.setPos(this.x + this.image.width() + 2.0f,
                    this.image.height() > this.name.height()
                            ? this.y + (this.image.height() - this.name.height()) / 2.0f : this.y);
            this.health.setRect(this.image.width() + 2.0f, this.name.bottom() + 2.0f, w, this.health.height());
            this.buffs.maxBuffs = 50;
            this.buffs.setRect(this.name.right(), this.name.bottom() - 7.0f - 2.0f, w - this.name.width(), 8.0f);
            if (!this.buffs.allBuffsVisible()) {
                this.buffs.setRect(0.0f, this.health.bottom(), this.width, 8.0f);
                this.height = Math.max(this.image.y + this.image.height(), this.buffs.bottom());
            } else {
                this.height = Math.max(this.image.y + this.image.height(), this.health.bottom());
            }
        }
    }
}
