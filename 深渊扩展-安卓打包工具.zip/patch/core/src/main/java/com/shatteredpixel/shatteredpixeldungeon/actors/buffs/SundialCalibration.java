package com.shatteredpixel.shatteredpixeldungeon.actors.buffs;

import com.shatteredpixel.shatteredpixeldungeon.Dungeon;
import com.watabou.utils.Bundle;

/**
 * MOD: 位面日晷（强化）的「校准」记录。
 *
 * <p>每层可以校准一次：把这一层的判定锁成**白昼**（敌人生成按白昼算），
 * 代价是不再享受夜间的掉落兑现。记在英雄身上，随存档保存。</p>
 */
public class SundialCalibration extends Buff {

    /** 被校准的层号（-1 = 没校准） */
    public int depth = -1;

    private static final String DEPTH = "depth";

    {
        type = buffType.NEUTRAL;
        announced = false;
    }

    public static SundialCalibration get() {
        return Dungeon.hero == null ? null : Dungeon.hero.buff(SundialCalibration.class);
    }

    /** 当前这一层是不是已经被校准成白昼 */
    public static boolean calibratedNow() {
        SundialCalibration b = get();
        return b != null && b.depth == Dungeon.depth;
    }

    @Override
    public void storeInBundle(Bundle bundle) {
        super.storeInBundle(bundle);
        bundle.put(DEPTH, depth);
    }

    @Override
    public void restoreFromBundle(Bundle bundle) {
        super.restoreFromBundle(bundle);
        depth = bundle.getInt(DEPTH);
    }
}
