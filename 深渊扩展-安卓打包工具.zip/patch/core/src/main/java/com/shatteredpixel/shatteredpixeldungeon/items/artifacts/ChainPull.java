package com.shatteredpixel.shatteredpixeldungeon.items.artifacts;

import com.shatteredpixel.shatteredpixeldungeon.Dungeon;
import com.shatteredpixel.shatteredpixeldungeon.actors.Actor;
import com.shatteredpixel.shatteredpixeldungeon.actors.Char;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.Buff;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.Cripple;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.Invisibility;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.MagicImmune;
import com.shatteredpixel.shatteredpixeldungeon.actors.buffs.Paralysis;
import com.shatteredpixel.shatteredpixeldungeon.actors.hero.Hero;
import com.shatteredpixel.shatteredpixeldungeon.actors.hero.Talent;
import com.shatteredpixel.shatteredpixeldungeon.actors.mobs.Mob;
import com.shatteredpixel.shatteredpixeldungeon.effects.Chains;
import com.shatteredpixel.shatteredpixeldungeon.effects.Effects;
import com.shatteredpixel.shatteredpixeldungeon.effects.Pushing;
import com.shatteredpixel.shatteredpixeldungeon.items.Item;
import com.shatteredpixel.shatteredpixeldungeon.levels.Level;
import com.shatteredpixel.shatteredpixeldungeon.levels.traps.Trap;
import com.shatteredpixel.shatteredpixeldungeon.scenes.CellSelector;
import com.shatteredpixel.shatteredpixeldungeon.scenes.GameScene;
import com.shatteredpixel.shatteredpixeldungeon.scenes.PixelScene;
import com.shatteredpixel.shatteredpixeldungeon.tiles.DungeonTilemap;
import com.shatteredpixel.shatteredpixeldungeon.utils.GLog;
import com.watabou.noosa.audio.Sample;
import com.watabou.utils.Callback;

import java.lang.reflect.Field;

/**
 * MOD: 虚空锁链的「两头自由」施放。
 *
 * <p>先选起点 A（**必须站着一个生物**），再选终点 B，然后把这个生物从 A 拉到 B。
 * 消耗的充能等于 A→B 的距离（每一环正好延长一格），
 * 且 A 必须在锁链够得到的范围内（同样以充能数为准）。</p>
 *
 * <p>被拉动的敌人会附带 1 回合麻痹 + 4 回合残废；如果拉的是玩家自己，不加这两个。</p>
 *
 * <p>强化（通过试炼）后：动画改为从「终点」伸出、够到起点再把人拉过来。</p>
 */
public class ChainPull {

    /** 已经选好的起点（-1 = 还没选） */
    private static int startCell = -1;

    // ============================================================
    // 入口
    // ============================================================

    public static void begin(Hero hero) {
        // 只有通过试炼、强化过的锁链才走「起点->终点」两段式
        if (!ArtifactTrial.isEnhancedClass(EtherealChains.class)) {
            return;
        }
        dbg("begin() hero=" + (hero != null) + " ready=" + (hero != null && hero.ready));
        EtherealChains chains = chains(hero);
        dbg("  chains=" + (chains != null) + " charge=" + (chains == null ? -1 : chargeOf(chains))
                + " cursed=" + (chains != null && chains.cursed));
        if (chains == null) {
            GLog.w("锁链得装在神器位上。");
            return;
        }
        if (hero.buff(MagicImmune.class) != null) {
            return;
        }
        if (chains.cursed) {
            GLog.w("被诅咒的锁链不会听你的。");
            return;
        }
        if (chargeOf(chains) < 1) {
            GLog.w("锁链的充能不足。");
            return;
        }
        startCell = -1;
        if (!hero.ready) {
            hero.ready = true;            // 确保选择器可用（selectCell 按 ready 决定是否响应点击）
        }
        GameScene.selectCell(PICK_START);
        dbg("  selectCell(PICK_START) called");
    }

    private static void dbg(String s) {
        try {
            com.watabou.utils.FileUtils.getFileHandle("chains_debug.txt")
                    .writeString(s + "\n", true, "UTF-8");
        } catch (Throwable ignored) {
        }
    }

    private static final CellSelector.Listener PICK_START = new CellSelector.Listener() {
        @Override
        public void onSelect(Integer cell) {
            dbg("PICK_START.onSelect(" + cell + ")");
            if (cell == null) {
                return;
            }
            Char ch = Actor.findChar(cell);
            if (ch == null) {
                GLog.w("锁链的起点上必须站着一个生物。");
                return;
            }
            Hero hero = Dungeon.hero;
            EtherealChains chains = chains(hero);
            if (chains == null) {
                return;
            }
            if (Dungeon.level.distance(hero.pos, cell) > chargeOf(chains)) {
                GLog.w("锁链够不到那么远。");
                return;
            }
            startCell = cell;
            selectEndLater();
        }

        @Override
        public String prompt() {
            return "选锁链的起点（必须是一个生物）";
        }
    };

    /**
     * 第一步选完后启动第二步。
     *
     * <p>不能在 {@code onSelect} 里直接再调 {@code GameScene.selectCell}：
     * 选择器在回调返回后会做收尾（清 listener、复位 enabled），
     * 同步重设的第二个 listener 会被一起清掉，表现就是「只能选起点」。
     * 所以延到下一帧再开第二步。</p>
     */
    private static void selectEndLater() {
        com.watabou.noosa.Game.runOnRenderThread(new Callback() {
            @Override
            public void call() {
                if (startCell < 0) {
                    return;
                }
                Hero hero = Dungeon.hero;
                if (hero != null && !hero.ready) {
                    hero.ready = true;
                }
                GameScene.selectCell(PICK_END);
                dbg("  selectCell(PICK_END) called (deferred)");
            }
        });
    }

    private static final CellSelector.Listener PICK_END = new CellSelector.Listener() {
        @Override
        public void onSelect(Integer cell) {
            dbg("PICK_END.onSelect(" + cell + ") from " + startCell);
            if (cell == null) {
                startCell = -1;
                return;
            }
            perform(cell);
        }

        @Override
        public String prompt() {
            return "选锁链的终点";
        }
    };

    // ============================================================
    // 真正拉动
    // ============================================================

    private static void perform(final int end) {
        final Hero hero = Dungeon.hero;
        final EtherealChains chains = chains(hero);
        if (hero == null || chains == null || startCell < 0) {
            startCell = -1;
            return;
        }
        final Char target = Actor.findChar(startCell);
        final int start = startCell;
        startCell = -1;
        if (target == null) {
            GLog.w("起点上的生物已经不在了。");
            return;
        }
        if (Char.hasProp(target, Char.Property.IMMOVABLE)) {
            GLog.w("锁链拉不动它。");
            return;
        }
        if (target == hero && hero.rooted) {
            PixelScene.shake(1.0f, 1.0f);
            GLog.w("锁链无法拉动被缠绕的你。");
            return;
        }
        Level level = Dungeon.level;
        if (end < 0 || end >= level.length()) {
            return;
        }
        if (level.solid[end] || (!level.passable[end] && !level.avoid[end])) {
            GLog.w("终点得是能站的地方。");
            return;
        }
        if (Char.hasProp(target, Char.Property.LARGE) && !level.openSpace[end]) {
            GLog.w("它太大了，塞不进去。");
            return;
        }
        Char occupied = Actor.findChar(end);
        if (occupied != null && occupied != target) {
            GLog.w("终点已经站着别的东西了。");
            return;
        }
        final int cost = level.distance(start, end);
        if (cost < 1) {
            GLog.i("这样拉不动它。");
            return;
        }
        if (cost > chargeOf(chains)) {
            GLog.w("锁链的充能不足（这次要 " + cost + " 环）。");
            return;
        }

        hero.busy();
        chains.throwSound();
        Sample.INSTANCE.play("sounds/chains.mp3");
        // MOD: 强化后的锁链先从**终点**伸出、够到起点，再把起点上的生物拉过来；
        // 未强化时保持原版表现（从玩家身上伸向目标）。
        final com.watabou.utils.PointF chainFrom;
        if (ArtifactTrial.isEnhancedClass(EtherealChains.class)) {
            chainFrom = DungeonTilemap.raisedTileCenterToWorld(end);
        } else {
            chainFrom = hero.sprite.center();
        }
        hero.sprite.parent.add(new Chains(chainFrom, target.sprite.center(),
                Effects.Type.ETHEREAL_CHAIN, new Callback() {
            @Override
            public void call() {
                Actor.add(new Pushing(target, start, end, new Callback() {
                    @Override
                    public void call() {
                        target.pos = end;
                        subtractCharge(chains, cost);
                        Invisibility.dispel(hero);
                        Talent.onArtifactUsed(hero);
                        Item.updateQuickslot();
                        // 被拉动的敌人：1 回合麻痹 + 4 回合残废（拉玩家自己不算）
                        if (target != hero && target instanceof Mob
                                && target.alignment == Char.Alignment.ENEMY
                                && target.isAlive()) {
                            Buff.prolong(target, Paralysis.class, 1.0f);
                            Buff.prolong(target, Cripple.class, 4.0f);
                        }
                        Dungeon.level.occupyCell(target);
                        Dungeon.observe();
                        GameScene.updateFog();
                        hero.spendAndNext(1.0f);
                        // 踩到陷阱/掉坑之类交给引擎原本的处理
                        try {
                            Trap trap = Dungeon.level.traps.get(end);
                            if (trap != null) {
                                trap.trigger();
                            }
                        } catch (Throwable ignored) {
                        }
                    }
                }));
                hero.next();
            }
        }));
    }

    // ============================================================
    // 充能读写
    // ============================================================

    private static EtherealChains chains(Hero hero) {
        if (hero == null || hero.belongings == null) {
            return null;
        }
        Artifact equipped = hero.belongings.artifact();
        return equipped instanceof EtherealChains ? (EtherealChains) equipped : null;
    }

    private static int readInt(Artifact a, String field, int def) {
        try {
            Field f = Artifact.class.getDeclaredField(field);
            f.setAccessible(true);
            return f.getInt(a);
        } catch (Throwable t) {
            return def;
        }
    }

    private static float readFloat(Artifact a, String field, float def) {
        try {
            Field f = Artifact.class.getDeclaredField(field);
            f.setAccessible(true);
            return f.getFloat(a);
        } catch (Throwable t) {
            return def;
        }
    }

    private static void writeInt(Artifact a, String field, int v) {
        try {
            Field f = Artifact.class.getDeclaredField(field);
            f.setAccessible(true);
            f.setInt(a, v);
        } catch (Throwable ignored) {
        }
    }

    private static void writeFloat(Artifact a, String field, float v) {
        try {
            Field f = Artifact.class.getDeclaredField(field);
            f.setAccessible(true);
            f.setFloat(a, v);
        } catch (Throwable ignored) {
        }
    }

    public static int chargeOf(Artifact chains) {
        return readInt(chains, "charge", 0);
    }

    private static void subtractCharge(Artifact chains, int n) {
        writeInt(chains, "charge", Math.max(0, readInt(chains, "charge", 0) - n));
    }

}
