# 卡在 sdkmanager 怎么办（以及推荐的云端打包）

## 你遇到的错误是什么

```
java.lang.NoClassDefFoundError: javax/xml/bind/annotation/XmlSchema
```

`sdk-tools-windows-3859397` 是 **2017 年**的包，它的 `sdkmanager` 需要 **Java 8**；而我们用的是 **JDK 17**（Java 11 起把 JAXB 从 JDK 里移除了，所以找不到 `javax/xml/bind`）。

**这条路走不通**，不用再折腾它了。

顺便说一句：你下到的 SPD 4.0.2 源码用的是 **Gradle 9.5 + AGP 9.2 + compileSdk 36**，本来也不是这种老工具能应付的。

---

## 推荐：让 GitHub 的服务器打包（不用装、不用下大文件）

### 第 1 步：新建仓库

手机或电脑打开 <https://github.com/new>，名字随便（例如 `abyss-expansion`），点 **Create repository**。

### 第 2 步：上传补丁包（300 KB）

在仓库页面点 **Add file → Upload files**，把

```
深渊扩展-安卓打包工具.zip
```

拖进去，**并把文件名改成 `kit.zip`**（上传后可在文件列表里用 "Rename" 改），点 **Commit changes**。

### 第 3 步：新建 workflow 文件（复制粘贴即可）

在仓库页面点 **Add file → Create new file**，文件名填：

```
.github/workflows/build-apk.yml
```

（输入 `/` 会自动建目录）

把下面整段内容粘进去，然后 **Commit changes**：

```yaml
name: build-apk
on: workflow_dispatch
jobs:
  build:
    runs-on: ubuntu-latest
    timeout-minutes: 60
    steps:
      - uses: actions/checkout@v4
      - name: kit
        run: |
          for z in kit.zip *.zip; do [ -f "$z" ] && unzip -q -o "$z" || true; done
          for d in */; do [ -d "$d/patch" ] && cp -rf "$d/patch" . || true; done
          test -d patch
      - uses: actions/setup-java@v4
        with: { distribution: temurin, java-version: '17' }
      - uses: android-actions/setup-android@v3
      - name: src
        run: |
          curl -L --retry 3 -o spd.zip https://github.com/00-Evan/shattered-pixel-dungeon/archive/refs/tags/v4.0.2.zip
          unzip -q spd.zip
          echo "SRC=$(ls -d shattered-pixel-dungeon-* | head -n1)" >> $GITHUB_ENV
      - name: patch
        run: |
          cp -rf patch/core/src/main/java/* "$SRC/core/src/main/java/"
          mkdir -p "$SRC/core/src/main/assets"
          cp -rf patch/core/src/main/assets/* "$SRC/core/src/main/assets/"
          for p in "mod_misc.properties:misc.properties" "mod_misc_zh.properties:misc_zh.properties"; do
            s="patch/core/src/main/assets/messages/misc/${p%%:*}"; d="$SRC/core/src/main/assets/messages/misc/${p##*:}"
            [ -f "$s" ] && [ -f "$d" ] && cat "$s" >> "$d" || true
          done
      - name: build
        working-directory: ${{ env.SRC }}
        run: |
          chmod +x gradlew
          ./gradlew android:assembleDebug --no-daemon --stacktrace 2>&1 | tee build.log
          test ${PIPESTATUS[0]} -eq 0
      - name: errors
        if: failure()
        run: grep -E "error:|错误:" build.log | head -60 || true
      - name: apk
        run: |
          APK=$(find "$SRC/android/build/outputs/apk" -name "*.apk" | head -n1)
          cp "$APK" abyss-expansion-android.apk
      - uses: actions/upload-artifact@v4
        with:
          name: abyss-expansion-apk
          path: abyss-expansion-android.apk
```

### 第 4 步：运行

仓库顶栏 **Actions** → 左边 **build-apk** → 右边 **Run workflow** → 绿色按钮。

等 10~20 分钟（云端要下 Gradle 9.5、AGP、SDK 36、依赖）。

### 第 5 步：下载安装

点进这次运行记录，页面**最底部**的 **Artifacts** → `abyss-expansion-apk` → 下载得到一个 zip → 解压出 `abyss-expansion-android.apk` → 传手机安装。

> 装之前必须卸载商店版（签名不同）。装好后进游戏：开始游戏 → 选角色 → 挑战 → 勾选「启用深渊扩展」。

---

## 如果编译报错

云端日志里会有 `error:` 行。把 **Actions 页面里 "build" 那一步**最后 50 行发我（或截图），我直接改代码，改完你只需重新上传新的 `kit.zip` 再跑一次。

---

## 本地打包还有救吗

有，但要换掉老工具：

| 需要 | 说明 |
|---|---|
| **command-line tools（新版）** | 支持 JDK 17，不能再用手上这个 2017 年的 3859397 |
| SDK 组件 | `platforms;android-36`、`build-tools;36.0.0`、`platform-tools` |
| Gradle 9.5 | 从 services.gradle.org 下载（约 140 MB） |
| AGP 9.2 依赖 | 从 maven.google.com 下载（约 300 MB） |

这些在你这边的网络里大概率都下不动，**所以云端那把更省事**。

如果哪天想恢复本地路：装 **Android Studio**（它自带新版 cmdline-tools + SDK），然后把它的 SDK 路径告诉脚本即可：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\build_android.ps1 -SdkPath "C:\Users\你\AppData\Local\Android\Sdk"
```
