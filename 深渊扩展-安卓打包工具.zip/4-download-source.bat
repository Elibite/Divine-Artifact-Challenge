@echo off
title Download SPD 4.0.2 source
cd /d "%~dp0"
echo.
echo  === Download source with resume (curl) ===
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0download_source.ps1"
echo.
pause
