@echo off
title Check source zip
cd /d "%~dp0"
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0check_source_zip.ps1"
echo.
pause