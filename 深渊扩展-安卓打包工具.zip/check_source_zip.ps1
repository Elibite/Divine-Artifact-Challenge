﻿# =====================================================================
#  检查源码 zip 是否完整（GitHub 被拦截时经常只下到几 KB 的错误页）
#  双击 3-check-source-zip.bat 运行
# =====================================================================
$ErrorActionPreference = "Continue"
$kit = $PSScriptRoot
$candidates = @(
    (Join-Path $kit "work\spd-4.0.2.zip"),
    (Join-Path $kit "work\v4.0.2.zip"),
    (Join-Path $kit "spd-4.0.2.zip"),
    (Join-Path $kit "v4.0.2.zip")
)

Write-Host ""
Write-Host "===== 源码包检查 =====" -ForegroundColor Cyan

$found = $null
foreach ($c in $candidates) {
    if (Test-Path $c) { $found = $c; break }
}

if (-not $found) {
    Write-Host "没找到源码包。期望位置：" -ForegroundColor Yellow
    foreach ($c in $candidates) { Write-Host ("  " + $c) }
    Write-Host ""
    Write-Host "请把手机上下载的 v4.0.2.zip 复制成上面第一个路径（可以先建好 work 文件夹）。" -ForegroundColor Yellow
    Read-Host "按回车关闭" | Out-Null
    exit 1
}

$f = Get-Item $found
$sizeMB = [math]::Round($f.Length / 1MB, 2)
Write-Host ("文件: " + $f.FullName)
Write-Host ("大小: " + $sizeMB + " MB  (" + $f.Length + " 字节)")

# 读前 16 字节判断类型
$bytes = [System.IO.File]::ReadAllBytes($found)
$head = ""
if ($bytes.Length -ge 4) {
    $head = [System.Text.Encoding]::ASCII.GetString($bytes[0..([Math]::Min(63, $bytes.Length - 1))])
}
$isZip = ($bytes.Length -ge 2 -and $bytes[0] -eq 0x50 -and $bytes[1] -eq 0x4B)   # 'PK'
$isHtml = ($head -match "<!DOCTYPE|<html|^\s*<")

Write-Host ""
if ($isZip -and $f.Length -gt 5MB) {
    Write-Host "结论: 看起来是完整的 zip（正常应在 15~25 MB）" -ForegroundColor Green
    Write-Host "可以直接双击 1-build-android.bat 继续。" -ForegroundColor Green
}
elseif ($isHtml) {
    Write-Host "结论: 这是一个网页(HTML)，不是 zip —— 下载被拦截/失败，GitHub 返回了错误页。" -ForegroundColor Red
    Write-Host ("开头内容: " + $head)
    Write-Host ""
    Write-Host "处理办法（任选）：" -ForegroundColor Yellow
    Write-Host "  1) 用加速地址重新下载，然后覆盖这个文件："
    Write-Host "     https://ghproxy.net/https://github.com/00-Evan/shattered-pixel-dungeon/archive/refs/tags/v4.0.2.zip"
    Write-Host "     https://ghfast.top/https://github.com/00-Evan/shattered-pixel-dungeon/archive/refs/tags/v4.0.2.zip"
    Write-Host "     https://github.moeyy.xyz/https://github.com/00-Evan/shattered-pixel-dungeon/archive/refs/tags/v4.0.2.zip"
    Write-Host "  2) 在手机上下载完整 zip 后传过来（注意用「文件」发送，别发链接/预览）"
    Write-Host "  3) 改用 GitHub 云端打包（见 下载不了Studio怎么办.md 方案 3）"
}
elseif ($isZip -and $f.Length -le 5MB) {
    Write-Host "结论: 是 zip 但太小，多半是没下完/被截断。" -ForegroundColor Red
    Write-Host "请重新下载（正常 15~25 MB），或改用加速地址。" -ForegroundColor Yellow
}
else {
    Write-Host "结论: 不是 zip 文件（可能被微信/浏览器改了扩展名，或下载成了网页）。" -ForegroundColor Red
    Write-Host ("开头内容: " + $head)
    Write-Host "请重新下载完整 zip。" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "===== 检查结束 =====" -ForegroundColor Cyan
Read-Host "按回车关闭" | Out-Null
