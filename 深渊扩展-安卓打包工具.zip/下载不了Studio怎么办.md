# 电脑/手机下载不了 Android Studio 怎么办

三条出路，按「省事程度」排序。**任意一条成功就能拿到 APK**。

---

## 方案 1（最先试）：手机浏览器切「桌面版网站」

你手机能打开 <https://developer.android.com/studio>，只是页面说设备不支持——因为它是按手机 UA 判断的。

**做法**：

1. 手机 Chrome / Edge 打开那个网址
2. 右上角菜单 → 勾选 **「桌面版网站 / Request desktop site」**
3. 刷新页面 → 就会出现 **Windows (64-bit)** 的下载按钮（约 1.5 GB）
4. 下载完，用数据线或微信文件传输把 `.exe` 传到电脑，双击安装
5. 回到 `1-build-android.bat` 双击

> 如果手机能下但电脑传不过去：用「微信 → 文件传输助手」发给自己，电脑端保存即可（微信上限 1 GB/文件，若超限就用数据线）。

---

## 方案 2（更轻）：只装命令行工具，不装 Studio

Android Studio 1.5 GB，其实只需要 **command-line tools**（约 150 MB）+ SDK 组件。

1. 打开 [AndroidDevTools（国内镜像站）](https://www.androiddevtools.cn/) → 「SDK Tools」区
2. 下载 Windows 版 `sdk-tools-windows-*.zip` 或 `commandlinetools-win-*.zip`
   （该页面的链接指向 Google 的下载域名，若打不开，用方案 3 的镜像思路）
3. 解压到 `C:\Android\sdk\cmdline-tools\latest\`（注意目录层级）
4. 双击 `1-build-android.bat`，它会自动识别 SDK 并补齐 `platform-tools / platforms;android-34 / build-tools;34.0.0`

如果连 SDK 组件也下不动，把 `sdkmanager` 的下载源换成镜像（在环境变量里加）：

```
SDK_TEST_BASE_URL=https://mirrors.cloud.tencent.com/AndroidSDK
```

（部分镜像站可用；若无效就还是用方案 3）

---

## 方案 3（完全不用装东西）：让 GitHub 的服务器替你打包

**只要有 GitHub 账号**，手机浏览器就能搞定，电脑不装任何东西。

### 步骤

1. 手机/电脑打开 <https://github.com/new>，新建一个仓库（名字随便，比如 `abyss-expansion`，选 **Public** 或 Private 都行）
2. 上传文件：把本工具包里这些东西传上去（网页拖拽即可）
   ```
   patch\                     ← 整个补丁目录（59 个类 + 资源）
   .github\workflows\build-apk.yml
   ```
   > 网页上传支持拖整个文件夹（Chrome/Edge 桌面版）；手机不方便时可在电脑上操作。
3. 打开仓库 **Actions** 标签 → 左侧 **build-modded-apk** → 右边 **Run workflow** → 绿色按钮
4. 等 10~20 分钟（第一次要下 Gradle 依赖）
5. 点进运行记录 → 页面底部 **Artifacts** → 下载 **abyss-expansion-apk**
6. 得到一个 zip，解压出 `abyss-expansion-android.apk` → 传到手机安装

### 优点 / 缺点

- ✅ 电脑不用装任何工具链；每次改完代码推上去就自动重打
- ✅ 打包产物是标准 debug 签名，可以直接装
- ❌ GitHub 在国内偶尔慢/需要登录；构建日志是英文
- ❌ 仓库里放的是我们的补丁代码（SPD 是 GPLv3，公开分发要保留其许可）

---

## 方案 4（保底）：我给你远程判断

如果上面都不行，把下面信息发我，我再换思路（例如改用 Gitee 的流水线、或把补丁拆成 smali 补丁）：

| 需要你告诉我 | 怎么拿 |
|---|---|
| 电脑能不能打开 `github.com` | 浏览器试 |
| 电脑能不能打开 `dl.google.com` | 浏览器试（能开就能用方案 2 的 sdkmanager） |
| 手机能不能打开 `github.com` | 手机浏览器试 |
| `1-build-android.bat` 失败时的最后 20 行 | 截图 |

---

## 附：为什么需要这些工具

打个 APK 必须有 `aapt2 / d8 / apksigner`（Android SDK 里的），以及 Gradle 来驱动编译。这三样官方都只在 Google 的下载站和 IDE 里提供，所以只能「装工具」或「借用别人的服务器」。桌面版的 jar 能直接覆盖是因为桌面启动器支持 classpath 优先级，安卓没有这个机制。
