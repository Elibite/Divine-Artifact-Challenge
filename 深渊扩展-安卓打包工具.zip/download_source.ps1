﻿# =====================================================================
#  下载官方 SPD v4.0.2 源码（支持断点续传 / 多次重试 / 多镜像）
#  双击 4-download-source.bat 运行
# =====================================================================
$ErrorActionPreference = "Continue"
$kit  = $PSScriptRoot
$work = Join-Path $kit "work"
New-Item -ItemType Directory -Force -Path $work | Out-Null
$zip  = Join-Path $work "spd-4.0.2.zip"

$mirrors = @(
    "https://ghproxy.net/https://github.com/00-Evan/shattered-pixel-dungeon/archive/refs/tags/v4.0.2.zip",
    "https://ghfast.top/https://github.com/00-Evan/shattered-pixel-dungeon/archive/refs/tags/v4.0.2.zip",
    "https://github.moeyy.xyz/https://github.com/00-Evan/shattered-pixel-dungeon/archive/refs/tags/v4.0.2.zip",
    "https://gh-proxy.com/https://github.com/00-Evan/shattered-pixel-dungeon/archive/refs/tags/v4.0.2.zip",
    "https://kkgithub.com/00-Evan/shattered-pixel-dungeon/archive/refs/tags/v4.0.2.zip",
    "https://github.com/00-Evan/shattered-pixel-dungeon/archive/refs/tags/v4.0.2.zip"
)

$curl = Join-Path $env:SystemRoot "System32\curl.exe"
if (-not (Test-Path $curl)) { $curl = "curl" }

Write-Host ""
Write-Host "===== 下载 SPD 4.0.2 源码（支持断点续传） =====" -ForegroundColor Cyan
Write-Host ("保存到: " + $zip)
Write-Host ""

# 已有残包就保留，curl 会用 Range 接着下
if (Test-Path $zip) {
    Write-Host ("发现已有文件: " + [math]::Round((Get-Item $zip).Length / 1MB, 1) + " MB，尝试续传…") -ForegroundColor Yellow
}

function Test-ZipOk([string]$path) {
    try {
        Add-Type -AssemblyName System.IO.Compression.FileSystem -ErrorAction SilentlyContinue
        $z = [System.IO.Compression.ZipFile]::OpenRead($path)
        $n = $z.Entries.Count
        $z.Dispose()
        return ($n -gt 100)
    } catch { return $false }
}

foreach ($url in $mirrors) {
    Write-Host ""
    Write-Host ("尝试: " + $url) -ForegroundColor Cyan
    # -C - 续传；--retry 断线重试；失败也不中断脚本
    & $curl -L --retry 10 --retry-delay 2 --retry-all-errors --connect-timeout 20 -C - -o $zip $url
    $code = $LASTEXITCODE
    Write-Host ("  curl 退出码: " + $code)
    if ((Test-Path $zip) -and (Test-ZipOk $zip)) {
        Write-Host ""
        Write-Host ("成功！大小 " + [math]::Round((Get-Item $zip).Length / 1MB, 1) + " MB，压缩包完整。") -ForegroundColor Green
        Write-Host "现在双击 1-build-android.bat 继续打包。" -ForegroundColor Green
        Read-Host "按回车关闭" | Out-Null
        exit 0
    }
    Write-Host "  这个源没下完整，换下一个…" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "所有源都没能下完整。" -ForegroundColor Red
Write-Host ""
Write-Host "推荐改用「云端打包」：电脑什么都不用下" -ForegroundColor Yellow
Write-Host "  1. 手机或电脑打开 https://github.com/new 新建仓库"
Write-Host "  2. 上传 深渊扩展-安卓打包工具.zip，改名为 kit.zip"
Write-Host "  3. 仓库 Actions -> build-modded-apk -> Run workflow"
Write-Host "  4. 跑完在 Artifacts 里下载 abyss-expansion-apk"
Write-Host ""
Write-Host "（详见 下载不了Studio怎么办.md 方案 3）" -ForegroundColor Gray
Read-Host "按回车关闭" | Out-Null
exit 1
