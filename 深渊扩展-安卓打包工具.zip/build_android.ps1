﻿# =====================================================================
#  深渊扩展 · 安卓版一键打包
#
#  做四件事（全自动）：
#    1. 下载官方 Shattered Pixel Dungeon v4.0.2 源码
#    2. 把 patch\ 里的 59 个类 + 贴图 + 语言文件覆盖进去
#    3. 准备 Android SDK（没有就自动下载 command-line tools 并安装平台）
#    4. gradlew android:assembleDebug → 输出可安装的 APK
#
#  用法：双击 1-build-android.bat
#  需要：能上网（下载源码/依赖/SDK 共约 1~2 GB）
# =====================================================================
param(
    [string]$SourceRoot = "",
    [string]$SourceZip = "",
    [string]$SdkPath = "",
    [switch]$SkipSdkInstall,
    [switch]$SkipBuild,
    [switch]$SkipPatch
)

$ErrorActionPreference = "Stop"
$kit = $PSScriptRoot
$work = Join-Path $kit "work"
$srcZipUrl = "https://github.com/00-Evan/shattered-pixel-dungeon/archive/refs/tags/v4.0.2.zip"

function Say($msg)  { Write-Host ("  " + $msg) }
function Step($msg) { Write-Host ""; Write-Host ("== " + $msg) -ForegroundColor Cyan }
function Good($msg) { Write-Host ("  [OK] " + $msg) -ForegroundColor Green }
function Warn2($msg){ Write-Host ("  [注意] " + $msg) -ForegroundColor Yellow }
function Fail($msg) {
    Write-Host ""
    Write-Host ("[失败] " + $msg) -ForegroundColor Red
    Write-Host ""
    Write-Host "把上面整段内容截图发出来，我来判断下一步。" -ForegroundColor Yellow
    Write-Host ""
    Read-Host "按回车键关闭" | Out-Null
    exit 1
}

Write-Host ""
Write-Host "========== 深渊扩展 · 安卓打包 ==========" -ForegroundColor Cyan
Say ("工作目录: " + $work)

New-Item -ItemType Directory -Force -Path $work | Out-Null

# ---------------------------------------------------------------- JDK
Step "1/5 检查 Java (需要 17)"
function Find-Jdk([string]$base) {
    if (-not $base) { return $null }
    $dirs = @()
    if (Test-Path $base) {
        $item = Get-Item $base -ErrorAction SilentlyContinue
        if ($item -and $item.PSIsContainer -and (Test-Path (Join-Path $item.FullName "bin\javac.exe"))) {
            return $item.FullName
        }
        $dirs = Get-ChildItem $base -Directory -ErrorAction SilentlyContinue
    }
    foreach ($d in $dirs) {
        if (Test-Path (Join-Path $d.FullName "bin\javac.exe")) { return $d.FullName }
    }
    return $null
}

$foundJdk = $null
foreach ($cand in @(
        $env:JAVA_HOME,
        (Join-Path $kit "..\..\jdk"),
        (Join-Path $kit "..\jdk"),
        (Join-Path $kit "jdk"),
        "C:\Program Files\Java",
        "C:\Program Files\Eclipse Adoptium",
        "C:\Program Files\Microsoft",
        "C:\Program Files\Android\Android Studio\jbr")) {
    if (-not $cand) { continue }
    $hit = Find-Jdk $cand
    if ($hit) { $foundJdk = $hit; break }
}
# 最后兜底：PATH 里的 javac
if (-not $foundJdk) {
    $javac = Get-Command javac -ErrorAction SilentlyContinue
    if ($javac) {
        $foundJdk = Split-Path (Split-Path $javac.Source -Parent) -Parent
    }
}
if (-not $foundJdk) {
    Fail @"
没找到 JDK 17。
最省事的办法：安装 Android Studio（自带 JDK 和 SDK）：
  https://developer.android.com/studio
安装完重新双击本脚本即可。
"@
}
$env:JAVA_HOME = $foundJdk
$env:PATH = (Join-Path $foundJdk "bin") + ";" + $env:PATH
Good ("JDK: " + $foundJdk)

# ---------------------------------------------------------------- 源码
Step "2/5 准备官方源码 (v4.0.2)"
if ($SourceRoot) {
    if (-not (Test-Path (Join-Path $SourceRoot "core\src\main\java"))) {
        Fail ("指定的源码目录不像 SPD 源码: " + $SourceRoot)
    }
    Good ("使用已有源码: " + $SourceRoot)
} else {
    $existing = Get-ChildItem $work -Directory -Filter "shattered-pixel-dungeon-*" -ErrorAction SilentlyContinue |
        Where-Object { Test-Path (Join-Path $_.FullName "core\src\main\java") } | Select-Object -First 1
    if ($existing) {
        $SourceRoot = $existing.FullName
        Good ("复用已下载源码: " + $SourceRoot)
    } else {
        $zip = Join-Path $work "spd-4.0.2.zip"
        # 先检查已存在的 zip 有没有下载坏（GitHub 被拦截时常常是几 KB 的 HTML）
        if (Test-Path $zip) {
            $len = (Get-Item $zip).Length
            $head = ""
            try {
                $fs = [System.IO.File]::OpenRead($zip)
                $buf = New-Object byte[] 32
                $n = $fs.Read($buf, 0, 32)
                $fs.Close()
                $head = [System.Text.Encoding]::ASCII.GetString($buf, 0, $n)
            } catch { }
            if ($len -lt 5MB -or -not ($head.StartsWith("PK"))) {
                Warn2 ("已有的源码包无效（" + [math]::Round($len / 1KB, 1) + " KB），删掉重下")
                Remove-Item $zip -Force -ErrorAction SilentlyContinue
            } else {
                Good ("已有源码包: " + [math]::Round($len / 1MB, 1) + " MB")
            }
        }
        if ($SourceZip) {
            if (-not (Test-Path $SourceZip)) { Fail ("给的源码 zip 不存在: " + $SourceZip) }
            Copy-Item $SourceZip $zip -Force
            Good ("使用手动指定的源码包: " + $SourceZip)
        }
        if (-not (Test-Path $zip)) {
            Say "正在下载源码（约 20 MB），依次尝试多个镜像…"
            $mirrors = @(
                $srcZipUrl,
                "https://ghproxy.net/https://github.com/00-Evan/shattered-pixel-dungeon/archive/refs/tags/v4.0.2.zip",
                "https://gh-proxy.com/https://github.com/00-Evan/shattered-pixel-dungeon/archive/refs/tags/v4.0.2.zip",
                "https://github.moeyy.xyz/https://github.com/00-Evan/shattered-pixel-dungeon/archive/refs/tags/v4.0.2.zip",
                "https://ghfast.top/https://github.com/00-Evan/shattered-pixel-dungeon/archive/refs/tags/v4.0.2.zip",
                "https://kkgithub.com/00-Evan/shattered-pixel-dungeon/archive/refs/tags/v4.0.2.zip"
            )
            $got = $false
            foreach ($u in $mirrors) {
                try {
                    Say ("尝试: " + $u)
                    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
                    Invoke-WebRequest -Uri $u -OutFile $zip -UseBasicParsing -TimeoutSec 300
                    if ((Get-Item $zip).Length -gt 1MB) { $got = $true; break }
                } catch {
                    Say ("  失败: " + $_.Exception.Message)
                    Remove-Item $zip -Force -ErrorAction SilentlyContinue
                }
            }
            if (-not $got) {
                Fail @"
所有镜像都下不动（你这边的网络连不上 GitHub）。

三个解决办法，任选其一：
 [A] 手机浏览器打开这个链接下载（手机网络通常能通）：
     https://github.com/00-Evan/shattered-pixel-dungeon/archive/refs/tags/v4.0.2.zip
     下载后用微信/数据线传到电脑，然后运行：
       powershell -NoProfile -ExecutionPolicy Bypass -File .\build_android.ps1 -SourceZip "D:\传过来的\v4.0.2.zip"
     或者直接把 zip 放进：
       $work\spd-4.0.2.zip
     然后重新双击 1-build-android.bat

 [B] 用 GitHub 的服务器打包（电脑什么都不用下）：见 下载不了Studio怎么办.md 的方案 3

 [C] 在浏览器里试试这几个加速地址（能下就用 -SourceZip 指过去）：
     https://ghproxy.net/https://github.com/00-Evan/shattered-pixel-dungeon/archive/refs/tags/v4.0.2.zip
     https://ghfast.top/https://github.com/00-Evan/shattered-pixel-dungeon/archive/refs/tags/v4.0.2.zip
"@
            }
            Good ("下载完成: " + [math]::Round((Get-Item $zip).Length / 1MB, 1) + " MB")
        }
        Good ("下载完成: " + [math]::Round((Get-Item $zip).Length / 1MB, 1) + " MB")
        Say "解压中…"
        Expand-Archive -Path $zip -DestinationPath $work -Force
        $dir = Get-ChildItem $work -Directory -Filter "shattered-pixel-dungeon-*" | Select-Object -First 1
        if (-not $dir) { Fail "解压后没找到源码目录" }
        $SourceRoot = $dir.FullName
        Good ("源码目录: " + $SourceRoot)
    }
}

# ---------------------------------------------------------------- 打补丁
if (-not $SkipPatch) {
    Step "3/5 覆盖自制内容"
    $pJava = Join-Path $kit "patch\core\src\main\java"
    $pAssets = Join-Path $kit "patch\core\src\main\assets"
    if (-not (Test-Path $pJava)) { Fail "patch 目录不完整，请重新解压安装包" }

    $dstJava = Join-Path $SourceRoot "core\src\main\java"
    $dstAssets = Join-Path $SourceRoot "core\src\main\assets"
    $replaced = 0
    $added = 0
    Get-ChildItem $pJava -Recurse -Filter *.java | ForEach-Object {
        $rel = $_.FullName.Substring($pJava.Length + 1)
        $dst = Join-Path $dstJava $rel
        New-Item -ItemType Directory -Force -Path (Split-Path $dst) | Out-Null
        if (Test-Path $dst) { $replaced++ } else { $added++ }
        Copy-Item $_.FullName $dst -Force
    }
    Good ("覆盖已有类: $replaced    新增类: $added")

    if (Test-Path $pAssets) {
        $an = 0
        Get-ChildItem $pAssets -Recurse -File | ForEach-Object {
            $rel = $_.FullName.Substring($pAssets.Length + 1)
            $dst = Join-Path $dstAssets $rel
            New-Item -ItemType Directory -Force -Path (Split-Path $dst) | Out-Null
            Copy-Item $_.FullName $dst -Force
            $an++
        }
        Good ("资源/语言文件: $an")
    }

    # 语言补充键：追加到官方 misc_*.properties 末尾（不覆盖原文件）
    $msgDir = Join-Path $dstAssets "messages\misc"
    if (Test-Path $msgDir) {
        foreach ($pair in @(@("mod_misc.properties", "misc.properties"), @("mod_misc_zh.properties", "misc_zh.properties"))) {
            $srcP = Join-Path $pAssets ("messages\misc\" + $pair[0])
            $dstP = Join-Path $msgDir $pair[1]
            if ((Test-Path $srcP) -and (Test-Path $dstP)) {
                $extra = Get-Content $srcP -Raw -Encoding UTF8
                $have = Get-Content $dstP -Raw -Encoding UTF8
                if ($have -notmatch [regex]::Escape("challenges.artifact_challenge=")) {
                    Add-Content -Path $dstP -Value $extra -Encoding UTF8
                    Good ("追加语言键: " + $pair[1])
                } else {
                    Say ("语言键已存在，跳过: " + $pair[1])
                }
            }
        }
    } else {
        Warn2 "没找到 core\src\main\assets\messages\misc ，语言文本可能不生效"
    }
}

if ($SkipBuild) {
    Write-Host ""
    Good "已完成打补丁（跳过了构建）"
    Read-Host "按回车键关闭" | Out-Null
    exit 0
}

# ---------------------------------------------------------------- Android SDK
Step "4/5 准备 Android SDK"
function Find-SdkManagerDeep([string]$dir) {
    if (-not $dir -or -not (Test-Path $dir)) { return $null }
    # 先查标准位置
    foreach ($rel in @("cmdline-tools\latest\bin\sdkmanager.bat", "tools\bin\sdkmanager.bat")) {
        $p = Join-Path $dir $rel
        if (Test-Path $p) { return $p }
    }
    # 再往下找两层（解压时多套了一层目录也很常见）
    $hits = @()
    foreach ($depth in @("*", "*\*")) {
        $hits += Get-ChildItem (Join-Path $dir $depth) -Filter "sdkmanager.bat" -Recurse -Depth 1 -ErrorAction SilentlyContinue
    }
    $hit = $hits | Where-Object { $_.FullName -match "\\bin\\sdkmanager\.bat$" } | Select-Object -First 1
    if ($hit) { return $hit.FullName }
    return $null
}

function Test-Sdk([string]$dir) {
    if (-not $dir) { return $false }
    if (-not (Test-Path $dir)) { return $false }
    if (Test-Path (Join-Path $dir "platform-tools")) { return $true }
    if (Find-SdkManagerDeep $dir) { return $true }
    return $false
}
function Get-SdkPath {
    if ($SdkPath) { return $SdkPath }
    if ($env:ANDROID_HOME) { return $env:ANDROID_HOME }
    if ($env:ANDROID_SDK_ROOT) { return $env:ANDROID_SDK_ROOT }
    $guess = @(
        (Join-Path $work "android-sdk"),
        "C:\Android\sdk",
        (Join-Path $env:USERPROFILE "Android\sdk"),
        (Join-Path $env:LOCALAPPDATA "Android\Sdk"),
        (Join-Path $kit "sdk")
    )
    foreach ($g in $guess) { if (Test-Sdk $g) { return $g } }
    return $null
}
function Find-SdkManager([string]$dir) {
    return (Find-SdkManagerDeep $dir)
}
$sdk = Get-SdkPath

if (-not $sdk) {
    if ($SkipSdkInstall) { Fail "没找到 Android SDK（已指定跳过自动安装）" }
    $sdk = Join-Path $work "android-sdk"
    Say "没找到 Android SDK，自动下载 command-line tools…"
    $clZip = Join-Path $work "cmdline-tools.zip"
    if (-not (Test-Path $clZip)) {
        try {
            Invoke-WebRequest -Uri "https://dl.google.com/android/repository/commandlinetools-win-11076708_latest.zip" -OutFile $clZip -UseBasicParsing -TimeoutSec 600
        } catch {
            Fail @"
下载 Android SDK 工具失败：$($_.Exception.Message)
替代方案：安装 Android Studio（https://developer.android.com/studio），装完重跑本脚本。
"@
        }
    }
    $clDir = Join-Path $work "cmdline-tools-tmp"
    if (Test-Path $clDir) { Remove-Item $clDir -Recurse -Force }
    Expand-Archive -Path $clZip -DestinationPath $clDir -Force
    New-Item -ItemType Directory -Force -Path (Join-Path $sdk "cmdline-tools") | Out-Null
    $inner = Get-ChildItem $clDir -Directory | Select-Object -First 1
    $target = Join-Path $sdk "cmdline-tools\latest"
    if (Test-Path $target) { Remove-Item $target -Recurse -Force }
    Move-Item $inner.FullName $target
    Good ("SDK 工具就位: " + $target)
    $sm = Join-Path $target "bin\sdkmanager.bat"

    Say "接受 SDK 许可协议…"
    cmd /c "echo y| ""$sm"" --sdk_root=""$sdk"" --licenses" 2>&1 | Out-Null
    Say "安装 platform-tools / platforms;android-34 / build-tools;34.0.0（约 300 MB）…"
    cmd /c """$sm"" --sdk_root=""$sdk"" ""platform-tools"" ""platforms;android-34"" ""build-tools;34.0.0""" 2>&1 |
        Select-Object -Last 5 | ForEach-Object { Say $_ }
}
$sdk = (Resolve-Path $sdk).Path
Good ("SDK: " + $sdk)

# 缺 platform-tools / platforms;android-34 / build-tools;34.0.0 就用 sdkmanager 补
$needPackages = @()
if (-not (Test-Path (Join-Path $sdk "platform-tools"))) { $needPackages += "platform-tools" }
if (-not (Test-Path (Join-Path $sdk "platforms\android-34"))) { $needPackages += "platforms;android-34" }
if (-not (Test-Path (Join-Path $sdk "build-tools\34.0.0"))) { $needPackages += "build-tools;34.0.0" }

if ($needPackages.Count -gt 0) {
    $sm = Find-SdkManager $sdk
    if (-not $sm) {
        Fail @"
SDK 里缺少组件（$($needPackages -join ', ')），也找不到 sdkmanager。
请重装 Android Studio，或下载 command-line tools（含 cmdline-tools\latest\bin\sdkmanager.bat）。
"@
    }
    Good ("sdkmanager: " + $sm)
    Say "接受许可协议…"
    cmd /c "echo y| ""$sm"" --sdk_root=""$sdk"" --licenses" 2>&1 | Out-Null
    Say ("安装组件: " + ($needPackages -join " "))
    foreach ($pkg in $needPackages) {
        cmd /c """$sm"" --sdk_root=""$sdk"" ""$pkg""" 2>&1 |
            Select-Object -Last 3 | ForEach-Object { Say $_ }
    }
    # 老版 sdkmanager 有时装到 %LOCALAPPDATA%\Android\Sdk，检查一下
    if (-not (Test-Path (Join-Path $sdk "platforms\android-34"))) {
        $alt = Join-Path $env:LOCALAPPDATA "Android\Sdk"
        if (Test-Path (Join-Path $alt "platforms\android-34")) {
            Warn2 ("组件被装到了 " + $alt + "，改用这个 SDK")
            $sdk = $alt
        } else {
            Warn2 "sdkmanager 没装成功（可能需要代理/网络），继续尝试编译"
        }
    }
}

# local.properties
$localProps = Join-Path $SourceRoot "local.properties"
"sdk.dir=" + ($sdk -replace '\\', '\\') | Set-Content -Path $localProps -Encoding ASCII
Good ("已写 local.properties")

# ---------------------------------------------------------------- 构建
Step "5/5 编译 APK（首次会下载 Gradle 依赖，可能 10~30 分钟）"
Push-Location $SourceRoot
try {
    $gradlew = Join-Path $SourceRoot "gradlew.bat"
    if (-not (Test-Path $gradlew)) { Fail "源码里没有 gradlew.bat" }
    & cmd /c "gradlew.bat android:assembleDebug --no-daemon 2>&1"
    $code = $LASTEXITCODE
} finally {
    Pop-Location
}
if ($code -ne 0) {
    Fail @"
编译失败（退出码 $code）。常见原因：
  - 首次需要联网下载 Gradle/依赖，网络不通
  - JDK 版本不对（必须 17）
  - Android SDK 平台缺失
请把上面最后 30 行发出来。
"@
}

$apk = Get-ChildItem (Join-Path $SourceRoot "android\build\outputs\apk") -Recurse -Filter *.apk -ErrorAction SilentlyContinue |
    Sort-Object LastWriteTime -Descending | Select-Object -First 1
if (-not $apk) { Fail "编译成功但没找到 APK（android\build\outputs\apk 下为空）" }

$out = Join-Path $kit "深渊扩展-android.apk"
Copy-Item $apk.FullName $out -Force
Write-Host ""
Good ("APK: " + $out)
Say ([math]::Round((Get-Item $out).Length / 1MB, 1).ToString() + " MB")
Write-Host ""
Write-Host "安装方法：" -ForegroundColor Yellow
Write-Host "  手机连电脑（开 USB 调试）-> 双击 2-install-to-phone.bat"
Write-Host "  或者把 apk 拷到手机里直接点安装"
Write-Host "  注意：需要先卸载商店版（签名不同，无法覆盖安装），存档会丢" -ForegroundColor Yellow
Write-Host ""
Read-Host "按回车键关闭" | Out-Null
