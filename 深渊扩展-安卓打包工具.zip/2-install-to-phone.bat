@echo off
title Install APK to phone
cd /d "%~dp0"
echo.
echo  === Installing APK via adb (USB debugging must be on) ===
echo.
set APK=%~dp0abyss-expansion-android.apk
if not exist "%APK%" set APK=%~dp0????-android.apk
if not exist "%APK%" ( echo APK not found - run 1-build-android.bat first & pause & exit /b 1 )
adb devices
adb install -r "%APK%"
echo.
pause
