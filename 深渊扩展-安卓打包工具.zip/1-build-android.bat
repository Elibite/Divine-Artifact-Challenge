@echo off
title Abyss Expansion - Android build
cd /d "%~dp0"
echo.
echo  === Building modded APK (needs internet) ===
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0build_android.ps1"
echo.
pause
